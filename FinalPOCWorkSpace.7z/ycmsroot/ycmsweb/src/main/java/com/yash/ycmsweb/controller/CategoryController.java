package com.yash.ycmsweb.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.yash.ycmscore.model.Category;
import com.yash.ycmscore.model.Customer;
import com.yash.ycmscore.model.Token;
import com.yash.ycmscore.service.CategoryService;
import com.yash.ycmscore.service.CustomerService;

import io.jsonwebtoken.Claims;

/**
 * this is the Controller that will handle the requests for the Category related
 * resources
 * 
 * @author aakash.jangid
 *
 */
@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class CategoryController {

	/**
	 * this will be the bean which will give the methods of CategoryService to the
	 * controller
	 */
	@Autowired
	private CategoryService categoryService;
	
	@Autowired
	private CustomerService customerService;
	/**
	 * this method will return the list of all the categories to the front
	 * application in JSON format
	 */
	@RequestMapping(value="/categories/{trashStatus}", method=RequestMethod.GET)
	public List<Category> getAllCategories(@PathVariable int trashStatus, HttpServletRequest httpRequest) {
		return categoryService.getAllCategories(trashStatus, getCustomer(httpRequest).getDomainName());
	}

	/**
	 * This method will change the status of the category whose id is being passed
	 * as the parameter in the URL.
	 * 
	 * @param id This is the identity of that category.
	 * @return true - if it changes the status successfully else it will return false.
	 */
	@RequestMapping(value = "/categories/trash/{id}", method = RequestMethod.GET)
	public boolean changeTrashStatus(@PathVariable int id,  HttpServletRequest httpRequest) {
		return categoryService.changeTrashStatus(id,  getCustomer(httpRequest).getDomainName());
	}
	
	/**
	 * This controller method is used to add the category
	 * 
	 * @param category - the category entity obtained from the request body
	 * 
	 * @return success message if category is added successfully otherwise failure message
	 * 
	 * @author minerva.shrivastava
	 */
	@RequestMapping(value="/category", method=RequestMethod.POST)
	public String addCategories(@RequestBody Category category, HttpServletRequest httpRequest){
		 boolean result = categoryService.addCategory(category, getCustomer(httpRequest).getDomainName());
		 if(result)
			 return "Category added successfully";
		 else
			 return "Category addition failed";
	}
	
	public Customer getCustomer(HttpServletRequest httpRequest) {
		Token token = null;
		Customer customer = null;
		Claims claims = (Claims) httpRequest.getAttribute("claims");
		ObjectMapper mapper = new ObjectMapper();
		try {
			token = mapper.readValue(claims.getSubject(), Token.class);
			customer = customerService.getCustomer(token.getEmail());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return customer;
	}
}