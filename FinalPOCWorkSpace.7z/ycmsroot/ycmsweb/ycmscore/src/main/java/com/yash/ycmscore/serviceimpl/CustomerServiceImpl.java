package com.yash.ycmscore.serviceimpl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;

import com.yash.ycmscore.dao.CustomerDAO;
import com.yash.ycmscore.model.Customer;
import com.yash.ycmscore.model.Page;
import com.yash.ycmscore.service.CustomerService;

/**
 * this is the implementation of the CustomerService interface
 * 
 * Date - 07/04/2018
 * 
 * @author chetan.magre
 * @Service annotation is used in your service layer and annotates classes that
 *          perform service tasks
 */
@Service
public class CustomerServiceImpl implements CustomerService {
	/**
	 * this is the customerDAO bean needed in service
	 * 
	 * @author chetan.magre
	 * @Autowired annotation is auto wire the bean by matching data type.
	 */
	@Autowired
	private CustomerDAO customerDAO;

	/**
	 * this is the LDAPService bean needed in service to use external LDAP
	 * service
	 * 
	 * @author chetan.magre
	 * @Autowired annotation is auto wire the bean by matching data type.
	 */
	@Autowired
	private LDAPService ldapService;
	/**
	 * this is the MailService bean needed in service use external mail service
	 * 
	 * @author chetan.magre
	 * @Autowired annotation is auto wire the bean by matching data type.
	 */
	@Autowired
	private MailService mailService;

	/**
	 * url that is used by getURL() method.
	 * 
	 * @author saloni.jain
	 */
	private final String URL = "http://localhost:4200/";

	/**
	 * this method will check whether the customer is registered or not and if
	 * not it will register user and will allot domain name as provided
	 * 
	 * @author chetan.magre
	 * @param customer
	 *            object with detail as email password and domain Name
	 * @return String value based on successful registration or not
	 */
	public String customerRegistration(Customer customer) {
		Customer isExist = customerDAO.isCustomerExist(customer.getEmail());
		if (isExist != null) {
			return "Customer is Already Registered to YCMS";
		} else {
			boolean status = ldapService.userAuthentication(customer.getEmail(), customer.getPassword());
			if (status) {
				customerDAO.insert(customer);
				customerDAO.createDatabase(customer.getDomainName());
				mailService.sendEmail(customer.getEmail(), customer.getDomainName(), getURL("signin"));
				createFiles(customer.getDomainName(), System.getProperty("catalina.base") + "\\webapps\\");
				return "Registration Successful";
			} else {
				return "Email Or Password is incorrect";
			}
		}
	}

	/**
	 * this method will get list of all domainName in the database and return
	 * 
	 * @author chetan.magre
	 * @return list of all domainNames
	 */
	public List<String> getListOfDomainName() {
		return customerDAO.getAllDatabaseNames();
	}

	/**
	 * this is a generic method that will return link based on action i.e.(name
	 * of form) for which we want to create a link and this link will be used as
	 * to navigate on different pages.
	 * this method will work as a helper method.
	 * 
	 * @author saloni.jain
	 * @param action
	 *            is the argument i.e.(name of form) for which we want to create
	 *            a link
	 * @return url based on action
	 */
	private String getURL(String action) {

		return URL + action;
	}

	/**
	 * This method will authenticate the customer based on the credentials provided 
	 * by calling the LDAPService for LDAP authentication services
	 * 
	 * @param Yash
	 *            emailId of customer
	 * @param Yash
	 *            password of customer
	 * @return true if customer is authenticated otherwise false
	 * 
	 * @author minerva.shrivastava
	 */
	public boolean customerAuthentication(String email, String password) {
		boolean status = false;
		if (customerDAO.isCustomerExist(email) != null) {
			status = ldapService.userAuthentication(email, password);
			if (status) {
				customerDAO.updateCustomerLoginDateTime(email);
			}
		}
		return status;
	}

	/**
	 * This method will create the folder and file structure by the name of the
	 * Domain and the path where it should be create
	 * 
	 * @param domainName
	 *            name of the domain where the files to be created
	 * @param path
	 *            where the files to be created
	 * @return boolean value on successful or unsuccessful operation
	 * 
	 * @author yash.verma
	 */
	public boolean createFiles(String domainName, String path) {
		File staticcss = null;
		File headerimg = null;
		File staticindex = null;
		try {
			staticcss = ResourceUtils.getFile("classpath:common/style.css");
			headerimg = ResourceUtils.getFile("classpath:common/header-img.jpg");
			staticindex = ResourceUtils.getFile("classpath:common/index.html");
		} catch (FileNotFoundException exception) {
			exception.printStackTrace();
		}

		File file = new File(path, domainName);
		file.mkdir();
		File cssfolder = new File(file, "//css");
		cssfolder.mkdir();
		File jsfolder = new File(file, "//js");
		jsfolder.mkdir();
		File imagesfolder = new File(file, "//images");
		imagesfolder.mkdir();

		Page page = new Page();
		page.setDomainName(domainName);

		try {
			File indexfile = new File(file, "//index.html");
			indexfile.createNewFile();
			copyContent(staticindex, indexfile);
			page.setPageName("index.html");
			page.setUrl(domainName + "/index.html");
			customerDAO.savePageContent(page);

			File stylecssfile = new File(cssfolder, "//style.css");
			stylecssfile.createNewFile();
			copyContent(staticcss, stylecssfile);
			page.setPageName("style.css");
			page.setUrl(domainName + "/css/style.css");
			customerDAO.savePageContent(page);

			File headerimage = new File(imagesfolder, "//header-img.jpg");
			headerimage.createNewFile();
			copyContent(headerimg, headerimage);
			page.setPageName("header-img.jpg");
			page.setUrl(domainName + "/images/header-img.jpg");
			customerDAO.savePageContent(page);

			File aboutfile = new File(file, "//about.html");
			aboutfile.createNewFile();
			page.setPageName("about.html");
			page.setUrl(domainName + "/about.html");
			customerDAO.savePageContent(page);

			// File ycmtTutorialfile = new File(file, "//ycmt-tutorial.html");
			// ycmtTutorialfile.createNewFile();
			// page.setPageName("ycmt-tutorial.html");
			// page.setUrl(domainName + "/ycmt-tutorial.html");
			// customerDAO.savePageContent(page);

		} catch (IOException e) {
			e.printStackTrace();
		}
		return true;
	}

	/**
	 * This method will copy the content of one file to another file
	 * 
	 * @param staticindex
	 * @param indexfile
	 * @return boolean value on successful or unsuccessful operation
	 * @author yash.verma
	 */
	public boolean copyContent(File staticindex, File indexfile) {
		FileInputStream instream = null;
		FileOutputStream outstream = null;
		try {
			File outfile = new File(indexfile.getPath());
			instream = new FileInputStream(staticindex);
			outstream = new FileOutputStream(outfile);
			byte[] buffer = new byte[1024];
			int length;
			while ((length = instream.read(buffer)) > 0) {
				outstream.write(buffer, 0, length);
			}
			instream.close();
			outstream.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
		return false;
	}

	/**
	 * This service method will return the url of a static page in the form of
	 * string by provided parameters- pageName and domainName
	 * 
	 * @param pageName
	 *            name of the page to be displayed
	 * @param domainName
	 *            name of the domain for which page to be displayed
	 * 
	 * @author shyam.patidar
	 * 
	 * @return String 'url' if success else return 'null'
	 */
	public String getPageUrl(String pageName, String domainName) {
		return customerDAO.getPageUrl(pageName, domainName);
	}

	/**
	 * this method is to check whether or not customer is in the database. or is
	 * registered or not
	 * 
	 * @author chetan.magre
	 * @param email
	 *            address of customer
	 * @return customer with its details from database
	 */
	public Customer isCustomerExist(String email) {
		return customerDAO.isCustomerExist(email);
	}

	/**
	 * this will be used for getting the customer according to login name
	 * 
	 * Date :- 09/04/2018
	 * 
	 * @author nitesh.yadav
	 * 
	 * @param loginname
	 * 
	 * @return it will return the customer to the customerController
	 */
	public Customer getCustomer(String loginname) {
		return customerDAO.getCustomer(loginname);
	}

	/**
	 * this will update the customer details in the customers table and will
	 * return the updated customer
	 * 
	 * Date :- 09/04/2018
	 * 
	 * @author nitesh.yadav
	 * 
	 * @param customer
	 * 
	 * @return it will return the updated customer to the customerController
	 */
	public Customer updateCustomer(Customer customer) {
		return customerDAO.update(customer);
	}

	/**
	 * This method will provide the top five updates that are performed on the 
	 * application and stored in the database
	 * 
	 * @author yash.khanwilkar 
	 * @return List of updates in String format
	 */
	public List<String> getTopFiveUpdates() {
		return customerDAO.getTopFiveUpdates();
		
	}

	/**
	 * this method will return list of customers which are registered and return
	 * 
	 * @author chetan.magre
	 * @return list of customers
	 */
	public List<Customer> getListOfAllCustomers() {
		return customerDAO.getAllCustomers();
	}
}