package com.yash.ycmscore.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "article")
public class Article {

	@Id
	@GeneratedValue
	@Column(name = "id")
	private int id;

	@Column(name = "publishStatus")
	private String publishStatus;

	@Column(name = "trashStatus")
	private String trashStatus;

	@Column(name = "author")
	private String author;

	@Column(name = "fileName")
	private String fileName;

	@Column(name = "language")
	private String language;

	@Column(name = "tag")
	private String tag;

	@Column(name = "access")
	private String access;

	@Column(name = "hitCount")
	private int hitCount;

	private String alias;

	@Transient
	private String htmlContent;
	private String featureStatus;

	private String category;

	private Date datecreated;



	// for object creation
	public Article() {

	}

	public Article(int id, String publishStatus, String trashStatus, String author, String fileName, String language,
			String tag, String access, int hitCount, String alias, String htmlContent, String featureStatus,
			String category, Date datecreated, String trash) {

		this.id = id;
		this.publishStatus = publishStatus;
		this.trashStatus = trashStatus;
		this.author = author;
		this.fileName = fileName;
		this.language = language;
		this.tag = tag;
		this.access = access;
		this.hitCount = hitCount;
		this.alias = alias;
		this.htmlContent = htmlContent;
		this.featureStatus = featureStatus;
		this.category = category;
		this.datecreated = datecreated;


	}

	public int getId() {
		return id;
	}

	public String getPublishStatus() {
		return publishStatus;
	}

	public void setPublishStatus(String publishStatus) {
		this.publishStatus = publishStatus;
	}

	public String getTrashStatus() {
		return trashStatus;
	}

	public void setTrashStatus(String trashStatus) {
		this.trashStatus = trashStatus;
	}

	public void setAccess(String access) {
		this.access = access;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getTag() {
		return tag;
	}

	public void setTag(String tag) {
		this.tag = tag;
	}

	public String getFileName() {
		return fileName;
	}

	public String getAccess() {
		return access;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public int getHitCount() {
		return hitCount;
	}

	public void setHitCount(int hitCount) {
		this.hitCount = hitCount;
	}

	public String getAlias() {
		return alias;
	}

	public void setAlias(String alias) {
		this.alias = alias;
	}

	public String getHtmlContent() {
		return htmlContent;
	}

	public void setHtmlContent(String htmlContent) {
		this.htmlContent = htmlContent;
	}

	public String getFeatureStatus() {
		return featureStatus;
	}

	public void setFeatureStatus(String featureStatus) {
		this.featureStatus = featureStatus;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Date getDatecreated() {
		return datecreated;
	}

	public void setDatecreated(Date datecreated) {
		this.datecreated = datecreated;
	}
}
