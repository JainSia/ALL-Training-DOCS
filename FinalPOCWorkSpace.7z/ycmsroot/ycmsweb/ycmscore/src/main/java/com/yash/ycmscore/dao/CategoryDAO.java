package com.yash.ycmscore.dao;

import java.util.List;

import com.yash.ycmscore.model.Category;

/**
 * This interface will have methods for handling category related operations
 * such as listing all the categories.
 * 
 * 
 * @version 0.0.1
 * 
 * @since 14 April, 2018
 * 
 * @author aakash.jangid
 *
 */
public interface CategoryDAO {

	/**
	 * This method will fetch all the categories from the database and will be
	 * called whenever the list of the categories is required.
	 * 
	 * @author aakash.jangid
	 * 
	 * @return List<Category> - This method will return a List of Category.
	 */
	public List<Category> getAllCategories(int trashStatus);

	/**
	 * This method will change the trash status of the category. It will fetch the
	 * particular category with the help of the id passed as a parameter and then it
	 * will update the trash status of the category.
	 * 
	 * @param id:int it is the id of the category by which the category will be fetched.
	 * 
	 * @author aakash.jangid
	 * 
	 * @return boolean it will return true if the status has been updated
	 *         successfully else it will return false.
	 */
	public boolean changeTrashStatus(int id);
	
	/**
	 * this method will be used to add a Category to the database
	 * 
	 * @param category to add
	 * 
	 * @return true if Category is added successfully otherwise false in case of some error
	 * 
	 * @author minerva.shrivastava
	 */
	public boolean insert(Category category);

}