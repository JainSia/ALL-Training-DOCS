package com.yash.ycmscore.daoimpl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.yash.ycmscore.dao.CustomerDAO;
import com.yash.ycmscore.model.Customer;
import com.yash.ycmscore.model.Page;
import com.yash.ycmscore.util.SessionFactoryUtil;

/**
 * this is the implementation class for CustomerDAO interface
 * 
 * Date - 04/04/2018
 * 
 * @author ishan.juneja
 * @Repository annotation is used in your DAO layer and annotates classes that
 *             perform Database tasks
 */
@Repository
public class CustomerDAOImpl implements CustomerDAO {

	/**
	 * Connection reference to be used in the methods of the class
	 */
	Connection con;

	/**
	 * the sessionFactory which will give a session.
	 * 
	 * @Autowired annotation is auto wire the bean by matching data type.
	 */
	@Autowired
	private SessionFactory sessionFactory;
	/**
	 * this is util class object
	 * 
	 *  @Autowired annotation is auto wire the bean by matching data type.
	 */
	@Autowired
	private SessionFactoryUtil sessionFactoryUtil;

	/**
	 * Constructor to initialize connection object
	 * 
	 * @author ishan.juneja
	 * 
	 */
	public CustomerDAOImpl() {
		try {

			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/", "root", "root");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	/**
	 * this method will create a database and it's table such as pages with the
	 * name of the database provided to it
	 * 
	 * @author ishan.juneja
	 * @param name
	 *            of the database to be created
	 */
	public void createDatabase(String dbname) {

		try {

			Statement stmt = con.createStatement();
			stmt.executeUpdate("create database " + dbname);
			sessionFactoryUtil.getSessionFactoryForPassedDB(dbname);

		} catch (Exception e) {
			System.out.println(e);
		}
	}

	/**
	 * this method will return all dbnames
	 * 
	 * @author ishan.juneja
	 * @return list of all database names in mysql server
	 */
	public List<String> getAllDatabaseNames() {
		List<String> dbnames = new ArrayList<String>();
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("show databases");
			while (rs.next()) {
				dbnames.add(rs.getString(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dbnames;
	}

	/**
	 * this method will insert a new customer in the database which is passed to
	 * it
	 *
	 * @author chetan.magre
	 * @param customer
	 *            object will have details of new customer
	 * @return int value on successful or unsuccessful operation
	 */
	public int insert(Customer customer) {
		int status = 0;
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		Integer id = (Integer) session.save(customer);
		commitAndCloseSession(session);
		if (id != null)
			status = 1;
		return status;
	}

	/**
	 * this method is to check whether or not customer is in the database. or is
	 * registered or not
	 * 
	 * @author chetan.magre
	 * @param email
	 *            address of customer
	 * @return customer with its details from database
	 */
	public Customer isCustomerExist(String email) {
		Customer customer = null;
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		String sql = "FROM Customer WHERE email=:email";
		Query query = session.createQuery(sql);
		query.setString("email", email);
		customer = (Customer) query.uniqueResult();
		commitAndCloseSession(session);
		return customer;
	}

	/**
	 * this method is used to commit session and close the current session this
	 * is created to re-factor the code
	 * 
	 * @author chetan.magre
	 * @param session
	 */
	private void commitAndCloseSession(Session session) {
		session.getTransaction().commit();
		session.close();
	}

	/**
	 * This method will save the static page information such as
	 * (pageName,url,domainName) on the domain's database
	 * 
	 * @param page
	 *            object will have details of page which will be stored in
	 *            database
	 * @return int value on successful or unsuccessful operation
	 * @author yash.verma
	 */
	public int savePageContent(Page page) {
		int status = 0;
		try {
			Statement stmt = con.createStatement();
			stmt.executeUpdate("USE " + page.getDomainName());
			stmt.executeUpdate("INSERT INTO pages(domainName,pageName,url) values( '" + page.getDomainName() + "','"
					+ page.getPageName() + "','" + page.getUrl() + "')");
		} catch (Exception e) {
			System.out.println(e);
		}
		return status;
	}

	/**
	 * This method will give the url of the html page from database by checking
	 * the domainName and pageName (with extension) which are provided as
	 * parameters. if the url not found in the database by the provided
	 * parameters then PageUrlNotFoundException will be thrown
	 * 
	 * @param pageName
	 *            name of the page to be displayed
	 * @param domainName
	 *            name of the domain for which page to be displayed
	 * 
	 * @author shyam.patidar
	 * 
	 * @return String 'url' if success else return 'null'
	 * 
	 */
	public String getPageUrl(String pageName, String domainName) {
		Session session = sessionFactory.openSession();

		session.beginTransaction();
		Query query = session.createSQLQuery(
				"SELECT url FROM " + domainName + ".pages WHERE pageName=:pageName AND domainName=:domainName");
		query.setParameter("pageName", pageName.concat(".html"));
		query.setParameter("domainName", domainName);
		String url = (String) query.uniqueResult();
		return url;
	}

	/**
	 * this will be used for getting the customer according to login name
	 * 
	 * Date :- 06/04/2018
	 * 
	 * @author nitesh.yadav
	 * @param loginName
	 * @return it will return the customer to the customer service interface
	 */
	public Customer getCustomer(String loginName) {

		Session session = sessionFactory.openSession();
		session.beginTransaction();
		Query query = session.createSQLQuery("select id from customers where email=:loginName");
		query.setParameter("loginName", loginName);
		Integer id = (Integer) query.uniqueResult();
		Customer customer = (Customer) session.get(Customer.class, id);
		session.getTransaction().commit();
		return customer;

	}

	/**
	 * this will update the customer details in the customers table and will
	 * return the updated customer
	 * 
	 * Date :- 06/04/2018
	 * 
	 * @author nitesh.yadav
	 * @param customer
	 * @return it will return the updated customer
	 */
	public Customer update(Customer customer) {
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		Customer old = (Customer) session.get(Customer.class, customer.getId());
		old.setOrganization(customer.getOrganization());
		old.setAddress(customer.getAddress());
		old.setFirstName(customer.getFirstName());
		old.setLastName(customer.getLastName());
		old.setContact(customer.getContact());
		old.setCountry(customer.getCountry());
		old.setState(customer.getState());
		old.setCity(customer.getCity());
		old.setZip(customer.getZip());
		session.update(old);
		old = (Customer) session.get(Customer.class, old.getId());
		session.getTransaction().commit();
		session.close();
		return old;

	}

	/**
	 * this method is to get all the customers from the customer table with
	 * there details
	 * 
	 * @author chetan.magre
	 * @return customers list with there details from database
	 */
	@SuppressWarnings("unchecked")
	public List<Customer> getAllCustomers() {
		List<Customer> customers = null;
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		String sql = "FROM Customer";
		Query query = session.createQuery(sql);
		customers = (List<Customer>) query.list();
		commitAndCloseSession(session);
		return customers;
	}

	/**
	 * this method will update customer login detail each time customer logs in
	 * to YCMS such as date and time, whose email is provided as parameter
	 * 
	 * @author chetan.magre
	 * @param email
	 *            of current logged in customer
	 */
	public void updateCustomerLoginDateTime(String email) {
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		String sql = "UPDATE Customer SET lastLoginTime=:time,lastLoginDate=:date WHERE email= :email";
		Query query = session.createQuery(sql);
		query.setTime("time", new Date(System.currentTimeMillis()));
		query.setDate("date", new Date(System.currentTimeMillis()));
		query.setString("email", email);
		query.executeUpdate();
		commitAndCloseSession(session);
	}

	/**
	 * This method will give the top five updates that are done on the
	 * application from the database.
	 * 
	 * @author yash.khanwilkar
	 * @return List of all the updates that are done on the application in
	 *         string format.
	 */
	@SuppressWarnings("unchecked")
	public List<String> getTopFiveUpdates() {
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		Query query = session.createSQLQuery("SELECT updates FROM updates ORDER BY date DESC LIMIT 5");
		return (List<String>) query.list();
	}
}
