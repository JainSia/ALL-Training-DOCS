package com.yash.ycmscore.serviceimpl;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.ycmscore.dao.ArticleDAO;
import com.yash.ycmscore.model.Article;
import com.yash.ycmscore.service.ArticleService;

@Service
public class ArticleServiceImpl implements ArticleService {

	@Autowired
	private ArticleDAO articleDAO;

	public String createNewArticle(Article article, String domain) {

		// set a by default language
		if (article.getLanguage() == null) {
			article.setLanguage("EN");
		}

		String metatags = "";
		if (article.getTag() != "") {
			metatags = getTags(article.getTag());
		}

		String path = System.getProperty("catalina.base") + "\\webapps\\" + domain+"\\"+article.getCategory();
		
		if(!new File(path).isDirectory()){
			new File(path).mkdir();
		}
		
		File file = new File(path + "\\" + article.getFileName().replaceAll(" ", "-") + ".html");
		
		System.out.println("--------------file created"+path);
		String doctypestart = "<!DOCTYPE html> <html language=" + "\"" + article.getLanguage() + "\">"
				+ "<head> <meta charset=\"UTF-8\"> <title>" + article.getFileName() + "</title>" + metatags + "</head>";
		String doctypeend = "</html>";
		try {
			file.createNewFile();
			Writer writer = new FileWriter(file);
			BufferedWriter bufferedWriter = new BufferedWriter(writer);
			bufferedWriter.write(doctypestart);
			bufferedWriter.write("<body>" + article.getHtmlContent() + "</body>");
			bufferedWriter.write(doctypeend);
			bufferedWriter.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return articleDAO.createNewArticle(article, domain);
	}

	public List<String> getAllArticles(String domain) {
		return articleDAO.getAllArticles(domain);
	}

	private String getTags(String tagstring) {

		Map<String, String> tagmap = new HashMap<String, String>();
		String[] parts = tagstring.split(",");

		for (String tag : parts) {
			String[] t = tag.split(":");
			tagmap.put(t[0], t[1]);
		}

		StringBuilder sb = new StringBuilder();
		for (String s : tagmap.keySet()) {
			sb.append("<meta name=\"" + s + "\" content=\"" + tagmap.get(s) + "\">");
		}

		return sb.toString();
	}

	public List<Article> getListOfArticles(Article article, String domain) {

		if (article.getTag() == null)
			article.setTag("");
		if (article.getAccess() == null)
			article.setAccess("");
		if (article.getAuthor() == null)
			article.setAuthor("");
		if (article.getPublishStatus() == null)
			article.setPublishStatus("");
		if (article.getFileName() == null)
			article.setFileName("");
		if (article.getLanguage() == null)
			article.setLanguage("");
		return articleDAO.listArticles(article, domain);
	}

	public List<Article> getAllUntrashedArticles(String domain) {
		return articleDAO.getAllUntrashedArticles(domain);
	}

	public boolean changeStatusToTrashStatus(int id, String domain) {
		return articleDAO.changeStatusToTrashStatus(id, domain);
	}

	public boolean changeStatusToUntrashStatus(int id, String domain) {
		return articleDAO.changeStatusToUntrashStatus(id, domain);
	}

	public boolean changeStatusToPublishStatus(int id, String domain) {
		return articleDAO.changeStatusToPublishStatus(id, domain);
	}

	public boolean changeStatusToUnpublishStatus(int id, String domain) {
		return articleDAO.changeStatusToUnpublishStatus(id, domain);
	}

	public int deleteArticle(int id, String domain) {
		return articleDAO.deleteArticle(id, domain);
	}

	public boolean changeStatusToUnFeatured(int id, String domain) {

		return articleDAO.changeStatusToUnFeatured(id, domain);
	}

	public boolean changeStatusToFeatured(int id, String domain) {

		return articleDAO.changeStatusToFeatured(id, domain);
	}

	public List<Article> getAllTrashedArticles(String domain) {
		
		return articleDAO.getAllTrashedArticles(domain);
	}

	public String getDocumentToEdit(String domain, String fileName, String category) {
		
		String path = System.getProperty("catalina.base")+"\\webapps\\"+domain+"\\"+category+"\\"+fileName+".html";
		
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(path));
	        StringBuilder sb = new StringBuilder();
	        String line = br.readLine();

	        while (line != null) {
	            sb.append(line);
	            
	            line = br.readLine();
	        }
	        br.close();
	        return sb.toString();
	    } catch (IOException e) {
			e.printStackTrace();
		}
		return "<h6>unable to read page</h6>";
	}

	public Article getArticleByName(String domain,String fileName) {
		
		return articleDAO.getArticleByName(domain,fileName);
	}

}
