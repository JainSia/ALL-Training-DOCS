package com.yash.ycmsweb.controller;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.yash.ycmscore.model.Article;
import com.yash.ycmscore.model.Customer;
import com.yash.ycmscore.model.Token;
import com.yash.ycmscore.service.ArticleService;
import com.yash.ycmscore.service.CustomerService;

import io.jsonwebtoken.Claims;

/**
 * this is the Controller that will handle the requests for the Article related
 * resources
 * 
 * Date - 04/16/2018
 * 
 * @author mayank
 *
 */
@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class ArticleController {

	/**
	 * this will be the bean which will give the methods of ArticleService to
	 * the controller
	 */
	@Autowired
	private ArticleService articleService;

	/**
	 * this will be the bean which will give the methods of CustomerService to
	 * the controller
	 */
	@Autowired
	private CustomerService customerService;

	/**
	 * this method will be used to create a new article in the directory named
	 * as the domain when user registered for the application
	 * 
	 * @author ishan.juneja
	 * 
	 * @param article
	 * @param httpRequest
	 * @return
	 */
	@RequestMapping(value = "/articles", method = RequestMethod.POST)
	public String createNewArticle(@RequestBody Article article, HttpServletRequest httpRequest) {
		article.setAlias(article.getFileName().replaceAll(" ", "-"));
		return articleService.createNewArticle(article, getCustomer(httpRequest).getDomainName());
	}

	/**
	 * this method will get the article name availability from database
	 * 
	 * @author ishan.juneja
	 * 
	 * @param articlename
	 * @param httpRequest
	 * @return
	 */
	@RequestMapping(value = "/articles/getarticle/{articlename}", method = RequestMethod.GET)
	@ResponseBody
	public String getDBAvailablity(@PathVariable String articlename, HttpServletRequest httpRequest) {

		List<String> articles = articleService.getAllArticles(getCustomer(httpRequest).getDomainName());

		for (String article : articles) {
			if (articlename.equalsIgnoreCase(article)) {
				return "article exists";
			}
		}

		return "available";
	}

	/**
	 * this method will be used to take out the customer details from the
	 * authorization header
	 * 
	 * @author ishan.juneja
	 * 
	 * @param httpRequest
	 * @return
	 */
	public Customer getCustomer(HttpServletRequest httpRequest) {
		Token token = null;
		Customer customer = null;
		Claims claims = (Claims) httpRequest.getAttribute("claims");
		ObjectMapper mapper = new ObjectMapper();
		try {
			token = mapper.readValue(claims.getSubject(), Token.class);
			customer = customerService.getCustomer(token.getEmail());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return customer;
	}

	@RequestMapping(value = "/articles/article/image", method = RequestMethod.POST, consumes = {
			"multipart/form-data" })
	public void getImage(@RequestParam MultipartFile file) {

		Path rootLocation = Paths.get("D:\\finalprojectws\\YCMS-cli\\src\\assets\\images");
		try {
			Files.copy(file.getInputStream(), rootLocation.resolve(file.getOriginalFilename()));
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	/**
	 * this method will search the articles on the basis of parameters passed
	 * from front end
	 * 
	 * @author mayank
	 * @param article
	 *            - to accept data from front
	 * @param httpRequest
	 *            - to get the domain name to get connection with the d.b
	 * @return
	 */
	@RequestMapping(value = "searchArticles", method = RequestMethod.POST)
	public List<Article> searchHandler(@RequestBody Article article, HttpServletRequest httpRequest) {

		
		return articleService.getListOfArticles(article, getCustomer(httpRequest).getDomainName());


	}

	/**
	 * this method will change the status from trashed to untrashed.
	 * 
	 * @author mayank
	 * @param article
	 *            - to accept data from front
	 * @param httpRequest
	 *            - to get the domain name to get connection with the d.b
	 * @return
	 */
	@RequestMapping(value = "changeStatusToUntrash", method = RequestMethod.POST)
	public boolean changeTrashedStatusToUntrashed(@RequestBody Article article, HttpServletRequest httpRequest) {

		return articleService.changeStatusToUntrashStatus(article.getId(), getCustomer(httpRequest).getDomainName());

	}

	/**
	 * this method will change the status from publish to unPublish.
	 * 
	 * @author mayank
	 * @param article
	 *            - to accept data from front
	 * @param httpRequest
	 *            - to get the domain name to get connection with the d.b
	 * @return
	 */
	@RequestMapping(value = "changeStatusToUnpublish", method = RequestMethod.POST)
	public boolean changePublishedStatusToUnpublish(@RequestBody Article article, HttpServletRequest httpRequest) {
		System.out.println(article.getId());
		return articleService.changeStatusToUnpublishStatus(article.getId(), getCustomer(httpRequest).getDomainName());

	}

	/**
	 * this method will change the status to trashed.
	 * 
	 * @author mayank
	 * @param article
	 *            - to accept data from front
	 * @param httpRequest
	 *            -to get the domain name to get connection with the d.b
	 * @return
	 */
	@RequestMapping(value = "changeStatusToTrash", method = RequestMethod.POST)
	public boolean changeUntrashedStatusToTrash(@RequestBody Article article, HttpServletRequest httpRequest) {

		return articleService.changeStatusToTrashStatus(article.getId(), getCustomer(httpRequest).getDomainName());

	}

	/**
	 * this method will change the status from unfeatured to featured.
	 * 
	 * @author mayank
	 * @param article
	 *            - to accept data from front
	 * @param httpRequest
	 *            - to get the domain name to get connection with the d.b
	 * @return
	 */
	@RequestMapping(value = "changeStatusToFeature", method = RequestMethod.POST)
	public boolean changeUntrashedStatusToFeature(@RequestBody Article article, HttpServletRequest httpRequest) {

		return articleService.changeStatusToFeatured(article.getId(), getCustomer(httpRequest).getDomainName());

	}

	/**
	 * this method will change the status from featured to unfeatured.
	 * 
	 * @author mayank
	 * @param article
	 *            - to accept data from front
	 * @param httpRequest
	 *            - to get the domain name to get connection with the d.b
	 * @return
	 */
	@RequestMapping(value = "changeStatusToUnfeature", method = RequestMethod.POST)
	public boolean changeUntrashedStatusToUnfeature(@RequestBody Article article, HttpServletRequest httpRequest) {

		return articleService.changeStatusToUnFeatured(article.getId(), getCustomer(httpRequest).getDomainName());

	}

	/**
	 * this method will delete the article on the basis of id.
	 * 
	 * @author mayank
	 * @param article
	 *            - to accept data from front
	 * @param httpRequest
	 *            - to get the domain name to get connection with the d.b
	 * @return
	 */

	@RequestMapping(value = "deleteArticle", method = RequestMethod.POST)
	public int deleteArticle(@RequestBody Article article, HttpServletRequest httpRequest) {

		return articleService.deleteArticle(article.getId(), getCustomer(httpRequest).getDomainName());

	}

	/**
	 * this method will change the status to publish
	 * 
	 * @author mayank
	 * @param article
	 *            - to accept data from front
	 * @param httpRequest
	 *            - to get the domain name to get connection with the d.b
	 * @return
	 */
	@RequestMapping(value = "changeStatusToPublish", method = RequestMethod.POST)
	public boolean changeUnpublishStatusToPublish(@RequestBody Article article, HttpServletRequest httpRequest) {
		return articleService.changeStatusToPublishStatus(article.getId(), getCustomer(httpRequest).getDomainName());

	}

	/**
	 * this method will return the list of untrashed articles in json format.
	 * 
	 * @author mayank
	 * @param httpRequest
	 *            - to get the domain name to get connection with the d.b
	 * @return
	 */
	@RequestMapping(value = "getUntrashedArticles", method = RequestMethod.GET)
	public List<Article> getAllUntrashedArticles(HttpServletRequest httpRequest) {


		return articleService.getAllUntrashedArticles(getCustomer(httpRequest).getDomainName());

	}

	@RequestMapping(value = "getFeatureArticles", method = RequestMethod.GET)
	public List<Article> getAllFeaturedArticles(HttpServletRequest httpRequest) {
		
		return articleService.getAllFeaturedArticles(getCustomer(httpRequest).getDomainName());
	}
	
	@RequestMapping(value = "getTrashedArticles", method = RequestMethod.GET)
	public List<Article> getAllTrashedArticles(HttpServletRequest httpRequest) {

		return articleService.getAllTrashedArticles(getCustomer(httpRequest).getDomainName());

	}
	
	@RequestMapping(value = "editArticle" , method = RequestMethod.POST)
	public Article editArticle(@RequestBody Article article,HttpServletRequest httpRequest){
		String domain = getCustomer(httpRequest).getDomainName();
		Article temparticle = articleService.getArticleByName(domain,article.getFileName());
		String html=articleService.getDocumentToEdit(domain,article.getFileName(),temparticle.getCategory());
		temparticle.setHtmlContent(html);
		return temparticle;
	
	}
	
	@RequestMapping(value="openpage/{title}",method=RequestMethod.GET)
	public String openPage(@PathVariable String title,HttpServletRequest httpRequest){
		String domain = getCustomer(httpRequest).getDomainName();
		Article article=articleService.getArticleByName(domain, title);
		String hostname="localhost";
		
			try {
				hostname=InetAddress.getLocalHost().getHostName();
			} catch (UnknownHostException e) {
				e.printStackTrace();
			}
		return "http://"+hostname+":8080/"+domain+"/"+article.getCategory()+"/"+title+".html";
		
	}
	
	
}
