package com.yash.ycmsweb.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.yash.ycmscore.exception.InvalidFileTypeException;
import com.yash.ycmscore.model.Video;
import com.yash.ycmscore.service.VideoService;

/**
 * This class controls the operations related to the video <br>
 * <br>
 * 
 * Date - 13/04/2018
 * 
 * @author harmeet.saluja
 *
 */
@RestController
@RequestMapping(value = "/videos")
@CrossOrigin(origins = "http://localhost:4200")
public class VideoUploadController {

	Logger log = Logger.getLogger(this.getClass().getName());

	/**
	 * The bean will provide the methods of the VideoService to the controller
	 */
	@Autowired
	VideoService videoService;

	/**
	 * This method will save the video to a particular location and save it's
	 * details to the database
	 * 
	 * @author harmeet.saluja
	 * @param file
	 *            Video that is to be saved
	 * @param title
	 *            title of the video
	 */
	@RequestMapping(value = "/savevideo", method = RequestMethod.POST)
	public void saveVideo(@RequestParam("file") MultipartFile file, @RequestPart("title") String title) {
		if (!file.getContentType().equals("video/mp4"))
			try {
				throw new InvalidFileTypeException("The file is not of type mp4.");
			} catch (InvalidFileTypeException e) {
				log.info(e.getMessage());
			}
		else {
			videoService.store(file, title);
		}
	}

	/**
	 * This method will fetch the details of all the videos in the database
	 * 
	 * @author harmeet.saluja
	 * @return the list of videos
	 */
	@RequestMapping(value = "/videosList", method = RequestMethod.GET)
	public List<Video> getVideosList() {
		return videoService.videosList();
	}
}
