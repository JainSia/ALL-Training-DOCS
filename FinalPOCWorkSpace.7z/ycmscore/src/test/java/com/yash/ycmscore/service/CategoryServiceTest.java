package com.yash.ycmscore.service;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import org.hibernate.HibernateException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.yash.ycmscore.daoimpl.CategoryDAOImpl;
import com.yash.ycmscore.model.Category;
import com.yash.ycmscore.serviceimpl.CategoryServiceImpl;

public class CategoryServiceTest {

	@Mock
	CategoryDAOImpl categoryDAO;
	
	@InjectMocks
	CategoryServiceImpl categoryService;
	
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void test_addCategory_method_with_actual_catgory_object() {

		when(categoryDAO.insert(any(Category.class),any(String.class))).thenReturn(true);
		Category category = new Category();
		assertThat(categoryService.addCategory(category, "dbname"), is(true));

	}
	
	@Test(expected = HibernateException.class)
	public void test_addCategory_method_with_null_category_object() {

		doThrow(HibernateException.class).when(categoryDAO).insert(null, null);
		Category category = null;
		categoryService.addCategory(category,null);

	}

}
