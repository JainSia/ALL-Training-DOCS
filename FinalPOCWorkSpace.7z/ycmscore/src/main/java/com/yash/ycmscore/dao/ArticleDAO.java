package com.yash.ycmscore.dao;

import java.util.List;

import com.yash.ycmscore.model.Article;

/**
 * this interface will provide the database related functionality for Articles
 * in the application
 * 
 * @version 0.0.1
 * 
 * @since 14 April, 2018
 * 
 * @author mayank
 *
 */
public interface ArticleDAO {

	/**
	 * this method will insert the information of an article in the database
	 * 
	 * @return not available if the alias or the document is present previously
	 *         in the database
	 */
	public String createNewArticle(Article article, String domain);

	/**
	 * this method will get a list of all the articles in the database
	 * 
	 * @author ishan.juneja
	 * 
	 * @param domain
	 * @return
	 */
	public List<String> getAllArticles(String domain);

	/**
	 * this method will search the articles on the basis of parameters passed
	 * from front end and get called whenever required
	 * 
	 * @author mayank
	 * @param article
	 *            - to travel the data
	 * @param domain
	 *            - name of the db to get connection with
	 * @return list of articles
	 */

	public List<Article> listArticles(Article article, String domain);

	/**
	 * This method will change the article status in the database and will be
	 * called whenever required.
	 * 
	 * @author mayank
	 * @param domain
	 *            : name of the db
	 * @param id
	 *            : id of the article
	 * @return boolean true or false
	 */

	public boolean changeStatusToTrashStatus(int id, String domain);

	/**
	 * This method will change the article status in the database and will be
	 * called whenever required.
	 * 
	 * @author mayank
	 * @param domain
	 *            : name of the db
	 * @param id
	 *            : id of the article
	 * @return boolean true or false
	 */

	public boolean changeStatusToUntrashStatus(int id, String domain);

	/**
	 * This method will change the article status in the database and will be
	 * called whenever required.
	 * 
	 * @author mayank
	 * @param domain
	 *            : name of the db
	 * @param id
	 *            : id of the article
	 * @return boolean true or false
	 */

	public boolean changeStatusToPublishStatus(int id, String domain);

	/**
	 * This method will change the article status in the database and will be
	 * called whenever required.
	 * 
	 * @author mayank
	 * @param domain
	 *            : name of the db
	 * @param id
	 *            : id of the article
	 * @return boolean true or false
	 */

	public boolean changeStatusToUnpublishStatus(int id, String domain);

	/**
	 * This method will change the article status in the database and will be
	 * called whenever required.
	 * 
	 * @author mayank
	 * @param domain
	 *            : name of the db
	 * @param id
	 *            : id of the article
	 * @return boolean true or false
	 */

	public boolean changeStatusToUnFeatured(int id, String domain);

	/**
	 * This method will change the article status in the database and will be
	 * called whenever required.
	 * 
	 * @author mayank
	 * @param domain
	 *            : name of the db
	 * @param id
	 *            : id of the article
	 * @return boolean true or false
	 */

	public boolean changeStatusToFeatured(int id, String domain);

	/**
	 * This method will delete the article from the database and will be called
	 * whenever required.
	 * 
	 * @author mayank
	 * @param domain
	 *            : name of the db
	 * @param id
	 *            : of the article to be deleted
	 * 
	 * @return int
	 */

	public int deleteArticle(int id, String domain);

	/**
	 * This method will fetch all the untrashed articles from the database and
	 * will be called whenever the list of the articles is required.
	 * 
	 * @author mayank
	 * @param domain
	 *            : name of the db
	 * @return List<Article> - This method will return a List of untrashed
	 *         articles.
	 */

	public List<Article> getAllUntrashedArticles(String domain);
	
	/**
	 * This method will fetch all the trashed articles from the database and
	 * will be called whenever the list of the articles is required.
	 * 
	 * @author mayank
	 * @param domain
	 *            : name of the db
	 * @return List<Article> - This method will return a List of trashed
	 *         articles.
	 */
	public List<Article> getAllTrashedArticles(String domain);

	public List<Article> getAllFeaturedArticles(String domainName);

	public Article getArticleByName(String domain, String fileName);

}
