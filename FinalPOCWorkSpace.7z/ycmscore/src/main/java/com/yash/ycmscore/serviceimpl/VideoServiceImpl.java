package com.yash.ycmscore.serviceimpl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.yash.ycmscore.dao.VideoDAO;
import com.yash.ycmscore.model.Video;
import com.yash.ycmscore.service.VideoService;

/**
 * This class implements all the methods present in VideoService interface<br>
 * <br>
 * 
 * Date - 13/04/2018
 * 
 * @author harmeet.saluja
 * @Service annotation is used in your service layer and annotates classes that
 *          perform service tasks
 */

@Service
public class VideoServiceImpl implements VideoService {

	Logger log = Logger.getLogger(this.getClass().getName());

	/**
	 * The rootLocation represents the root path where all the uploaded files
	 * will be saved.
	 */
	private Path rootLocation = null;
	
	/**
	 * this is the videoDAO bean needed in service
	 * 
	 * @Autowired annotation is auto wire the bean by matching data type.
	 */
	@Autowired
	private VideoDAO videoDAO;

	/**
	 * This method is used to set the path where the videos will be saved(in the
	 * asset/videos folder of YCMS-cli app)
	 * 
	 * @author harmeet.saluja
	 */
	private void setPath() {
		String catalinaBase = System.getProperty("catalina.base");
		String applicationPath = "\\webapps\\ycms\\assets\\videos";
		this.rootLocation = Paths.get(catalinaBase, applicationPath);
	}

	/**
	 * This method saves the Video File at a particular location.
	 * 
	 * @author harmeet.saluja
	 * @param file
	 *            File that is to be saved at a given location
	 * @param title
	 *            unique title of the file that will be saved inside the
	 *            database
	 * @return true if the file is saved successfully, else returns false
	 */
	public boolean store(MultipartFile file, String title) {
		setPath();
		try {
			Files.copy(file.getInputStream(), this.rootLocation.resolve(file.getOriginalFilename()));
			Video videoToBeSaved = new Video();
			videoToBeSaved.setPath(file.getOriginalFilename());
			videoToBeSaved.setTitle(title);
			videoDAO.saveVideoDetails(videoToBeSaved);
			log.info("Video Details Saved");
			return true;
		} catch (Exception e) {
			log.error("Failed" + e.getMessage());
			return false;
		}
	}

	/**
	 * This method will use the will call the method of the userDAO to get the
	 * list of videos.
	 * 
	 * @author harmeet.saluja
	 * @return the list of the videos
	 */
	public List<Video> videosList() {
		return videoDAO.videosList();
	}

}
