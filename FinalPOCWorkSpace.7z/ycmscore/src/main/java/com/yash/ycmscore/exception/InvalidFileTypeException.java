package com.yash.ycmscore.exception;

/**
 * This class is an exception class that will be used to throw the exception
 * whenever the uploaded file is not of type mp4.
 * 
 * Date - 13/04/2018
 * 
 * @author harmeet.saluja
 *
 */
public class InvalidFileTypeException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * constructor for the class
	 * 
	 * @author harmeet.saluja
	 * @param message
	 *            message that will be displayed whenever the exception will be
	 *            thrown
	 */
	public InvalidFileTypeException(String message) {
		super(message);
	}

}
