package com.yash.ycmscore.daoimpl;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.yash.ycmscore.dao.ArticleDAO;
import com.yash.ycmscore.model.Article;
import com.yash.ycmscore.model.Category;
import com.yash.ycmscore.util.SessionFactoryUtil;

@Repository
public class ArticleDAOImpl implements ArticleDAO {

	/**
	 * the sessionFactory which will give a session.
	 * 
	 * @Autowired annotation is auto wire the bean by matching data type.
	 */
	@Autowired
	private SessionFactoryUtil sessionFactoryUtil;

	/**
	 * this method will create a new article information for the passed article
	 * in the database
	 * 
	 * @author ishan.juneja
	 */
	public String createNewArticle(Article article, String domain) {
		article.setDatecreated(new Date(new java.util.Date().getTime()));
		SessionFactory factory = sessionFactoryUtil.getSessionFactoryForPassedDB(domain);
		Session session = factory.openSession();
		session.beginTransaction();
		article.setCategoryid(getCategoryByName(article.getCategory(), domain));
		Article temparticle = getArticleByName(domain, article.getFileName());
		if(temparticle!=null) {
			article.setId(temparticle.getId());
		}
		session.saveOrUpdate(article);
		session.getTransaction().commit();
		session.close();
		factory.close();
		return "article saved";
	}

	/**
	 * this method will return a list of all the articles in the database
	 */
	public List<String> getAllArticles(String domain) {
		List<String> articles;
		final SessionFactory factory = sessionFactoryUtil.getSessionFactoryForPassedDB(domain);
		Session session = factory.openSession();
		session.beginTransaction();
		Criteria criteria = session.createCriteria(Article.class);
		articles = criteria.setProjection(Projections.property("fileName")).list();
		session.getTransaction().commit();
		session.close();
		factory.close();
		return articles;
	}

	public List<Article> listArticles(Article article, String domain) {
	
			List<Article> list = new ArrayList<Article>();
			SessionFactory factory = sessionFactoryUtil.getSessionFactoryForPassedDB(domain);
			Session session = factory.openSession();
			session.beginTransaction();
			Criteria criteria = session.createCriteria(Article.class);
			criteria.add(Restrictions.like("access", article.getAccess() + "%"));
			criteria.add(Restrictions.like("author", article.getAuthor() + "%"));
			criteria.add(Restrictions.like("tag", article.getTag() + "%"));
			criteria.add(Restrictions.like("publishStatus", article.getPublishStatus() + "%"));
			criteria.add(Restrictions.like("language", article.getLanguage() + "%"));
			criteria.add(Restrictions.like("featureStatus", article.getFeatureStatus() + "%"));
			criteria.add(Restrictions.like("fileName", article.getFileName() + "%"));
			list = criteria.list();
			session.getTransaction().commit();
			return list;
		
	
		
	}

	public boolean changeStatusToTrashStatus(int id, String domain) {
		SessionFactory factory = sessionFactoryUtil.getSessionFactoryForPassedDB(domain);
		Session session = factory.openSession();
		session.beginTransaction();
		Article article = (Article) session.get(Article.class, id);
		if (article.getTrashStatus().equalsIgnoreCase("untrashed")) {
			article.setTrashStatus("trashed");
			session.saveOrUpdate(article);
			session.getTransaction().commit();
			session.close();
			factory.close();
			return true;
		}
		session.getTransaction().commit();
		session.close();
		factory.close();
		return false;
	}

	public boolean changeStatusToUntrashStatus(int id, String domain) {
		SessionFactory factory = sessionFactoryUtil.getSessionFactoryForPassedDB(domain);
		Session session = factory.openSession();
		session.beginTransaction();
		Article article = (Article) session.get(Article.class, id);
		if (article.getTrashStatus().equalsIgnoreCase("trashed")) {
			article.setTrashStatus("untrashed");
			session.saveOrUpdate(article);
			session.getTransaction().commit();
			session.close();
			factory.close();
			return true;
		}
		session.getTransaction().commit();
		session.close();
		factory.close();
		return false;
	}

	public boolean changeStatusToPublishStatus(int id, String domain) {
		SessionFactory factory = sessionFactoryUtil.getSessionFactoryForPassedDB(domain);
		Session session = factory.openSession();
		session.beginTransaction();
		Article article = (Article) session.get(Article.class, id);
		if (article != null) {
			article.setPublishStatus("published");
			session.save(article);
			session.getTransaction().commit();
			session.close();
			factory.close();
			return true;
		}
		session.getTransaction().commit();
		session.close();
		factory.close();
		return false;
	}

	public boolean changeStatusToUnpublishStatus(int id, String domain) {
		SessionFactory factory = sessionFactoryUtil.getSessionFactoryForPassedDB(domain);
		Session session = factory.openSession();
		session.beginTransaction();
		Article article = (Article) session.get(Article.class, id);

		if (article.getPublishStatus().equalsIgnoreCase("published")) {
			article.setPublishStatus("unpublished");
			session.save(article);
			session.getTransaction().commit();
			session.close();
			factory.close();
			return true;
		}
		session.getTransaction().commit();
		session.close();
		factory.close();
		return false;
	}

	public List<Article> getAllUntrashedArticles( String domain) {
		List<Article> articles = new ArrayList<Article>();
		SessionFactory factory = sessionFactoryUtil.getSessionFactoryForPassedDB(domain);
		Session session = factory.openSession();
		session.beginTransaction();
		Query query = session.createQuery("from Article where trashStatus=:trashStatus");
		query.setString("trashStatus", "untrashed");
		articles = query.list();
		session.getTransaction().commit();
		session.close();
		factory.close();
		return articles;
	}

	public List<Article> getAllTrashedArticles(String domain) {
		List<Article> articles = new ArrayList<Article>();
		SessionFactory factory = sessionFactoryUtil.getSessionFactoryForPassedDB(domain);
		Session session = factory.openSession();
		session.beginTransaction();
		Query query = session.createQuery("from Article where trashStatus=:trashStatus");
		query.setString("trashStatus", "trashed");
		articles = query.list();
		session.getTransaction().commit();
		session.close();
		factory.close();
		return articles;
	}

	public int deleteArticle(int id, String domain) {
		SessionFactory factory = sessionFactoryUtil.getSessionFactoryForPassedDB(domain);
		Session session = factory.openSession();
		session.beginTransaction();
		int result = 0;
		Article article = (Article) session.get(Article.class, id);
		if (article != null) {
			session.delete(article);
			session.getTransaction().commit();
			session.close();
			factory.close();
			return result + 1;
		}
		session.getTransaction().commit();
		session.close();
		factory.close();
		return result;
	}

	public boolean changeStatusToFeatured(int id, String domain) {
		SessionFactory factory = sessionFactoryUtil.getSessionFactoryForPassedDB(domain);
		Session session = factory.openSession();
		session.beginTransaction();
		Article article = (Article) session.get(Article.class, id);
		System.out.println(article);
		if (!article.getFeatureStatus().equals(null) && article.getFeatureStatus().equalsIgnoreCase("No")) {
			article.setFeatureStatus("yes");
			session.saveOrUpdate(article);
			session.getTransaction().commit();
			session.close();
			factory.close();
			return true;
		}
		session.getTransaction().commit();
		session.close();
		factory.close();
		return false;
	}

	public boolean changeStatusToUnFeatured(int id, String domain) {
		SessionFactory factory = sessionFactoryUtil.getSessionFactoryForPassedDB(domain);
		Session session = factory.openSession();
		session.beginTransaction();
		Article article = (Article) session.get(Article.class, id);
		if (!article.getFeatureStatus().equals(null) && article.getFeatureStatus().equalsIgnoreCase("Yes")) {
			article.setFeatureStatus("No");
			session.saveOrUpdate(article);
			session.getTransaction().commit();
			session.close();
			factory.close();
			return true;
		}
		session.getTransaction().commit();
		session.close();
		factory.close();
		return false;
	}
	
	private Category getCategoryByName(String category,String domain){
		SessionFactory factory = sessionFactoryUtil.getSessionFactoryForPassedDB(domain);
		Session session = factory.openSession();
		session.beginTransaction();
		Query query = session.createQuery("FROM Category WHERE title=:category");
		query.setString("category", category);
		Category categoryObtain=(Category) query.uniqueResult();
		session.getTransaction().commit();
		session.close();
		factory.close();
		return categoryObtain;
	}
	
	public Article getArticleByName(String domain,String fileName) {
		SessionFactory factory = sessionFactoryUtil.getSessionFactoryForPassedDB(domain);
		Session session = factory.openSession();
		session.beginTransaction();
		Query query = session.createQuery("FROM Article where fileName=?");
		query.setString(0, fileName);
		Article article = (Article) query.uniqueResult();
		session.getTransaction().commit();
		session.close();
		factory.close();
		return article;
	}

	public List<Article> getAllFeaturedArticles(String domainName) {
		List<Article> articles = new ArrayList<Article>();
		SessionFactory factory = sessionFactoryUtil.getSessionFactoryForPassedDB(domainName);
		Session session = factory.openSession();
		session.beginTransaction();
		Query query = session.createQuery("from Article where featureStatus=:featureStatus");
		query.setString("featureStatus", "yes");
		articles = query.list();
		session.getTransaction().commit();
		session.close();
		factory.close();
		return articles;
	}

}
