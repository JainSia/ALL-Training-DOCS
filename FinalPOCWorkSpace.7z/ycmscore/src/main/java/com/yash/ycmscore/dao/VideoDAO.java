package com.yash.ycmscore.dao;

import java.util.List;

import com.yash.ycmscore.model.Video;

/**
 * This interface is used to provide the database operations related to the
 * Video such as saving the details of the video into the database, list the
 * details of videos etc.
 * 
 * Functionalities provided- 1) Save details of Video. 2) Get Video details
 * Lists <br>
 * <br>
 * Date - 13/04/2018
 * 
 * @author harmeet.saluja
 *
 */
public interface VideoDAO {

	/**
	 * Save the details of the video into the database
	 * 
	 * @author harmeet.saluja
	 * @param video
	 *            video whose details are to be saved into the database
	 * @return true if the details are saved successfully, else returns false
	 */
	public boolean saveVideoDetails(Video video);

	/**
	 * This method gets the details of all the videos that are present in the
	 * database.
	 * 
	 * @author harmeet.saluja
	 * @return The list of Videos
	 */
	public List<Video> videosList();

}
