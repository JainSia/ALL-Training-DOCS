package com.yash.numbertest;
/*
 * this is a test case for PositiveOrNegativeNumber
 */
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class PositiveOrNegativeNumberTest {
	/*
	 * Input Array
	 */
public final int testArray[]={1,2,-2,-3,-4,3,4,5,6,7,8,9,10,-12,-15};
/*
 * this is a test case to verify total positive, total Negative, 
 * total Even and total Odd numbers in the array
 */
	
	@Test
	public void test_number() {
		PositiveOrNegativeNumber number = new PositiveOrNegativeNumber();
		String Result=number.numberProperties(testArray);
		assertEquals("positive :5 negative :10even :8odd :7", Result);
	}

}
