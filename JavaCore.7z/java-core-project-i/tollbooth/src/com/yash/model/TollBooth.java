package com.yash.model;
/**
 * this is the TollBooth model class
 * @author ishan.juneja
 *
 */
public class TollBooth {
	/**
	 * it is the count of all the paying cars passing through the toll booth
	 */
	private int payingcars;
	/**
	 * it is the count of all the Non paying cars passing through the toll booth
	 */
	private int nonpayingcars;
	/**
	 * it is the amount collected from all the paying cars passing through the toll booth
	 */
	private Double amount;
	/**
	 * it is the constructor that initializes the counts to zero
	 */
	public TollBooth(){
		payingcars=0;
		nonpayingcars=0;
		amount=0.0;
	}
/**
 *this method increments the paying car count and adds an amount of money to the total amount collected 
 *when a paying car passes the toll booth
 */
	public void payingCar(){
		payingcars++;
		amount=amount+0.50;
	}
	/**
	 * this method increments the count of non paying cars passing the toll booth which did not pay at toll booth
	 */
	public void noPayCar(){
		nonpayingcars++;
	}
	/**
	 * this method displays the total number of paying cars, the total number of non paying cars 
	 * and total amount collected from the toll booth
	 */
	public void display(){
		System.out.println("total paying cars passed ="+payingcars);
		System.out.println("total non paying cars passed ="+nonpayingcars);
		System.out.println("total amount colected ="+amount);
	}
}
