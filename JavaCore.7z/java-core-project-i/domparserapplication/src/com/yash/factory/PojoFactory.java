package com.yash.factory;
/**
 * this is the POJO factory class. 
 * It contains an array of all POJO objects and returns the specific object demanded.
 */
import com.yash.pojo.Application;

public class PojoFactory {
	/**
	 * this is the Array of POJO objects initialized from LoadPojoXml class
	 */
	Object[] pojos;
	/**
	 * this Constructor initializes the Object array of POJOs
	 * @param pojos
	 */
	public PojoFactory(Object[] pojos) {
		this.pojos=pojos;
	}
/**
 * this method searches in the POJO array for required object which matches the passed parameter type 
 * @param class1 is the required class's Object
 * @return the required object if present in the POJO array and returns null if not present in the POJO array
 * @throws InstantiationException
 * @throws IllegalAccessException
 */
	public Object getPojo(Class class1) throws InstantiationException, IllegalAccessException {

		for (Object object : pojos) {
			if(object.getClass()==class1){
				return  object;
			}
		}
		return null;
	}

	
	
	
}
