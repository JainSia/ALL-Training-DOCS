package com.yash.pojo;
/**
 * this is the POJO for User class
 * @author ishan.juneja
 *
 */
public class User {
private int Id;
private String name;
public int getId() {
	return Id;
}
public void setUserId(int id) {
	Id = id;
}
public String getName() {
	return name;
}
public void setUserName(String name) {
	this.name = name;
}
@Override
public String toString() {
	
	return "name :"+this.getName()+" ID : "+this.getId();
}
}
