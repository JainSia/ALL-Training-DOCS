package com.yash.pojo;
/**
 * this is the POJO for application class
 * @author ishan.juneja
 *
 */
public class Application {
private int id;
private String name;

public int getId() {
	return id;
}
public void setAppId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setAppName(String name) {
	this.name = name;
}
	

@Override
	public String toString() {
		
		return "name :"+this.getName()+" ID : "+this.getId();
	}
	
}
