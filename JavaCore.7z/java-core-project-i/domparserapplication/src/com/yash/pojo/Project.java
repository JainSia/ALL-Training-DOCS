package com.yash.pojo;
/**
 * this is the POJO for Project class
 * @author ishan.juneja
 *
 */
public class Project {
private int Id;
private String name;
public int getId() {
	return Id;
}
public void setProjId(int Id) {
	this.Id = Id;
}
public String getName() {
	return name;
}
public void setProjName(String name) {
	this.name = name;
}
@Override
public String toString() {
	
	return "name :"+this.getName()+" ID : "+this.getId();
}
}
