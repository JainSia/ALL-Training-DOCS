package com.yash.controller;

public class ApplicationController {

	public void showControllerStatus(){
		System.out.println("Active");
	}
	
	
}
