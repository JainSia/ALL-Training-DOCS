package com.yash.service;

public class ApplicationService {

}
