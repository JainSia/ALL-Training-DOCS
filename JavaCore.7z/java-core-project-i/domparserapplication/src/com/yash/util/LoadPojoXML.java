package com.yash.util;
/**
 * this is a class that prepares pojo objects and return them to PojoFactory class.
 * this class uses DOMParser to parse the passed xml document and prepare Objects according to the passed xml file.
 */
import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.yash.factory.PojoFactory;
import com.yash.pojo.Application;
import com.yash.pojo.Project;
import com.yash.pojo.User;

public class LoadPojoXML {
	/**
	 * this array of objects will be passed to POJO factory. 
	 * it will contain all the POJO objects written in the the xml. 
	 */
	Object[] pojos ;
	
	/**
	 * this method will accomplish the task of parsing the passed XML document and creating objects for all POJOs
	 * mentioned in the XML Document
	 * @param file is the XML Document with POJO paths
	 * @return PojoFactory Reference 
	 */
	public PojoFactory getPojoFactory(File file) {

		
		DocumentBuilderFactory dbfactory = DocumentBuilderFactory.newInstance();

		try {
			DocumentBuilder dbuilder = dbfactory.newDocumentBuilder();
			Document document = dbuilder.parse(file);
			NodeList temp = document.getElementsByTagName("pojo");
			pojos=new Object[temp.getLength()];
			for (int i = 0; i < temp.getLength(); i++) {
				
				Element element = (Element) temp.item(i);
				int id = Integer.parseInt(element.getElementsByTagName("id").item(0).getTextContent());
				String name = element.getElementsByTagName("appname").item(0).getTextContent();
				String classname = element.getAttribute("class");

				Class<?> pojo = Class.forName(classname);
				Object obj = pojo.newInstance();
				Class<?> c = obj.getClass();

				if (obj.getClass() == Application.class) {
					Method setID = c.getMethod("setAppId", int.class);
					Method setName = c.getMethod("setAppName", String.class);
					setID.invoke(obj, id);
					setName.invoke(obj, name);
				}
				if (obj.getClass() == Project.class) {
					Method setID = c.getMethod("setProjId", int.class);
					Method setName = c.getMethod("setProjName", String.class);
					setID.invoke(obj, id);
					setName.invoke(obj, name);
				}
				if (obj.getClass() == User.class) {
					Method setID = c.getMethod("setUserId", int.class);
					Method setName = c.getMethod("setUserName", String.class);
					setID.invoke(obj, id);
					setName.invoke(obj, name);
				}

				pojos[i] = obj;

			}

		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (NoSuchMethodException e) {			
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}

		PojoFactory pojof = new PojoFactory(pojos);

		return pojof;
	}

}
