package com.yash.main;
/**
 * this is the Startup Class for the application.
 * Application starts from this class.
 */
import java.io.File;

import com.yash.controller.ApplicationController;
import com.yash.factory.PojoFactory;
import com.yash.pojo.Application;
import com.yash.pojo.Project;
import com.yash.pojo.User;
import com.yash.util.LoadPojoXML;

public class StartupApp {

	public static void main(String[] args) throws InstantiationException, IllegalAccessException {
		PojoFactory pf = new LoadPojoXML().getPojoFactory(new File("Pojo.xml"));
		Application app = (Application) pf.getPojo(Application.class);
		System.out.println(app);
		Project proj=(Project) pf.getPojo(Project.class);
		System.out.println(proj);
		User user = (User) pf.getPojo(User.class);
		System.out.println(user);
		ApplicationController ac = (ApplicationController) pf.getPojo(ApplicationController.class);
		
		try{
		ac.showControllerStatus();
		}
		catch(NullPointerException npe){
			System.out.println("pojo factory can't produce objects for classes which are not in com.yash.pojo");
		}
		
	}
}
