package com.yash.totalevenandodddigits;

import org.junit.Test;



import junit.framework.TestCase;

public class EvenAndOddDigitsTest extends TestCase {

private static final String NUMBER="-=abgs6a12124785jnsy1234";
	
@Test
public void test_no_input() throws Exception{

	EvenAndOddDigits evenodd = new EvenAndOddDigits();
	String result=evenodd.parse("");
	assertEquals("0 even and 0 odd",result);
}

	@Test
	public void test_invalid_input() throws Exception{

		EvenAndOddDigits evenodd = new EvenAndOddDigits();
		String result=evenodd.parse("abcd");
		assertEquals("0 even and 0 odd",result);
	}

	@Test
	public void test_mixed_input() throws Exception{

		EvenAndOddDigits evenodd = new EvenAndOddDigits();
		String result=evenodd.parse(NUMBER);
		assertEquals("7 even and 6 odd",result);
	}
	
	
}
