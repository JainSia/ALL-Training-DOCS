package com.yash.totalevenandodddigits;

public class EvenAndOddDigits {

	public String parse(String number) {
		
		
		char[] characterArray = number.toCharArray();
		int iterator=0;
		int evencount=0;
		int oddcount=0;
		while(iterator<characterArray.length){
			if(Character.isDigit(characterArray[iterator])){
			if(characterArray[iterator]%2==0){
				evencount++;
			}	
			else{
				oddcount++;
			}	
				
			}
			iterator++;
		}
		return evencount+" even and "+oddcount+" odd";
		
	}

	
	
	
}
