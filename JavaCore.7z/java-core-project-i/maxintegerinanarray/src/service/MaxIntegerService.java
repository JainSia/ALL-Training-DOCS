package service;
/**
 * this is a service class for MaxInteger class
 */
import java.util.Scanner;

public class MaxIntegerService {
/**
 * this method is used to take inputs from the user
 * @return input array
 */
	public int[] inputNumbers() {
		Scanner sc = new Scanner(System.in);
		System.out.println("how many numbers you want to enter");
		int length = sc.nextInt();
		int[] inputArray=new int[length];
		for(int i=0;i<inputArray.length;i++){
			System.out.println("enter number");
			inputArray[i]=sc.nextInt();
		}
		return inputArray;
	}

	/**
	 * this method is used to identify the maximum valued integer in the passed array
	 * and returns index of the maximum integer value and total number of elements in array
	 * @param integerArray
	 * @param length 
	 * @return maximum number
	 */
	public String maxInt(int[] integerArray, int length){
		int temp=0;
		int tempIndex=0;
		for(int i=0;i<length;i++){
			if(temp<integerArray[i]) {
				temp=integerArray[i];
				tempIndex = i;
			}
			}
		
		return "max integer is at location "+tempIndex+" and value is "+temp+" and total number of elements in array is "+integerArray.length;
	}
}
