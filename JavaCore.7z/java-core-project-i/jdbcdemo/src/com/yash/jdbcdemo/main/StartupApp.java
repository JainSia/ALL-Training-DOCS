package com.yash.jdbcdemo.main;
/**
 * this is the main class from which the execution of the application starts
 */
import java.sql.Connection;

import javax.swing.JOptionPane;

import com.yash.jdbcdemo.serviceimpl.AdminServiceImpl;
import com.yash.jdbcdemo.serviceimpl.LoginServiceImpl;
import com.yash.jdbcdemo.serviceimpl.RegistrationServiceImpl;
import com.yash.jdbcdemo.serviceimpl.TraineeServiceImpl;
import com.yash.jdbcdemo.serviceimpl.TrainerServiceImpl;
import com.yash.jdbcdemo.util.CreateSchema;
import com.yash.jdbcdemo.util.DBConnection;

public class StartupApp {

	public static void main(String[] args) {
		
		Connection con = new DBConnection().connect();
		CreateSchema.createschema(con);
		do {
			
			System.out.println("----MAIN MENU----");
			System.out.println("1.) LOGIN");
			System.out.println("2.) REGISTER");
			System.out.println("3.) QUIT");
			int choice=0;
			try{
			choice=Integer.parseInt(JOptionPane.showInputDialog("Enter Your Choice"));
			}catch(NumberFormatException nfe){
				System.out.println("invalid input");}
			switch (choice) {
			//login
			case 1:
				String username=JOptionPane.showInputDialog("ENTER NAME");
				String password=JOptionPane.showInputDialog("ENTER PASSWORD");
				String role=new LoginServiceImpl().login(username, password);
				switch (role) {
				//admin logged in
				case "admin":
					new AdminServiceImpl().showAdminMenu(username);
					break;
				//trainer logged in
				case "trainer":
					new TrainerServiceImpl().showTrainerMenu(username);
					break;
				//trainee logged in	
				case "trainee":
					new TraineeServiceImpl().showTraineeMenu(username);
					break;
				//newly registered user
				case "waiting":
					System.out.println("Waiting for approval from admin. Contact Admin");
					break;
				//invalid username or password
				case "NA":
					System.out.println("Invalid Credentials");
					break;
				default:
					break;
				}
				break;
				//registration 
			case 2:
				String regname=JOptionPane.showInputDialog("ENTER NAME");
				String regpass=JOptionPane.showInputDialog("ENTER PASSWORD");
				new RegistrationServiceImpl().registerUser(regname, regpass);
				break;	
				//Quit
			case 3:
				System.exit(0);
				break;
			default:
				break;
			}			
		} while (true);
		}
	}


