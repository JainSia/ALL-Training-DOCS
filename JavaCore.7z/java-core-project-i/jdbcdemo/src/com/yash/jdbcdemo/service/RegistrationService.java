package com.yash.jdbcdemo.service;
/**
 * this Interface is used to register a new user to the system
 * @author ishan.juneja
 *
 */
public interface RegistrationService {
	/**
	 * this method registers a new user to the system
	 * @param username
	 * @param password
	 */
public void registerUser(String username,String password);
}
