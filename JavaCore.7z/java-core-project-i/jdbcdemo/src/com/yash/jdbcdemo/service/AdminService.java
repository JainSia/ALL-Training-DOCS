package com.yash.jdbcdemo.service;
/**
 * this is the interface that will handle all the services for admin
 */
import java.sql.Connection;

public interface AdminService {
/**
 * this method will show admin menu
 * @param name
 */
	public void showAdminMenu(String name);
	/**
	 * this method will request AdminDao to show list the users from the database.
	 * @param con
	 */
	public void listUsers(Connection con);
	/**
	 * this method will request the AdminDao to change a users role in the database
	 * @param con
	 */
	public void editRole(Connection con);
	/**
	 * this method will request the AdminDao to change the status of a user from blocked to unblocked in the database or vice versa
	 * @param con
	 */
	public void blockUnblock(Connection con);
	/**
	 * this method will request AdminDao to delete a user from the database
	 * @param con
	 */
	public void deleteUser(Connection con);

}
