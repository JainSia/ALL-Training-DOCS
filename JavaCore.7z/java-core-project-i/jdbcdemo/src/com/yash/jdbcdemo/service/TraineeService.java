package com.yash.jdbcdemo.service;
/**
 * this is the Interface that provides services to the trainee
 * @author ishan.juneja
 *
 */
public interface TraineeService {
	/**
	 * this method shows the trainee menu
	 * @param traineename
	 */
	public void showTraineeMenu(String traineename);
	/**
	 * this method requests the TraineeDao to list all the activated courses by the Trainer of the current trainee
	 * @param traineename
	 */
	public void showCourses(String traineename);
}
