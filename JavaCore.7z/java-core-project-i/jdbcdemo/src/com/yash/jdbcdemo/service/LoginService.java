package com.yash.jdbcdemo.service;
/**
 * this is the LoginService Interface which handles the login requests
 * @author ishan.juneja
 *
 */
public interface LoginService {
	/**
	 * this function requests LoginDao to authenticate the user
	 * @param name
	 * @param password
	 * @return
	 */
public String login(String name,String password);
}
