package com.yash.jdbcdemo.service;
/**
 * this Interface contains service methods for Trainer
 */
import java.sql.Connection;

public interface TrainerService {
	/**
	 * this method requests TrainerDao to add a course to the database under the current Trainer name
	 * @param name
	 */
public void addCourse(String name);
/**
 * this method displays the trainer menu
 * @param username
 */
public void showTrainerMenu(String username);
/**
 * this method requests TrainerDao to list all courses under the current Trainer along with activation status
 * @param name
 */
public void listCourses(String name);
/**
 * this method requests TrainerDao to edit the course name in the database
 * @param name
 */
public void editCourse(String name);
/**
 * this method requests TrainerDao to activate or deactivate a course in the database
 * @param name
 */
public void activateDeactivate(String name);
/**
 * this method requests TrainerDao to delete the course from the database
 * @param name
 */
public void deleteCourse(String name);

}
