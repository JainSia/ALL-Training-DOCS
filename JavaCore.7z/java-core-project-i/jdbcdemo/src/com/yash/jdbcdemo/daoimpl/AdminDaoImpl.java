package com.yash.jdbcdemo.daoimpl;
/**
 * this class is the implementation of AdminDao interface
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.yash.jdbcdemo.dao.AdminDao;
public class AdminDaoImpl implements AdminDao {
	/**
	 * this method would list all the users for the application from database.
	 * This list contains all employees including admin,trainer and trainees in the system
	 * @param con
	 * @return
	 */
	@Override
	public ResultSet listUsers(Connection con) {
		String list = "select * from usermanagement.users";
		String role = "";
		try {
			PreparedStatement listps = con.prepareStatement(list);
			ResultSet rs = listps.executeQuery();
			return rs;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	/**
	 * this method will be used to edit and assign role to a newly registered employee. 
	 * It also activates the new employee on first assignment of role to the employee
	 * @param name
	 * @param con
	 * @param role
	 * @param trainername
	 */
	@Override
	public void editRole(String name, Connection con, int role, String trainername) {
		String editsql = "update usermanagement.users set role=?,status=? where username=? and role!=1";
		String trainersql = "insert into usermanagement.trainees(traineename,trainername) values(?,?)";
		try {
			PreparedStatement updateps = con.prepareStatement(editsql);
			updateps.setInt(1, role + 1);
			updateps.setInt(2, 1);
			updateps.setString(3, name);
			if (updateps.executeUpdate() != 0) {
				System.out.println("Role Edited");
			}
			else System.out.println("You cannot edit an admin");
			updateps.close();
			if (trainername != "") {
				PreparedStatement traineeinsert = con.prepareStatement(trainersql);
				traineeinsert.setString(1, name);
				traineeinsert.setString(2, trainername);
				traineeinsert.executeUpdate();
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
	/**
	 * this method will change the status of an employee from blocked to unblocked or vice versa
	 * @param name
	 * @param con
	 */
	@Override
	public void blockUnblock(String name, Connection con) {
		int userstatus = 2;
		int userrole = 0;
		String getstat = "select status,role from usermanagement.users where username=?";
		String busql = "update usermanagement.users set status=? where username=?";
		try {
			PreparedStatement getps = con.prepareStatement(getstat);
			getps.setString(1, name);
			ResultSet rs = getps.executeQuery();
			while (rs.next()) {
				userstatus = rs.getInt(1);
				userrole = rs.getInt(2);
			}
			getps.close();

			PreparedStatement bups = con.prepareStatement(busql);
			if (userrole != 1) {
				if (userstatus == 1) {
					bups.setInt(1, 0);
					System.out.println("Blocked " + name + " successfuly!");
				} else if (userstatus == 0) {
					bups.setInt(1, 1);
					System.out.println("Unblocked " + name + " successfuly!");
				}
				bups.setString(2, name);
				bups.executeUpdate();
				bups.close();
			} else
				System.out.println("you cannot block an admin");
		} catch (SQLException e) {
			System.out.println("invalid input");
		}
	}
	/**
	 * this method is used to delete an employee permanently from the system
	 * @param name
	 * @param con
	 */
	@Override
	public void deleteUser(String name, Connection con) {

		int userrole = 0;
		String getrole = "select role from usermanagement.users where username=?";
		String deletesql = "delete from usermanagement.users where username=?";
		try {
			PreparedStatement getps = con.prepareStatement(getrole);
			getps.setString(1, name);
			ResultSet rs = getps.executeQuery();
			while (rs.next()) {
				userrole = rs.getInt(1);
			}
			getps.close();
			PreparedStatement deleteps = con.prepareStatement(deletesql);
			if (userrole != 1) {
				deleteps.setString(1, name);
				if (deleteps.executeUpdate() != 0) {
					System.out.println(name + " deleted successfully");
				}
			} else
				System.out.println("you cannot delete an admin");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
