package com.yash.jdbcdemo.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.yash.jdbcdemo.dao.TrainerDao;
import com.yash.jdbcdemo.util.DBConnection;

public class TrainerDaoImpl implements TrainerDao {
	Connection con = new DBConnection().connect();
	/**
	 * this method is used by the trainer to add the course under his name.
	 * @param trainername
	 * @param coursename
	 */
	@Override
	public void addCourse(String trainername, String coursename) {
		String addcoursesql = "insert into usermanagement.courses(trainername,coursename,status) values(?,?,?)";
		try {
			PreparedStatement addps = con.prepareStatement(addcoursesql);
			addps.setString(1, trainername);
			addps.setString(2, coursename);
			addps.setInt(3, 0);
			addps.executeUpdate();
			addps.close();
		} catch (SQLException e) {
			System.out.println();
			System.out.println(coursename + " course exists for " + trainername);
		}

	}
	/**
	 * this method is used to list all courses for a trainer along with which courses are activated and which are deactivated
	 * @param name
	 */
	@Override
	public void listcourses(String trainername) {
		String listsql = "select * from usermanagement.courses where trainername=?";
		try {
			PreparedStatement listps = con.prepareStatement(listsql);
			listps.setString(1, trainername);
			ResultSet rs = listps.executeQuery();
			System.out.println("courses for " + trainername);
			while (rs.next()) {
				System.out.println("coursename : "+rs.getString(2)+" Status : "+rs.getInt(3));
			}
			rs.close();
			listps.close();
		} catch (SQLException e) {

			e.printStackTrace();
		}
	}
	/**
	 * this method is used to delete the course under his name.
	 * @param trainername
	 * @param coursename
	 */
	@Override
	public void deleteCourse(String trainername, String coursename) {
		String deletesql = "delete from usermanagement.courses where coursename=? and trainername=?";
		try {
			PreparedStatement deleteps = con.prepareStatement(deletesql);
			deleteps.setString(1, coursename);
			deleteps.setString(2, trainername);
			if(deleteps.executeUpdate()>0){
			System.out.println(coursename + " course deleted for " + trainername);
			}else System.out.println("no such course");
			deleteps.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
	/**
	 * this method is used to activate or deactivate a course for the traineed under him
	 * @param trainername
	 * @param coursename
	 */
	@Override
	public void activateDeactivate(String trainername, String coursename) {
		int status = 2;
		String getstat = "select status from usermanagement.courses where coursename=? and trainername=?";

		String adsql = "update usermanagement.courses set status=? where coursename=? and trainername=?";
		try {
			PreparedStatement getstatus = con.prepareStatement(getstat);
			getstatus.setString(1, coursename);
			getstatus.setString(2, trainername);
			ResultSet rs = getstatus.executeQuery();
			while (rs.next()) {
				if (rs.getInt(1) == 0) {
					status = 1;
				} else if (rs.getInt(1) == 1) {
					status = 0;
				}
			}
			rs.close();
			getstatus.close();
			PreparedStatement adps = con.prepareStatement(adsql);
			adps.setInt(1, status);
			adps.setString(2, coursename);
			adps.setString(3, trainername);
			adps.executeUpdate();
			if (status == 1) {
				System.out.println(coursename + " activated by trainer " + trainername);
			} else if (status == 0) {
				System.out.println(coursename + " deactivated by trainer " + trainername);
			}
			else if(status==2){
				System.out.println("no such course");
			}
			adps.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
	/**
	 * this method is used to edit the name of the course
	 * @param trainername
	 * @param oldcoursename
	 * @param newcoursename
	 */
	@Override
	public void editCourse(String trainername, String oldcoursename,String newcoursename) {
		String editsql="update usermanagement.courses set coursename=? where trainername=? and coursename=?";
		try {
			PreparedStatement edps=con.prepareStatement(editsql);
			edps.setString(1, newcoursename);
			edps.setString(2, trainername);
			edps.setString(3, oldcoursename);
			if(edps.executeUpdate()>0){
			System.out.println(newcoursename+" set for "+oldcoursename+" by trainer "+trainername);
			}else System.out.println("no such course");
			} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

}
