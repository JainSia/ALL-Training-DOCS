package com.yash.jdbcdemo.daoimpl;
/**
 * this class is the implementation of LoginDao Interface
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.yash.jdbcdemo.dao.LoginDao;
import com.yash.jdbcdemo.pojo.User;
import com.yash.jdbcdemo.util.DBConnection;

public class LoginDaoImpl implements LoginDao {
	/**
	 * this function authenticates the user logging in and selects the role for the employee
	 * @param name
	 * @param password
	 * @return
	 */
	@Override
	public User login(String name, String password) {
		User user = new User();
		Connection con = new DBConnection().connect();

		String sql = "select * from usermanagement.users where username=? and password=?";
		PreparedStatement loginps;
		try {
			loginps = con.prepareStatement(sql);
			loginps.setString(1, name);
			loginps.setString(2, password);
			ResultSet rs = loginps.executeQuery();
			try {

				user.setUsername(name);
				user.setPassword(password);
				if (rs.next()) {
					rs.previous();
					while (rs.next()) {
						user.setStatus(rs.getInt(5));
						if (user.getStatus() == 1) {
							if (rs.getInt(4) == 1) {
								user.setRole("admin");
							}
							if (rs.getInt(4) == 2) {
								user.setRole("trainer");
							}
							if (rs.getInt(4) == 3) {
								user.setRole("trainee");
							}
							if (rs.getInt(4) == 4) {
								user.setRole("waiting");
							}
						} else {
							user.setRole("nitesh");
							System.out.println("you have been blocked. Contact admin");
							con.close();
							return user;
						}
					}

				} else {
					user.setStatus(0);
					user.setRole("NA");
				}
				con.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		} catch (SQLException e) {

			e.printStackTrace();
		}

		return user;
	}

}
