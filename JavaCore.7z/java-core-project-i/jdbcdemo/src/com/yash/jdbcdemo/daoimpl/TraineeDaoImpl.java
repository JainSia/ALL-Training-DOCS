package com.yash.jdbcdemo.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.yash.jdbcdemo.dao.TraineeDao;
import com.yash.jdbcdemo.util.DBConnection;

public class TraineeDaoImpl implements TraineeDao {
Connection con=new DBConnection().connect();
/**
 * this method shows all the courses for the trainee that has been activated by the trainee's trainer
 * @param traineename
 */
	@Override
	public void showCourses(String traineename) {
		String sql="SELECT coursename,trainername FROM usermanagement.courses WHERE trainername=(SELECT trainername FROM usermanagement.trainees WHERE traineename=? AND STATUS=?)";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, traineename);
			ps.setInt(2, 1);
			ResultSet rs=ps.executeQuery();
			rs.next();
			try{
			System.out.println("courses for "+traineename+" TRAINER NAME : "+rs.getString(2));
			}catch(SQLException se){
				System.out.println("NO COURSES ACTIVATED/EXIST for "+traineename);
			}
			rs.previous();
			while(rs.next()){
				System.out.println(rs.getString(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

}
