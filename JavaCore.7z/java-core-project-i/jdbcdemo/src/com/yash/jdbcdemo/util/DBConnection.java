package com.yash.jdbcdemo.util;
/**
 * this class is for setting up the DBConnection by using jdbc.properties file
 */
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBConnection {

	private Connection dbconnection;
	/**
	 * this method loads the properties from the property file
	 * @return
	 */
	private static Properties loadPropertiesFromFile(){
		File dir=new File("lib");
		dir.mkdir();
		Properties properties=new Properties();
		try {
			InputStream propertiesinput=new FileInputStream("jdbc.properties");
			properties.load(propertiesinput);
			propertiesinput.close();
			return properties;
		} catch (FileNotFoundException e) {
			System.out.println("Properties file not found. Check Properties file");
		} catch (IOException e) {
			System.out.println("Properties file not found. Check Properties file");
		}
		return null;
	}
	/**
	 * this method is used to setup a connection to the database
	 * @return the connection or null if there is a problem connecting the database
	 */
	public Connection connect(){
		Properties prop = loadPropertiesFromFile();
		try {
			
			String driverclassname=prop.getProperty("driver");
			String url=prop.getProperty("url");
			String username=prop.getProperty("username");
			String password=prop.getProperty("password");
			Class<?> driverclass= Class.forName(driverclassname);
			dbconnection = DriverManager.getConnection(url,username,password);
			
			
		} catch (ClassNotFoundException e) {
			System.out.println("Driver not found : "+prop.getProperty("MYSQLJDBC.driver"));
			
		} catch (SQLException e) {
			System.out.println("invalid username/password/URL");
		}
		
		
		return dbconnection;
	}
}

