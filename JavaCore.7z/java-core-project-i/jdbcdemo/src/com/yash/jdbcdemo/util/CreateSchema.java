package com.yash.jdbcdemo.util;
/**
 * this util class is used to create a schema if it does'nt exist and respective table if they don't exist in the database
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class CreateSchema {
/**
 * this method is used to create a schema if it does'nt exist and respective table if they don't exist in the database
 * @param con
 */
	public static void createschema(Connection con){
		/**
		 * create schema SQL query
		 */
		String schemacreate = "create database if not exists usermanagement";
		/**
		 * create admintable SQL query
		 */
		String admintablecreate = "create table if not exists usermanagement.users(id int auto_increment primary key,username varchar(20),password varchar(10),role int,status tinyint,unique(username))";
		/**
		 * create trainertable SQL query
		 */
		String trainertablecreate="create table if not exists usermanagement.courses(trainername varchar(50),coursename varchar(50),status tinyint,primary key(trainername,coursename))";
		/**
		 * create traineetable SQL query
		 */
		String traineetablecreate="create table if not exists usermanagement.trainees(id int auto_increment primary key,traineename varchar(50),trainername varchar(50))";
		/**
		 * insert first admin if it doesnt exist in the users table with username-"root" and password-"root"
		 */
		String insertadmin = "insert into usermanagement.users(username,password,role,status) values('root','root','1','1')";
		try {
			PreparedStatement createdatabaseps = con.prepareStatement(schemacreate);
			createdatabaseps.executeUpdate();
			createdatabaseps.close();
			PreparedStatement createadmintableps = con.prepareStatement(admintablecreate);
			createadmintableps.executeUpdate();
			createadmintableps.close();
			PreparedStatement createtrainertableps = con.prepareStatement(trainertablecreate);
			createtrainertableps.executeUpdate();
			createtrainertableps.close();
			PreparedStatement createtraineetableps = con.prepareStatement(traineetablecreate);
			createtraineetableps.executeUpdate();
			createtraineetableps.close();
			PreparedStatement insertadminps=con.prepareStatement(insertadmin);
			if(insertadminps.executeUpdate()>0);{
			insertadminps.close();
			}
			con.close();
		} catch (SQLException e) {
		}
		catch(NullPointerException ne){
			System.out.println("Error Creating schema. Please check .Properties file");
			System.exit(0);
		}
	}
	
}
