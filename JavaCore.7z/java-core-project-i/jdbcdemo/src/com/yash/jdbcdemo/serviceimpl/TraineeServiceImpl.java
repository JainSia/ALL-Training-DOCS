package com.yash.jdbcdemo.serviceimpl;

import javax.swing.JOptionPane;

import com.yash.jdbcdemo.dao.TraineeDao;
import com.yash.jdbcdemo.daoimpl.TraineeDaoImpl;
import com.yash.jdbcdemo.service.TraineeService;


public class TraineeServiceImpl implements TraineeService {
	TraineeDao traineeDao=new TraineeDaoImpl();
	/**
	 * this method shows the trainee menu
	 * @param traineename
	 */
	public void showTraineeMenu(String name) {
		
		boolean cont = true;
		do {
			System.out.println();
			System.out.println("--WELCOME " + name.toUpperCase() + "--");
			System.out.println("---ADMIN MENU---");
			System.out.println("1.) Show courses");
			System.out.println("2.) Logout");
			int choice=0;
			try{
			choice=Integer.parseInt(JOptionPane.showInputDialog("Enter Your Choice"));
			}catch(NumberFormatException nfe){
				System.out.println("invalid input");}
			switch (choice) {
			case 1:
				showCourses(name);
				break;
			
			case 2:
				cont = false;
				break;
			default:
				break;
			}
		} while (cont);

	}
		
	/**
	 * this method requests the TraineeDao to list all the activated courses by the Trainer of the current trainee
	 * @param traineename
	 */
	@Override
	public void showCourses(String traineename) {
		traineeDao.showCourses(traineename);
	}
	
}
