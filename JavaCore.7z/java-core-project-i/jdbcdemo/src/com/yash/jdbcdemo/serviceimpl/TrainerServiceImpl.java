package com.yash.jdbcdemo.serviceimpl;

import java.sql.Connection;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import com.yash.jdbcdemo.dao.TrainerDao;

import com.yash.jdbcdemo.daoimpl.TrainerDaoImpl;
import com.yash.jdbcdemo.service.TrainerService;
import com.yash.jdbcdemo.util.DBConnection;

public class TrainerServiceImpl implements TrainerService {
	Connection con = new DBConnection().connect();
	TrainerDao trainerdao = new TrainerDaoImpl();

	@Override
	public void showTrainerMenu(String trainername) {
		boolean cont = true;
		do {
			System.out.println();
			System.out.println("--WELCOME " + trainername.toUpperCase() + "--");
			System.out.println("---TRAINER MENU---");
			System.out.println("1.) Add Course");
			System.out.println("2.) List Courses");
			System.out.println("3.) Edit Course");
			System.out.println("4.) Activate/Deactivate Course");
			System.out.println("5.) Delete Course");
			System.out.println("6.) Logout");
			int choice=0;
			try{
			choice=Integer.parseInt(JOptionPane.showInputDialog("Enter Your Choice"));
			}catch(NumberFormatException nfe){
				System.out.println("invalid input");}
			switch (choice) {
			case 1:
				addCourse(trainername);
				break;
			case 2:
				listCourses(trainername);
				break;
			case 3:

				editCourse(trainername);
				break;

			case 4:
				activateDeactivate(trainername);
				break;
			case 5:
				deleteCourse(trainername);
				break;
			case 6:
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				cont = false;
				break;
			default:
				break;
			}
		} while (cont);

	}

	public void listCourses(String trainername) {
		trainerdao.listcourses(trainername);
	}

	public void addCourse(String trainername) {
		String coursename=JOptionPane.showInputDialog("enter coursename to be added");
		trainerdao.addCourse(trainername, coursename);
	}

	public void deleteCourse(String trainername) {
		String coursename=JOptionPane.showInputDialog("enter coursename to be deleted");
		trainerdao.deleteCourse(trainername,coursename);
	}

	public void activateDeactivate(String trainername) {
		String coursename=JOptionPane.showInputDialog("enter coursename to be Activated/Deactivated");
		trainerdao.activateDeactivate(trainername, coursename);
	}

	public void editCourse(String trainername) {
		String oldname=JOptionPane.showInputDialog("enter coursename to be edited");
		String newname=JOptionPane.showInputDialog("enter new coursename");
		trainerdao.editCourse(trainername, oldname, newname);
	}

}
