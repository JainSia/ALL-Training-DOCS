package com.yash.jdbcdemo.serviceimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.yash.jdbcdemo.service.RegistrationService;
import com.yash.jdbcdemo.util.DBConnection;

public class RegistrationServiceImpl implements RegistrationService{
	/**
	 * this method registers a new user to the system
	 * @param username
	 * @param password
	 */
	@Override
	public void registerUser(String username, String password) {
		Connection con = new DBConnection().connect();
		String sql="insert into usermanagement.users(username,password,role,status) values(?,?,?,?)";
		try {
			PreparedStatement registerps=con.prepareStatement(sql);
			registerps.setString(1, username);
			registerps.setString(2, password);
			registerps.setInt(3, 4);
			registerps.setInt(4, 1);
			int reg=registerps.executeUpdate();
			if(reg!=0){
				System.out.println("registeration successful");
			}else System.out.println("registeration unsuccessful");
		} catch (SQLException e) {
			System.out.println("username already exists! Please try again with different username");
		}
		
		
	}

}
