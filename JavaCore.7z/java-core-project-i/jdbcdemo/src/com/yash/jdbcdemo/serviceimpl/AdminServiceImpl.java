package com.yash.jdbcdemo.serviceimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import com.yash.jdbcdemo.dao.AdminDao;
import com.yash.jdbcdemo.daoimpl.AdminDaoImpl;
import com.yash.jdbcdemo.service.AdminService;
import com.yash.jdbcdemo.util.DBConnection;

public class AdminServiceImpl implements AdminService {
	AdminDao admindao = new AdminDaoImpl();
	Connection con = new DBConnection().connect();
	/**
	 * this method will show admin menu
	 * @param name
	 */
	@Override
	public void showAdminMenu(String name) {

		boolean cont = true;
		do {
			System.out.println();
			System.out.println("--WELCOME " + name.toUpperCase() + "--");
			System.out.println("---ADMIN MENU---");
			System.out.println("1.) List Users");
			System.out.println("2.) Edit User's Role");
			System.out.println("3.) Block/Unblock User");
			System.out.println("4.) Delete User");
			System.out.println("5.) Logout");
			int choice=0;
			try{
			choice=Integer.parseInt(JOptionPane.showInputDialog("Enter Your Choice"));
			}catch(NumberFormatException nfe){
				System.out.println("invalid input");}
			switch (choice) {
			case 1:
				listUsers(con);
				break;
			case 2:

				editRole(con);
				break;

			case 3:
				blockUnblock(con);
				break;
			case 4:
				deleteUser(con);
				break;
			case 5:
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				cont = false;
				break;
			default:
				System.out.println("invalid input");
				break;
			}
		} while (cont);

	}
	/**
	 * this method will request AdminDao to delete a user from the database
	 * @param con
	 */
	@Override
	public void deleteUser(Connection con2) {
		String name = JOptionPane.showInputDialog("Enter username to be deleted");
		admindao.deleteUser(name, con);
	}
	/**
	 * this method will request the AdminDao to change the status of a user from blocked to unblocked in the database or vice versa
	 * @param con
	 */
	@Override
	public void blockUnblock(Connection con) {
		String name = JOptionPane.showInputDialog("Enter username to be Blocked/Unblocked");
		admindao.blockUnblock(name, con);
	}
	/**
	 * this method will request the AdminDao to change a users role in the database
	 * @param con
	 */
	@Override
	public void editRole(Connection con) {
		String trainername="";
		String name = JOptionPane.showInputDialog("Enter username to be edited");
		String[] options = new String[] { "ADMIN", "TRAINER", "TRAINEE" };
		int role = JOptionPane.showOptionDialog(null, "Enter New Employee Role", "ROLE", JOptionPane.DEFAULT_OPTION, 1,
				null, options, options[0]);
		if(role==2){
			trainername=JOptionPane.showInputDialog("Enter trainer name for "+name);
		}
		admindao.editRole(name, con, role,trainername);
	}
	/**
	 * this method will request AdminDao to show list the users from the database.
	 * @param con
	 */
	@Override
	public void listUsers(Connection con) {
		ResultSet rs = admindao.listUsers(con);
		String role = "";
		try {
			while (rs.next()) {
				if (rs.getInt(4) == 1) {
					role = "admin";
				}
				if (rs.getInt(4) == 2) {
					role = "trainer";
				}
				if (rs.getInt(4) == 3) {
					role = "trainee";
				}
				if (rs.getInt(4) == 4) {
					role = "unknown";
				}
				System.out.println("ID : " + rs.getInt(1) + " NAME : " + rs.getString(2) + " ROLE : " + role);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
