package com.yash.jdbcdemo.serviceimpl;
/**
 * this class is the implementation of LoginService Interface
 */
import java.sql.ResultSet;
import java.sql.SQLException;

import com.yash.jdbcdemo.daoimpl.LoginDaoImpl;
import com.yash.jdbcdemo.pojo.User;
import com.yash.jdbcdemo.service.LoginService;

public class LoginServiceImpl implements LoginService {
	/**
	 * this function requests LoginDao to authenticate the user
	 * @param name
	 * @param password
	 * @return
	 */
	public String login(String name, String password) {
		User user = new LoginDaoImpl().login(name, password);
		return user.getRole();
		
	}

}
