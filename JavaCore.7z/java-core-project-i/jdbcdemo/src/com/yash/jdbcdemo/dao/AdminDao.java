package com.yash.jdbcdemo.dao;
/**
 * this is the interface that contains database methods for admin of the application
 */
import java.sql.Connection;
import java.sql.ResultSet;

public interface AdminDao {
/**
 * this method would list all the users for the application from database.
 * This list contains all employees including admin,trainer and trainees in the system
 * @param con
 * @return
 */
	public ResultSet listUsers(Connection con);
	/**
	 * this method will be used to edit and assign role to a newly registered employee. 
	 * It also activates the new employee on first assignment of role to the employee
	 * @param name
	 * @param con
	 * @param role
	 * @param trainername
	 */
	public void editRole(String name,Connection con,int role,String trainername);
	/**
	 * this method will change the status of an employee from blocked to unblocked or vice versa
	 * @param name
	 * @param con
	 */
	public void blockUnblock(String name,Connection con);
	/**
	 * this method is used to delete an employee permanently from the system
	 * @param name
	 * @param con
	 */
	public void deleteUser(String name,Connection con);
}
