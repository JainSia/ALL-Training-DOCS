package com.yash.jdbcdemo.dao;
/**
 * this is the interface for handling the database functions of trainee role
 * @author ishan.juneja
 *
 */
public interface TraineeDao {
	/**
	 * this method shows all the courses for the trainee that has been activated by the trainee's trainer
	 * @param traineename
	 */
public void showCourses(String traineename);
}
