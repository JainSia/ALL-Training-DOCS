package com.yash.jdbcdemo.dao;
/**
 * this is the interface that will handle all the database methods for trainer role
 * @author ishan.juneja
 *
 */
public interface TrainerDao {
/**
 * this method is used by the trainer to add the course under his name.
 * @param trainername
 * @param coursename
 */
	public void addCourse(String trainername,String coursename);
	/**
	 * this method is used to list all courses for a trainer along with which courses are activated and which are deactivated
	 * @param name
	 */
	public void listcourses(String name);
	/**
	 * this method is used to delete the course under his name.
	 * @param trainername
	 * @param coursename
	 */
	public void deleteCourse(String trainername,String coursename);
	/**
	 * this method is used to activate or deactivate a course for the traineed under him
	 * @param trainername
	 * @param coursename
	 */
	public void activateDeactivate(String trainername,String coursename);
	/**
	 * this method is used to edit the name of the course
	 * @param trainername
	 * @param oldcoursename
	 * @param newcoursename
	 */
	public void editCourse(String trainername,String oldcoursename,String newcoursename);
}
