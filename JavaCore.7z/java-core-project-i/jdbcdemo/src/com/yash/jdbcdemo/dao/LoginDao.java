package com.yash.jdbcdemo.dao;
/**
 * this interface contains the database method for logging in into the system
 */
import java.sql.ResultSet;

import com.yash.jdbcdemo.pojo.User;

public interface LoginDao {
	/**
	 * this function authenticates the user logging in and selects the role for the employee
	 * @param name
	 * @param password
	 * @return
	 */
	public User login(String name,String password);
}
