package com.yash.model;
/**
 * this is the model class for the employee
 * @author ishan.juneja
 *
 */
public class Employee {
	/**
	 * this is the employee id for the employee
	 */
private int employeeId;
/**
 * this is the employee name for the employee
 */
private String employeeName;
/**
 * this is the salary for the employee
 */
private int employeeSalary;

public int getEmployeeId() {
	return employeeId;
}
public void setEmployeeId(int employeeId) {
	this.employeeId = employeeId;
}
public String getEmployeeName() {
	return employeeName;
}
public void setEmployeeName(String employeeName) {
	this.employeeName = employeeName;
}
public int getEmployeeSalary() {
	return employeeSalary;
}
public void setEmployeeSalary(int employeeSalary) {
	this.employeeSalary = employeeSalary;
}
	
	
}
