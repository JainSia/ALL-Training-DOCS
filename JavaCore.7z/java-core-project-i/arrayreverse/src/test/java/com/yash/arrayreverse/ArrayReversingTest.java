package com.yash.arrayreverse;
/*
 * this is the test class for ArrayReverse
 */
import static org.junit.Assert.*;

import org.junit.Test;

public class ArrayReversingTest {
private final int[] testArray={1,2,3,4,5,6,7,8,9,10};
private final int[] resultArray={10,9,8,7,6,5,4,3,2,1};
	/*
	 * this is a test case for reversing an array
	 */
@Test
	public void test_reverse() {
		ArrayReverse arrayReverse = new ArrayReverse();
		int[] result=new int[testArray.length];
		result=arrayReverse.reverseArray(testArray);
		assertArrayEquals(resultArray, result);
	}

}
