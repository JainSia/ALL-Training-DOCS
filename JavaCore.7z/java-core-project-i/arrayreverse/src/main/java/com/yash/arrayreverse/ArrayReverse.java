package com.yash.arrayreverse;
/*
 * this class will reverse an integer array passed to it
 */
public class ArrayReverse {
	/*
	 * this will hold the reversed array
	 */
	int[] tempArray=new int[10];
	public int[] reverseArray(int[] testArray) {
		
		int j=0;
		for(int i=9;i>=0;i--){
		tempArray[j]=testArray[i];
		j++;
		}
		return tempArray;
	}

	
}
