package com.yash.searchfromtennumbers;
/*
 * this is the test class for FindFromTenNumber
 */
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class FindFromTenNumbersTest {
/*
 * this method will test the input has 10 numbers
 */
	FindFromTenNumbers find;
	@Before
	public void setUp(){
		
	find = new FindFromTenNumbers();
	}
	
	@Test
	public void test_integer_input() {
		
		String result=find.takeInput();
		assertEquals("10 numbers entered", result);
	}
	
	/*
	 * this method will test the count of a number in given array
	 */
	@Test
	public void test_count() {

		find.takeInput();
		int result = find.claculateCount();
		assertEquals(3, result);
	}
	
	

}
