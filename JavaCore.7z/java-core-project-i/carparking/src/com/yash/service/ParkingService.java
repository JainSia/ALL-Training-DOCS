package com.yash.service;
/**
 * this is the car parking service. It will have methods such as park car and remove car.
 */
import com.yash.model.Car;
import com.yash.model.ParkingToken;

public class ParkingService {
	/**
	 * place available will hold the index of the available place at which the car would be parked
	 */
	int placeAvailable;
	/**
	 * this is the car array which will simulate the real space for cars in the car parking.
	 */
Car[] parkingSpace=new Car[15];
/**
 * this method will search for an available space in the parking lot 
 * and place a car object for the passed parameters in the available place
 * @param Cname is the Car name for the car object
 * @param Oname is the owner name for the car object
 * @param RegNo is the registration number of the car object.
 */
public void park(String Cname, String Oname, int RegNo){
	placeAvailable=searchSpace(parkingSpace);
	if(placeAvailable!=16){
		ParkingToken token = new ParkingToken();
		Car car = new Car();
		car.setCarName(Cname);
		car.setOwnerName(Oname);
		car.setRegNo(RegNo);
		token.setOwnerName(car.getOwnerName());
		token.setToken(placeAvailable+101);
		
		car.setToken(token);
		parkingSpace[placeAvailable]=car;
	}else System.out.println("parking space is full");
}

/**
 * this method will remove the car with the same token number that has been passed to the car
 * It will display the car removed along with the owner name of the car removed and will free a token
 * for the available space.
 * @param token is the token number of the car to be removed from the car parking
 * @return false if token passed does not match a car in the parking
 */
public boolean remove(ParkingToken token){
	for (int i=0;i<15;i++) {
		
		if(parkingSpace[i]!=null){
		
		if(parkingSpace[i].getToken().getToken()==token.getToken()){
			System.out.println("car removed with token number "+parkingSpace[i].getToken().getToken()+" owner was "+parkingSpace[i].getOwnerName());
			parkingSpace[i]=null;
			return true;
		}
		}
		
	}
	return false;
}

/**
 * this method will show the list of the cars parked at there respective floor and position
 * where they were parked at the start.
 */
public void showParking(){
	
			for (int i=0;i<15;i++) {
				if(parkingSpace[i]!=null){
					if(i<5)System.out.println(parkingSpace[i].getToken().getToken()+"--"+parkingSpace[i].getCarName()+"-- parked on floor #1 at position "+(i+1)%5);
					if(i>=5 && i<9)System.out.println(parkingSpace[i].getToken().getToken()+"--"+parkingSpace[i].getCarName()+"-- parked on floor #2 at position "+(i+1)%4);
					if(i>=9 && i<12)System.out.println(parkingSpace[i].getToken().getToken()+"--"+parkingSpace[i].getCarName()+"-- parked on floor #3 at position "+(i+1)%3);
					if(i>=12 && i<15)System.out.println(parkingSpace[i].getToken().getToken()+"--"+parkingSpace[i].getCarName()+"-- parked on floor #4 at position "+(i+1)%2);
					if(i==15)System.out.println(parkingSpace[i].getToken().getToken()+"--"+parkingSpace[i].getCarName()+"-- parked on floor #5 at position 1");
				
				}
				}
			}
/**
 * this method searches for first available space in the parking and returns the index of the available slot.
 * @param parking is the array of car parking to be searched for the available space.
 * @return index of available position or 16 if no space is available.
 */
public int searchSpace(Car[] parking){
	for(int i=0;i<15;i++){
		if(parking[i]==null){
			return i;		
		}
	}
	return 16;
}
}