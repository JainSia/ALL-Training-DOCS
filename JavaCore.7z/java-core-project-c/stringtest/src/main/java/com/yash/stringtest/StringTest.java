package com.yash.stringtest;

public class StringTest {

	public boolean getintern() {
		String str1= new String("Hello");
		String str2="Hello";
		String str3=str1.intern();
		if(str2==str3)		
		 {return true;}
		else
		{
			 return false;
		}

	
	}

}
