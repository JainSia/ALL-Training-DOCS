package enumdemo;
public class TestEnum
{
public static void main(String[] args) {
	Color color=Color.RED;
	System.out.println(color.ordinal());
}	
}