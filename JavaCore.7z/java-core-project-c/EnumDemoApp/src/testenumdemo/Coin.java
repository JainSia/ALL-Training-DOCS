package testenumdemo;

public enum Coin {
 PENNY(1) {
	@Override
	public String currencyColor() {
		return "Copper";
	}
},
 NICKLE(5) {
	@Override
	public String currencyColor() {
		return "Bronze";
	}
},
 DIME(10) {
	@Override
	public String currencyColor() {
		return "Silver";
	}
},
 QUATAR(25) {
	@Override
	public String currencyColor() {
		return "Silver";
	}
};
 private int value;
 private Coin(int value)
 {
	 this.value=value;
 }
 @Override
public String toString() {
	 switch(this){
		case PENNY:return "Penny coin "+value+" Color :"+currencyColor();
		case NICKLE:return"Nickle coin "+value+" Color :"+currencyColor();
		case DIME:return"Dime coin "+value+" Color :"+currencyColor();
		case QUATAR:return"Quatar coin "+value+" Color :"+currencyColor();
		}
	 return super.toString();
}
 abstract public String currencyColor();
};
