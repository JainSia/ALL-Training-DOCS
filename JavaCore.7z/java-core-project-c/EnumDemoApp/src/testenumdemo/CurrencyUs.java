package testenumdemo;

public class CurrencyUs {

	public static void main(String[] args) {
		Coin coin= Coin.DIME;
        System.out.println(coin);

	}

}
