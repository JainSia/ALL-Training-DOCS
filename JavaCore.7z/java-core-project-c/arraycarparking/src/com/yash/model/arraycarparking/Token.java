package com.yash.model.arraycarparking;
/**
 * this will provide token to user
 * @author chetan.magre
 *
 */

public class Token {
/**
 * token number of parked car
 */
private int tokenno;
private Car car;
public Token(int tokenno, Car car) {
	this.tokenno=tokenno;
	this.car=car;
}
public int getTokenno() {
	return tokenno;
}
public void setTokenno(int tokenno) {
	this.tokenno = tokenno;
}
public Car getCar() {
	return car;
}
public void setCar(Car car) {
	this.car = car;
}
@Override
	public String toString() {
				
	if(6>(this.getTokenno()))return "[Token Number is: "+this.getTokenno()+" "+car.toString()+" parked at 1st floor ]";
	if(5<(this.getTokenno())&&10>(this.getTokenno()))return "[Token Number is: "+this.getTokenno()+" "+car.toString()+" parked at 2nd floor ]";
	if(9<(this.getTokenno())&&13>(this.getTokenno()))return "[Token Number is: "+this.getTokenno()+" "+car.toString()+" parked at 3rd floor ]";
	if(12<(this.getTokenno())&&115>(this.getTokenno()))return "[Token Number is: "+this.getTokenno()+" "+car.toString()+" parked at 4th floor ]";
	else 
	if(15==(this.getTokenno()))return "[Token Number is: "+this.getTokenno()+" "+car.toString()+" parked at 5th floor ]";
	else return null; 
    }

}
