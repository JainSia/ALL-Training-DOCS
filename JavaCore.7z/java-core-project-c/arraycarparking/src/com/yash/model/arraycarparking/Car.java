package com.yash.model.arraycarparking;
/**
 * this will store the details of car parked in parking zone
 * @author chetan.magre
 *
 */
public class Car {
/**
 * registration number of car
 */
private int registrationno;
/**
 * name of the car
 */
private String carname;
/**
 * owner name of the car
 */
private String ownername;

public Car() {
	
}
public int getRegistrationno() {
	return registrationno;
}
public void setRegistrationno(int registrationno) {
	this.registrationno = registrationno;
}
public String getCarname() {
	return carname;
}
public void setCarname(String carname) {
	this.carname = carname;
}
public String getOwnername() {
	return ownername;
}
public void setOwnername(String ownername) {
	this.ownername = ownername;
}
@Override
	public String toString() {
		return "Registration no: "+this.getRegistrationno()+" Car Name: "+this.getCarname()+" Owner Name: "+this.getOwnername();
	}
}
