package com.yash.service.arraycarparking;
/**
 * this will provide parking services
 */

import com.yash.model.arraycarparking.Car;
import com.yash.model.arraycarparking.Token;

public class CarParking {
	private  Token token[];
	private int location;
	private int tokenno=1;
	public CarParking() {
	token=new Token[15];
	location=0;
	}
    /**
     * this will park a car and return a token
     * @param car
     * @return
     */
	public int parkACar(Car car)
	{if(location<token.length)
	 {	if(token[location]==null)
		{
		Token tokenn=new Token(tokenno,car);
		token[location++]=tokenn;
		tokenno++;
		return token[(location-1)].getTokenno();
	   }
	 }
	else
	{ int i =0;
	  while(token[i]!=null){i++;}
	  Token tokenn=new Token((i+1),car);
	  token[i]=tokenn;
	  return ++i;
	}
		return 0;
	}
	
	/**
	 * this will return all parked car list 
	 * @return
	 */
	public Token [] listParkedCar() {
		Token [] parkedcars=new Token[location];
		for(int i=0;i<location;i++)
		{
			parkedcars[i]=token[i];
		}
		return parkedcars;
	}
	/**
	 * this will check the parking area and take out the car
	 * @param tokenno
	 * @return
	 */
	
	public String takeOutAcar(int tokenno)
	{int i=0;
	if(location==0){
		return "parking area is empty, No car/token exist";
	}
	else
	   {
		 for(i=0;i<token.length;i++)
		 {  if(token[i]==null)
		    {continue;}
		    else
		    { if(tokenno==token[i].getTokenno())
			  {
	            token[i]=null;
	            return "car removed";
	          }continue;
		    }
	     }
		 return "Token Not found";
       }
    }
	
	/**
	 * this will list the number of cars parked per floor
	 */
	public void showparkedCount() {
		int countt=0,i=0;
		while(i<5)
		{if(token[i]==null)
			{i++;continue;}
			countt++;i++;
		}	System.out.println("car parked at 1st floor is "+countt); countt=0;
		
		while(4<i&&i<9)
		{if(token[i]==null)
			{i++;continue;}
			countt++;i++;
		}System.out.println("car parked at 2nd floor is "+countt); countt=0;
		
		while(8<i&&i<12)
		{if(token[i]==null)
			{i++;continue;}
			countt++;i++;
		}System.out.println("car parked at 3rd floor is "+countt); countt=0;
		
		while(11<i&&i<14)
		{if(token[i]==null)
			{i++;continue;}
			countt++;i++;
		}System.out.println("car parked at 4th floor is "+countt);
		
		if(token[14]==null) System.out.println("car parked at 5th floor is 0");
		else System.out.println("car parked at 5th floor is 1");
	}
}