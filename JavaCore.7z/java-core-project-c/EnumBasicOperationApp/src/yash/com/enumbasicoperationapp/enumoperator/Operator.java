package yash.com.enumbasicoperationapp.enumoperator;

public enum Operator {
 PLUS('+'),
 MINUS('-'),
 TIMES('*'),
 DIVIDE('/');
	private int a;
	private int b;
	char operation;
	private Operator(char operation){
		this.operation=operation;
	}
	public void setOperands(int a,int b){
		this.a=a;this.b=b;
	}
	@Override
	public String toString() {
		switch(this){
		case PLUS:return a+""+operation+""+b+" = "+(a+b);
		case MINUS: return a+""+operation+""+b+" = "+(a-b);
		case TIMES:return a+""+operation+""+b+" = "+(a*b);
		case DIVIDE:return a+""+operation+""+b+" = "+(a/b);
		}
		return super.toString();
	}
}
