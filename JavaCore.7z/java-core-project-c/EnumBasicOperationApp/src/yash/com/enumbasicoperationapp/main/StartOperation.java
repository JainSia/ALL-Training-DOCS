package yash.com.enumbasicoperationapp.main;

import yash.com.enumbasicoperationapp.enumoperator.Operator;

public class StartOperation {

	public static void main(String[] args) {
		Operator opertor = Operator.MINUS;
		opertor.setOperands(5, 7);
		System.out.println(opertor);
        
	}

}
