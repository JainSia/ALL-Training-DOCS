package com.yash.sumofnumberbetween100and200;

public class SumOfNumber {

	public int getSumOfnumberBetween100and200() {
       int i=101, sum=0;
       
		while(i<=200)
       {
    	   if(i%7==0)
    	   {
    		   sum+=i;
    	   }
    	   i+=1;
       }
		return sum;
	}

}
