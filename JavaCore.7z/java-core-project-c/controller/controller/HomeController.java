
public class HomeController implements Controller
{
	//HomeController hom =new HomeController();

	public Controller getController(String name) {
		HomeController hom =new HomeController();
		System.out.println("Control type is "+name);
		return hom;
	}

	@Override
	public void activate() {
		System.out.println("Home controller is activated");
		
	}

}
