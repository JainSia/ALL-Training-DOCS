
public class AdminController implements Controller {
	
	public Controller getcontroller(String name) {
     AdminController adm= new AdminController();
	 System.out.println("Control is "+name);
	 return adm;
	}

	@Override
	public void activate() {
		System.out.println("Admin Controller is activated");
		
	}

}
