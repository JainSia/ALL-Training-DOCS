 public class FrontController 
{
  public void geturl(String url)
  {
	  int lastindex=url.lastIndexOf("/");
	  String suburl =url.substring(lastindex);
	  lastindex = suburl.lastIndexOf(".");
	  suburl=suburl.substring(1,lastindex);
	  System.out.println(suburl);
     Controller con =Controller.getcontroller(suburl);
     con.activate();
  }
  
  
}
