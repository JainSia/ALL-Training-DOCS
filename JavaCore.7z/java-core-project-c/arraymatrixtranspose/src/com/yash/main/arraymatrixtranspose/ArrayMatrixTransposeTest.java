package com.yash.main.arraymatrixtranspose;
/**
 * this will take user input of 4x4matrix and will show transpose result 
 */
import java.util.Scanner;

import com.yash.service.arraymatrixtranspose.ArrayMatrixTranspose;

public class ArrayMatrixTransposeTest {
     
	public static void main(String[] args) {
		int [][]matrix=new int[4][4];
    System.out.println("Enter elemnts in 4x4 matrix");
    Scanner scan = new Scanner(System.in);
    for(int i=0;i<4;i++)
     {for(int j=0;j<4;j++)
      {
    	matrix[i][j]=scan.nextInt();
      } 	
     }
	System.out.println("you have entered");
	for(int i=0;i<4;i++)
    {for(int j=0;j<4;j++)
     {
   	System.out.print(matrix[i][j]+"  ");
     } 	
    System.out.println();
    }
	System.out.println("after transpose");
	ArrayMatrixTranspose matrixtarans= new ArrayMatrixTranspose();
	matrix= matrixtarans.transpose(matrix);
	for(int i=0;i<4;i++)
    {for(int j=0;j<4;j++)
     {
   	System.out.print(matrix[i][j]+" ");
     }System.out.println(); 	
    }
	}
}
