package com.yash.service.arraymatrixtranspose;
/**
 * this will provide service to main by transposing the matrix  
 * @author chetan.magre
 *
 */
public class ArrayMatrixTranspose {
/**
 * this wil return transpose of given matrix
 * @param matrix
 * @return
 */
	public int[][] transpose(int[][] matrix) {
		int matrixtemp[][]=new int[matrix.length][matrix.length];
		for(int i=0;i<matrix.length;i++)
		{for(int j=0;j<matrix.length;j++)
		  {
			matrixtemp[j][i]=matrix[i][j];
		  }		
		}
		return matrixtemp;
	}

}
