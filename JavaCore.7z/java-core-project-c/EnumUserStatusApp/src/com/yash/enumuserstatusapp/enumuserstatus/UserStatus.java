package com.yash.enumuserstatusapp.enumuserstatus;
/**
 * Enum for user status
 * @author chetan.magre
 *
 */
public enum UserStatus {
	ACTIVE,
	INACTIVE,
	PENDING,
	DELETED;
}
