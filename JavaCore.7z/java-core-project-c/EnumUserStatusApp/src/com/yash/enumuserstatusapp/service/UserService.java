package com.yash.enumuserstatusapp.service;
/**
 * this will provide services
 */

import java.util.ArrayList;
import java.util.List;
import com.yash.enumuserstatusapp.model.User;

public class UserService {
 List<User> users=null;
 public UserService() {
	 users=new ArrayList<User>();
 }
 /**
  * this will add user with his status
  * @param user
  */
 public void createUser(User user){
	 users.add(user);
	 System.out.println("User Added");
 }
 /**
  * this will return all user along with there status
  * @return
  */
 public List<User> listUser()
 {
	 return users;
 }
}
