package com.yash.enumuserstatusapp.main;

import java.util.List;
import java.util.Scanner;
import com.yash.enumuserstatusapp.enumuserstatus.UserStatus;
import com.yash.enumuserstatusapp.model.User;
import com.yash.enumuserstatusapp.service.UserService;

public class StartApp {

	public static void main(String[] args) {
     UserService service=new UserService();
     User user=null;
     Scanner scanner=new Scanner(System.in);
     String cont=null;
     do{ 
    	 System.out.println("1.add user");
         System.out.println("2.list user");
    	 System.out.println("Enter Your Choice....");
    	 int choice=scanner.nextInt();
    	 switch(choice){
    	 case 1: user=new User();
    	         System.out.println("Enter Name ");
    	         scanner.nextLine();
    	         user.setUserName(scanner.nextLine());
    	         System.out.println("Enter Status (ACTIVE/INACTIVE/PENDING/DELETED)");
    	         String status=scanner.next();
    	         switch (status.toLowerCase()) {
	    	        case "active": user.setStatus(UserStatus.ACTIVE);break;
		            case "inactive":user.setStatus(UserStatus.INACTIVE);break;
		            case "pending":user.setStatus(UserStatus.PENDING);break;
		            case "deleted":user.setStatus(UserStatus.DELETED);break;
		            default:System.out.println("Invalid choice");break;
		           }
                 service.createUser(user);break;
    	 case 2:List<User> list=service.listUser();
    	        for (User user1 : list) {
    			System.out.println(user1);
    	        }break;
    		 default: System.out.println("Invalid choice.....");
    	 }
    	 System.out.println("Do you want to continue.....(Y/N)");
         cont=scanner.next();     
     }while(cont.contentEquals("y"));
	}

}
