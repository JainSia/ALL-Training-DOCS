package com.yash.enumuserstatusapp.model;
/**
 * this will store user information 
 */
import com.yash.enumuserstatusapp.enumuserstatus.UserStatus;

public class User {
	/**
	 * name of the user
	 */
 private String userName;
 /**
  * working status of user
  */
 private UserStatus status;
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public UserStatus getStatus() {
	return status;
}
public void setStatus(UserStatus status) {
	this.status = status;
}
 @Override
	public String toString() {
	 return "User Name : "+this.getUserName()+"  Status: "+this.getStatus();
	}
}
