package com.yash.main.arraysalutations;
/**
 * application will start from here and takes the person's details
 */

import java.util.Scanner;

import com.yash.service.arraysalutations.SalutationService;

public class StartSalutation {
	private static Scanner scan ;
	public static void main(String[] args) {
		String check;
	SalutationService saluationservice=new SalutationService();
		do
		{   scan =new Scanner(System.in);
			System.out.println("*********Main***********");
            System.out.println("1.Enter Name");
            System.out.println("2.View Name/Names");
            System.out.println("0.Exit");
            System.out.println("Enter your choice");
            int choice=scan.nextInt();
            switch (choice) {
			case 1:{
				     System.out.println("Enter Name: ");
				     scan.nextLine();
				     String name=scan.nextLine();
				     System.out.println("Enter Gender(M/F): ");
                     char gender=scan.nextLine().charAt(0);
				     System.out.println("Enter Martial Status(M/U/W): ");
				     char martial_status=scan.nextLine().charAt(0);
				     saluationservice.addPerson(name,gender,martial_status);
			      }break;
			case 2:{
				  saluationservice.presentsNames();
			       }break;
			case 3:{System.exit(0);}
			default:System.out.println("Invalid choice");
				break;
			}
            System.out.println("Do you want to continue....(Y/N)");
            check=scan.next();
		}while(check.equalsIgnoreCase("y"));

	}

}
