package com.yash.service.arraysalutations;
/**
 * this will provide repository for storing names of persons and provide services to list and add a new person  
 * @author chetan.magre
 *
 */
public class SalutationService {
/**
 *this is the array repository to store names 
 */ 
 String[][] namerepository;
 private int size =10;
 /**
  * index for male person in repository
  */
 static int maleindex;
 /**
  * index for female person in repository who are unmarried
  */
 static int unmarriedfemaleindex;
 /**
  * index for female person in repository who are married 
  */
 static int marriedfemaleindex;
 /**
  * index for female person in repository who are divorced or widow
  */
 static int divorcedfemaleindex;
 public SalutationService() {
	  maleindex=1;
	  unmarriedfemaleindex=1;
	  marriedfemaleindex=1;
	  divorcedfemaleindex=1;
	  namerepository = new String[4][size];
	  namerepository[0][0]="Mr";
	  namerepository[1][0]="Miss";
	  namerepository[2][0]="Mrs";
	  namerepository[3][0]="Ms";
}
 /**
  * this will add the names of person into the name repository according to their gender and martial status
  * @param name
  * @param gender
  * @param martial_status
  */
public void addPerson(String name, char gender, char martial_status) {
	if(gender=='m'||gender=='M')
	{
		addMalePerson(name);
	}else if(gender=='F'||gender=='f')
	{
		addFemalePerson(name,martial_status);
	}else
	{
		System.out.println("Invalid Input");
	}
	
}
/**
 * this will the names of females in name repository according to their martial status
 * @param name
 * @param martial_status
 */
private void addFemalePerson(String name, char martial_status) {
	if(martial_status=='m'||martial_status=='M')
	{
		namerepository[2][marriedfemaleindex++]=name;
	}else if(martial_status=='u'||martial_status=='U')
	{
		namerepository[1][unmarriedfemaleindex++]=name;
	}else
	{
		namerepository[3][divorcedfemaleindex++]=name;
	}
	
}
/**
 * this will add the name of male in the name repository 
 * @param name
 */
private void addMalePerson(String name) {
	namerepository[0][maleindex++]=name;
	
}
/**
 * this will list all the names in the repository along with their salutation
 */
public void presentsNames() {
if(maleindex>1)
for(int j=1;j<maleindex;j++)
{
 System.out.println(namerepository[0][0]+" "+namerepository[0][j]);
}
if(unmarriedfemaleindex>1)
for(int j=1;j<unmarriedfemaleindex;j++)
{
System.out.println(namerepository[1][0]+" "+namerepository[1][j]);
}
if(marriedfemaleindex>1)
for(int j=1;j<marriedfemaleindex;j++)
{
System.out.println(namerepository[2][0]+" "+namerepository[2][j]);
}
if(divorcedfemaleindex>1)
for(int j=1;j<divorcedfemaleindex;j++)
{
System.out.println(namerepository[3][0]+" "+namerepository[3][j]);
}
	
}
 
}
