package com.yash.fileioapp.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class MenuService {
 
 public static void showmenu() throws IOException {
	 
		File file=new File("menu.txt");
	    file.createNewFile();
	    FileReader fileReader= new FileReader(file);
	    BufferedReader bufferedReader=new BufferedReader(fileReader);
	    String line=bufferedReader.readLine();
	    while(line!=null) {
			System.out.println(line);
			line=bufferedReader.readLine();
		}
	    bufferedReader.close();

}
 public static void showLoginMenu() throws IOException{
	 File file=new File("loginMenu.txt");
	    file.createNewFile();
	    FileReader fileReader= new FileReader(file);
	    BufferedReader bufferedReader=new BufferedReader(fileReader);
	    String line=bufferedReader.readLine();
	    while(line!=null) {
			System.out.println(line);
			line=bufferedReader.readLine();
		}
	    bufferedReader.close();
 }
}
