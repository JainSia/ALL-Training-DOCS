package com.yash.fileioapp.documentservice;

import java.util.List;

import com.yash.fileioapp.model.TrainerDocument;

public interface DocumentService {
	public void createDocument(TrainerDocument document);
	public void deleteDocument(String documentName);
	public void updateDocument(TrainerDocument document);
    public TrainerDocument findDocument(String documentName);
    public List<TrainerDocument> showDocumentWithActiveStatus();
    public List<TrainerDocument> showDocumentWithReadStatus();
    public List<TrainerDocument> showDocumentWithNonActiveStatus();
	public List<TrainerDocument> showDocument();

}
