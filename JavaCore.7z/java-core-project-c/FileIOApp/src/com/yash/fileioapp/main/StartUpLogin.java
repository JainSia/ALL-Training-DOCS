package com.yash.fileioapp.main;

import java.io.IOException;
import java.util.Scanner;
import com.yash.fileioapp.model.Admin;
import com.yash.fileioapp.model.Trainer;
import com.yash.fileioapp.service.MenuService;

public class StartUpLogin {
 public static void main(String[] args) throws IOException {
  Trainer trainer= new Trainer();
  Admin admin=new Admin();
  String conti;
  Scanner scanner = new Scanner(System.in);
 do{ MenuService.showLoginMenu();
     int choice=scanner.nextInt();
     System.out.print("Enter UserName : ");
     String user=scanner.next();
     System.out.print("Enter Password : ");
     String pass=scanner.next();
     switch (choice) {
	case 1:  trainer.checkUserLogin(user, pass);break;
	case 2: System.out.println("Option not Available");
	case 3:  admin.checkUserLogin(user, pass);break;
	default: System.out.println("Invalid Choice....");
		break;
	}
    
     System.out.println("Switch Account....(y/n)");
	 conti=scanner.next();
 }while(conti.equalsIgnoreCase("y"));	
 }
}
