package com.yash.fileioapp.main;

import java.io.IOException;
import java.util.List;
import java.util.Scanner;
import com.yash.fileioapp.documentserviceimpl.DocumentServiceImpl;
import com.yash.fileioapp.model.TrainerDocument;
import com.yash.fileioapp.service.MenuService;

public class StartUpTrainer {
public static void activateTrainerMenu() throws IOException {
	Scanner scanner=new Scanner(System.in);
	DocumentServiceImpl documentServiceImpl=new DocumentServiceImpl();
	TrainerDocument document;
	String cont;
	do{ 
		MenuService.showmenu();
		int choice=scanner.nextInt();
		switch (choice) {
		case 1: document=new TrainerDocument();
		        System.out.println("Enter Name Of Document You want to create");
		        document.setDocName(scanner.next());
		        documentServiceImpl.createDocument(document);
		       	break;
		case 2: System.out.println("Enter Name Of Document You want to create");
                String docName=scanner.next();
                documentServiceImpl.deleteDocument(docName);
       	        break;
		case 3: document=new TrainerDocument();
                System.out.println("Enter Name Of Document You want to update");
                document.setDocName(scanner.next());
                System.out.println("Change Read Status (Seen/Unseen)");
                String read=scanner.next();
                if(read.equalsIgnoreCase("seen")||read.equalsIgnoreCase("unseen"))
                {document.setReadStatus(read);}else {System.out.println("Invalid status"); break;}
                System.out.println("Change Activation Status (Active/InActive)");
                String active=scanner.next();
                if(active.equalsIgnoreCase("Active")||active.equalsIgnoreCase("InActive"))
                {document.setActiveStatus(active);}else {System.out.println("Invalid status"); break;}
                documentServiceImpl.updateDocument(document);
       	        break;
		case 4: System.out.println("Enter Name Of Document You want to find");
                String docuName=scanner.next();
                document= documentServiceImpl.findDocument(docuName);
                if(document!=null){System.out.println(document);}
                else{System.out.println("Document not found");}
                break;
		case 5: List<TrainerDocument> list=documentServiceImpl.showDocument();
		        for (TrainerDocument trainerDocument : list) {
				  System.out.println(trainerDocument);	
				}
		        break;
		case 6: List<TrainerDocument> activelist=documentServiceImpl.showDocumentWithActiveStatus();
                for (TrainerDocument trainerDocument : activelist) {
		        System.out.println(trainerDocument);	
		        } 
                break;
		case 7: List<TrainerDocument> inActiveList=documentServiceImpl.showDocumentWithNonActiveStatus();
                for (TrainerDocument trainerDocument : inActiveList) {
                System.out.println(trainerDocument);	
                }  
                break;
		case 8: List<TrainerDocument> readList=documentServiceImpl.showDocumentWithReadStatus();
                for (TrainerDocument trainerDocument : readList) {
                System.out.println(trainerDocument);	
                }  
                break;
		case 0: return;
		default: System.out.println("Invalid Choice");
			break;
		}
		
	 System.out.println("Do You Want to Continue....(Y/N)");
	 cont=scanner.next();
	}while(cont.equalsIgnoreCase("y"));
}
}
