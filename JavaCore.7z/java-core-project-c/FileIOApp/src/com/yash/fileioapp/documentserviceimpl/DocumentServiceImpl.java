package com.yash.fileioapp.documentserviceimpl;

import java.util.ArrayList;
import java.util.List;
import com.yash.fileioapp.documentservice.DocumentService;
import com.yash.fileioapp.model.TrainerDocument;
import com.yash.fileioapp.util.ReadAndWrite;

public class DocumentServiceImpl implements DocumentService{
	List<TrainerDocument> documentRepository;
	public DocumentServiceImpl() {
		documentRepository=ReadAndWrite.readFromDocument();
	}
	@Override
	public void createDocument(TrainerDocument document) {
		document.setActiveStatus("Not Active");
		document.setReadStatus("Unseen");
		documentRepository.add(document);
		ReadAndWrite.writeInDocument(documentRepository); 
	}

	@Override
	public List<TrainerDocument> showDocument() {
		List<TrainerDocument> avalibleDocument = ReadAndWrite.readFromDocument();
		return avalibleDocument;
	}
	@Override
	public void updateDocument(TrainerDocument document) {
		documentRepository = ReadAndWrite.readFromDocument();
		for (TrainerDocument trainerDocument : documentRepository) {
		    if(trainerDocument.getDocName().equalsIgnoreCase(document.getDocName()))
		    {    
		    	 trainerDocument.setActiveStatus(document.getActiveStatus());
		         trainerDocument.setReadStatus(document.getReadStatus());
		         System.out.println("Document updated sucessfully");
		         
		         ReadAndWrite.writeInDocument(documentRepository);
		    }
		}
	}
	@Override
	public void deleteDocument(String documentName) {
		documentRepository = ReadAndWrite.readFromDocument();
		for (TrainerDocument trainerDocument : documentRepository) {
			if(trainerDocument.getDocName().equalsIgnoreCase(documentName))
			{
				documentRepository.remove(trainerDocument);
				System.out.println("Document deleted");
				ReadAndWrite.writeInDocument(documentRepository);
				break;
			}
		}
	}
	@Override
	public TrainerDocument findDocument(String documentName) {
		documentRepository = ReadAndWrite.readFromDocument();
		for (TrainerDocument trainerDocument : documentRepository) {
			if(trainerDocument.getDocName().equalsIgnoreCase(documentName))
			{
				return trainerDocument;
			}
		}
		return null;
	}
	@Override
	public List<TrainerDocument> showDocumentWithActiveStatus() {
		documentRepository = ReadAndWrite.readFromDocument();
		List<TrainerDocument> active=new ArrayList<>();
		for (TrainerDocument trainerDocument : documentRepository) {
			if(trainerDocument.getActiveStatus().equalsIgnoreCase("Active"))
			{
				active.add(trainerDocument);
			}
		}
		return active;
	}
	@Override
	public List<TrainerDocument> showDocumentWithReadStatus() {
		documentRepository = ReadAndWrite.readFromDocument();
		List<TrainerDocument> read=new ArrayList<>();
		for (TrainerDocument trainerDocument : documentRepository) {
			if(trainerDocument.getReadStatus().equalsIgnoreCase("seen"))
			{
				read.add(trainerDocument);
			}
		}
		return read;
	}
	@Override
	public List<TrainerDocument> showDocumentWithNonActiveStatus() {
		documentRepository = ReadAndWrite.readFromDocument();
		List<TrainerDocument> inactive=new ArrayList<>();
		for (TrainerDocument trainerDocument : documentRepository) {
			if(trainerDocument.getReadStatus().equalsIgnoreCase("inactive"))
			{
				inactive.add(trainerDocument);
			}
		}
		return inactive;
	}

}
