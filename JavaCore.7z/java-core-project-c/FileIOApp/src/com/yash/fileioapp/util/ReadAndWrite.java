package com.yash.fileioapp.util;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import com.yash.fileioapp.model.TrainerDocument;

public class ReadAndWrite {
     public static List<TrainerDocument> readFromDocument() {
		FileInputStream documentFile=null;
		ObjectInputStream objectInputStream=null;
		List<TrainerDocument> document=null;
		try {
			documentFile=new FileInputStream("documents.txt");
			objectInputStream=new ObjectInputStream(documentFile);
			document=(ArrayList<TrainerDocument>)objectInputStream.readObject();
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				objectInputStream.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return document;
	}
	 public static void writeInDocument(List<TrainerDocument> document)
	 {  FileOutputStream documentFile=null;
	    ObjectOutputStream objectOutputStream=null; 
	   try{
		 documentFile=new FileOutputStream("Documents.txt");
		 objectOutputStream=new ObjectOutputStream(documentFile);
		 objectOutputStream.writeObject(document);
		 objectOutputStream.flush();
	   }
	  catch (IOException e) {
		e.printStackTrace();
	}  
	   finally {
		   try {
			objectOutputStream.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
		
	 }
}
