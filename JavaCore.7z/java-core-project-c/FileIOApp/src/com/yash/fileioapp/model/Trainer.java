package com.yash.fileioapp.model;

import java.io.IOException;

import com.yash.fileioapp.main.StartUpTrainer;

public class Trainer {
	private String trainerName="chetan"; 
	private String password="admin";
	public String getTrainerName() {
			return trainerName;
		}
	public String getPassword() {
			return password;
		}
	public int checkUserLogin(String username,String password) {
		   if(username.equalsIgnoreCase(getTrainerName())&&password.equals(getPassword()))
		   {   try {System.out.println("Trainer logged-In");
				StartUpTrainer.activateTrainerMenu();
			   } catch (IOException e) {
				e.printStackTrace();
			   }
		   }else{return 0;}
           return 0;
		 }
}
