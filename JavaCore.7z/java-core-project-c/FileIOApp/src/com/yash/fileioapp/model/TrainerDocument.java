package com.yash.fileioapp.model;

import java.io.Serializable;

public class TrainerDocument implements Serializable {
  private String docName;
  private String readStatus;
  private String activeStatus;
public String getDocName() {
	return docName;
}
public void setDocName(String docName) {
	this.docName = docName;
}
public String getReadStatus() {
	return readStatus;
}
public void setReadStatus(String readStatus) {
	this.readStatus = readStatus;
}
public String getActiveStatus() {
	return activeStatus;
}
public void setActiveStatus(String activeStatus) {
	this.activeStatus = activeStatus;
}
@Override
	public String toString() {
		return "Document Name : "+this.getDocName()+" Read status : "+this.getReadStatus()+" Active Status : "+this.getActiveStatus();
	}
}
