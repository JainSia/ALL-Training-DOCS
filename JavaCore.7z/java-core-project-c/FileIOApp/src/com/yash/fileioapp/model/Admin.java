package com.yash.fileioapp.model;

public class Admin {
 private String AdminName="Chetan Magre";
 private String userName="chetan"; 
 private String password="123";
 
 public String getAdminName() {
	return AdminName;
}
 public String getUserName() {
		return userName;
	}
 public String getPassword() {
		return password;
	}
public void checkUserLogin(String user, String pass) {
	 if(user.equalsIgnoreCase(getUserName())&&pass.equals(getPassword()))
	 {
		 System.out.println(" Admin Logged-In");
	 }else{System.out.println("Invalid UserName or password");} return;
}
}
