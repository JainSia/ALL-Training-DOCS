package com.yash.factorialcalcuate;

import junit.framework.TestCase;

public class FactorialCalculate extends TestCase {

	public long fact(int i) {
		int total=1;
		if(i<=0)
		{ if(i<0)
		   {return 0;}
		else
			return 1;
		}
		else
		{
		for(int j=i;j>=1;j--)
		{
			total=total*j;
		}
		return total;
		}
		
	}

}
