package com.yash.factorialcalcuate;

import org.junit.Before;
import org.junit.Test;

import junit.framework.TestCase;

public class FactorialCalculateTest extends TestCase {
    private FactorialCalculate factorial;
	@Before
    public void setUp() throws Exception
    {
    	factorial= new FactorialCalculate();
    }
	@Test
	public void test_for_return_factorial_of_input0() throws Exception
	{   long result=factorial.fact(0);
		assertEquals(1,result);
	}
	@Test
	public void test_for_return_factorial_of_input1() throws Exception
	{   long result=factorial.fact(1);
		assertEquals(1,result);
	}
	@Test
	public void test_for_return_factorial_of_max_input_to16() throws Exception
	{   long result=factorial.fact(16);
	    System.out.println(result);
		assertEquals(2004189184,result);
	}
}
