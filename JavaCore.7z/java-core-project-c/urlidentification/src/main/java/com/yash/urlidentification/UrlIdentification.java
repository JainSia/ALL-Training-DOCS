package com.yash.urlidentification;

public class UrlIdentification {

	public String getCommand(String url) 
	{
		  int lastindex=url.lastIndexOf("/");
		
		  String suburl =url.substring(lastindex);
		  
		  lastindex = suburl.lastIndexOf(".");
		  
		  suburl=suburl.substring(1,lastindex);
		
		  return suburl;
	}

}
