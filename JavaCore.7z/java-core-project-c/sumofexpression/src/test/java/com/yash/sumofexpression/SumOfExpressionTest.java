package com.yash.sumofexpression;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class SumOfExpressionTest {

	private static final String ANY_SINGLE_VALID_STRING_WITHOUT_EXPRESSION_AS_INPUT="1+2+3+4+5";
	private SumOfExpression sumexpression;
	@Before
	public void setUp() throws Exception{
		sumexpression = new SumOfExpression();
	}
	@Test
	public void test_for_empty_input() throws Exception
	{   int result=sumexpression.add("");
		assertEquals(0,result);
	}
	
	@Test
	public void test_for_single_value_input_as_Any_Single_Number() throws Exception
	{  int result=sumexpression.add(ANY_SINGLE_VALID_STRING_WITHOUT_EXPRESSION_AS_INPUT);
		assertEquals(15,result);
	}
	
	@Test
	public void test_for_two_number_seprated_by_plussign_return_sum_of_input() throws Exception
	{  int result=sumexpression.add("1+2");
		assertEquals(3,result);
	}

	@Test
	public void test_for_three_number_seprated_by_plussign_return_sum_of_input() throws Exception
	{  int result=sumexpression.add("1+2+3+400");
		assertEquals(406,result);
	}
	@Test
	public void test_for_invalid_number_seprated_by_plussign_return_sum_of_input_string() throws Exception
	{  int result=sumexpression.add("1+2+3+400++");
		assertEquals(-1,result);
	}
}
