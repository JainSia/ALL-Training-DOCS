package com.yash.sumofexpression;

import java.util.Arrays;

//import java.util.Arrays;

public class SumOfExpression {

	public int add(String expression) {
		if(expression.isEmpty())
		{	return 0;}
		else if(expression.charAt(0)=='+'||expression.charAt(expression.length()-1)=='+')
		{
			return -1;
		}
		else{
			int index;
			for(index=0;index<expression.length();index++)
			{
				if(expression.charAt(index)=='+'&&expression.charAt(index+1)=='+')
				{
					return -1;
				}
			}
		return Arrays.stream(expression.split("\\+")).mapToInt(Integer::parseInt).sum();
		}
	}
}
