package com.yash.service.revreseitstring;
/**
 * this will provide services to ReverseIt
 * @author chetan.magre
 *
 */
public class ReverseIT {
/**
 * this will reverse the string and return
 * @param str
 * @return
 */
	public String reverseIt(String str) {
		char string[]=str.toCharArray();
		int frontcount=0;
		int backcount=string.length-1;
		while(frontcount<=backcount)
		{
			char a=string[frontcount];
			string[frontcount]=string[backcount];
			string[backcount]=a;
			frontcount++;
			backcount--;
		}
		String revstring =String.valueOf(string);
		return revstring;
	}

}
