package com.yash.reflectiondompojoapp.interfaceservice;

public interface Pojo {

}
