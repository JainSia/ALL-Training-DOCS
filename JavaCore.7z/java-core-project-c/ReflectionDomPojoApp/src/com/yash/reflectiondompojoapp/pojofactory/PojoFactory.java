package com.yash.reflectiondompojoapp.pojofactory;

import java.io.File;


import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.yash.reflectiondompojoapp.exception.PojoIsNotRegisteredInXMLFileException;
import com.yash.reflectiondompojoapp.exception.PojoNotAvailabileInTheProjectException;
import com.yash.reflectiondompojoapp.interfaceservice.Pojo;
import com.yash.reflectiondompojoapp.pojo.Application;
import com.yash.reflectiondompojoapp.pojo.Project;
import com.yash.reflectiondompojoapp.pojo.User;


public class PojoFactory {
	Application app=null;
	User user=null;
	Project project=null;
	
	private PojoFactory() {
	}
	
	public  Pojo getPojoObject(String type) throws Exception{
		File file =new File("pojo.xml");
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db=dbf.newDocumentBuilder();
		Document document=db.parse(file);
		NodeList doc=document.getDocumentElement().getChildNodes();
		for (int i = 0; i < doc.getLength(); i++) {
			Node node=doc.item(i);
			if (node.getNodeType() == Node.ELEMENT_NODE)
			 {Element element=(Element)node;
	  
			         if(type.equalsIgnoreCase(element.getAttribute("id"))){
				          if(type.equalsIgnoreCase("application")){
			        	  String str = element.getAttribute("class");
				          if(app==null){
				  	      app=(Application)Class.forName(str).newInstance();
				  	      app.setId(Integer.parseInt(element.getElementsByTagName("id").item(0).getTextContent()));
				  	      app.setAppName(element.getElementsByTagName("appname").item(0).getTextContent());
				          return app;
				          }else{return app;}	 
			              } else
			              if(type.equalsIgnoreCase("user")){
			        	  String str = element.getAttribute("class");
				          if(user==null){
				  	      user=(User)Class.forName(str).newInstance();
				  	      user.setId(Integer.parseInt(element.getElementsByTagName("id").item(0).getTextContent()));
				  	      user.setUserName(element.getElementsByTagName("username").item(0).getTextContent());
				          return user;
				          }else{return user;}	 
			              } else
			              if(type.equalsIgnoreCase("Project")){
	        	          String str = element.getAttribute("class");
	        	          
		                  if(project==null){
		  	              project=(Project)Class.forName(str).newInstance();
		  	              project.setId(Integer.parseInt(element.getElementsByTagName("id").item(0).getTextContent()));
		  	              project.setProjectName(element.getElementsByTagName("projectname").item(0).getTextContent());
		                  return project;
		                  }else{return project;}	 
	                      } 
			              else
			              {
			            	  throw new PojoNotAvailabileInTheProjectException("Pojo does not Exist in the Project");
			              }
			          } 
			 }
		}
		throw new PojoIsNotRegisteredInXMLFileException("Pojo is Not Registered in Xml File");
	}
	
}
