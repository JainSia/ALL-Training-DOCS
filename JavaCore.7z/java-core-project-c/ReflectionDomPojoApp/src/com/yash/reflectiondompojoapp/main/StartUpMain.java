package com.yash.reflectiondompojoapp.main;

import java.lang.reflect.Constructor;

import com.yash.reflectiondompojoapp.pojo.Application;
import com.yash.reflectiondompojoapp.pojo.Project;
import com.yash.reflectiondompojoapp.pojo.User;
import com.yash.reflectiondompojoapp.pojofactory.PojoFactory;

public class StartUpMain {

	public static void main(String[] args) throws Exception {
		Class c=Class.forName("com.yash.reflectiondompojoapp.pojofactory.PojoFactory");
		Constructor[] conslist=c.getDeclaredConstructors();
		conslist[0].setAccessible(true);
		PojoFactory pojo=(PojoFactory)conslist[0].newInstance();
		Application app=(Application)pojo.getPojoObject("application");
		System.out.println(app.getId());
		System.out.println(app.getAppName());
        User user=(User)pojo.getPojoObject("user");
        System.out.println(user.getId());
        System.out.println(user.getUserName());
        Project project=(Project)pojo.getPojoObject("project");
        System.out.println(project.getId());
	}

}
