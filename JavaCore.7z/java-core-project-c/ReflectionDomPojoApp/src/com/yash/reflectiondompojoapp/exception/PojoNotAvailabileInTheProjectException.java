package com.yash.reflectiondompojoapp.exception;

public class PojoNotAvailabileInTheProjectException extends RuntimeException {
   public PojoNotAvailabileInTheProjectException(String errMsg)
   { super(errMsg);
   }
}
