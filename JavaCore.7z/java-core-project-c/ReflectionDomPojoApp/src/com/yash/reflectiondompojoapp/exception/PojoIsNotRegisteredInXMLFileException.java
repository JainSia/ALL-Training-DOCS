package com.yash.reflectiondompojoapp.exception;

public class PojoIsNotRegisteredInXMLFileException extends RuntimeException{
	public PojoIsNotRegisteredInXMLFileException(String errMsg) {
		super(errMsg);
	}

}
