package com.yash.reflectiondompojoapp.pojo;

import com.yash.reflectiondompojoapp.interfaceservice.Pojo;

public class Application implements Pojo {
	private int id;
	private String appName;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	

}
