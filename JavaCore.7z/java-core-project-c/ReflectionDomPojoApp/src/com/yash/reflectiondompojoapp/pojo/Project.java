package com.yash.reflectiondompojoapp.pojo;

import com.yash.reflectiondompojoapp.interfaceservice.Pojo;

public class Project implements Pojo {
 private int id;
 private String projectName;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getProjectName() {
	return projectName;
}
public void setProjectName(String projectName) {
	this.projectName = projectName;
}
}
