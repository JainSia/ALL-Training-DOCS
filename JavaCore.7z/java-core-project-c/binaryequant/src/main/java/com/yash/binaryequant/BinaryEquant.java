package com.yash.binaryequant;

import java.util.Stack;

public class BinaryEquant {
    
	public String calculateBinary(int input) {
		Stack<Integer> stack = new Stack<Integer>();
		int count=0;
		if(input>0)
		{
			while(input!=0)
		{
			int digit = input%2;
			stack.push(digit);
			input=input/2;
			count++;
		}
		int [] binary= new int[count];
		int i=0;
		while(!(stack.isEmpty()))
		{
			binary[i]=stack.pop();
			i++;
		}
		StringBuilder result= new StringBuilder();
		for(int j=0;j<binary.length;j++)
		{
			result.append(binary[j]);
		}
		String str= result.toString();
		System.out.println("binary  is "+str);
		return str;
	    }
		else
		{  int a[] = new int[1];
		   a[0]=0;
			return "0"; 
		}
	}	
}
