package com.yash.onlinetrainingsystem.serviceimpl;
/**
 * this will provide services to admin
 */
import com.yash.onlinetrainingsystem.dao.AdminDao;
import com.yash.onlinetrainingsystem.daoserviceimpl.AdminDaoImpl;
import com.yash.onlinetrainingsystem.model.User;
import com.yash.onlinetrainingsystem.service.AdminService;

public class AdminServiceImpl implements AdminService {
	AdminDao adminDao=new AdminDaoImpl();
	/**
	 * this will list all users to admin 
	 */
	@Override
	public void listAllUser() {
		adminDao.getAllRecords("users");	
	}
	/**
	 * this will list all courses to admin 
	 */
	@Override
	public void listAllCourses() {
		adminDao.getAllRecords("courses");	
	}
	/**
	 * this will update user status 
	 */
	@Override
	public boolean updateUserDetailStatus(User user) {
		boolean status=adminDao.updateStatusOfRecord(user);
		return status;
	}
    /**
     * this will update user role
     */
	@Override
	public boolean updateUserDetailRole(User user,int trainerId) {
		boolean status=adminDao.updateRoleOfRecord(user,trainerId);
		return status;
	}

}
