package com.yash.onlinetrainingsystem.serviceimpl;
/**
 * this will provide services to trainee
 */
import com.yash.onlinetrainingsystem.dao.TraineeDao;
import com.yash.onlinetrainingsystem.daoserviceimpl.TraineeDaoImpl;
import com.yash.onlinetrainingsystem.service.TraineeService;

public class TraineeServiceImpl implements TraineeService {
    TraineeDao traineeDao=new TraineeDaoImpl();
	/**
	 * this will list all the courses available
	 */
    @Override
	public void listAllCourese(String TraineeName) {
		traineeDao.listAllCourses(TraineeName);	
	}
    /**
     * this will check that the trainee is active or not
     */
	@Override
	public boolean checkStatus(String TraineeName) {
		return traineeDao.checkStatus(TraineeName);
		
	}
    
}
