package com.yash.onlinetrainingsystem.serviceimpl;
/**
 * this will provide services to Trainer
 */
import com.yash.onlinetrainingsystem.dao.TrainerDao;
import com.yash.onlinetrainingsystem.daoserviceimpl.TrainerDaoImpl;
import com.yash.onlinetrainingsystem.model.Courses;
import com.yash.onlinetrainingsystem.service.TrainerService;

public class TrainerServiceImpl implements TrainerService{
    private TrainerDao trainerDao=new TrainerDaoImpl();
    private String type="courses";
    /**
     * this will list all trainees
     */
	@Override
	public void listAllTrainees() {
	trainerDao.getRecordsBasedOnRole("trainee", "users");	
	}
    /**
     * this will list all courses added by logged in trainer
     */
	@Override
	public void listAllCourses(String trainerName) {
		trainerDao.getRecordsBasedOnName(trainerName,type);
	}
    /**
     * this will update course details
     */
	@Override
	public boolean updateCourseDetails(Courses course) {
		boolean status=trainerDao.updateRecordOfCourseTable(course);
		return status;
	}
    /**
     * this will add new course
     */
	@Override
	public boolean addNewCourse(Courses course) {
		boolean status=trainerDao.addNewRecordInCourseTable(type,course);
		return status;
	}
    /**
     * this will delete a existing course
     */
	@Override
	public boolean deleteCourse(Courses course) {
		boolean status=trainerDao.deleteRecordByIdInCourseTable(type,course);
		return status;
	}

}
