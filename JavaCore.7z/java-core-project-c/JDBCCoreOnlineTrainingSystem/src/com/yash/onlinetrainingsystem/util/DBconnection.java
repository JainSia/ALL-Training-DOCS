package com.yash.onlinetrainingsystem.util;
import java.io.FileNotFoundException;
/**
 *  this will provide Database Connection 
 */
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBconnection {
	/**
	 * database connection code
	 * @return
	 */
	public Connection DataBaseConnectivity(){
		FileReader fr;
		Connection con=null;
		try {
			fr = new FileReader("JDBC.properties");
			Properties prprt=new Properties();
			prprt.load(fr);
			String driverClassName =prprt.getProperty("driverClassName");
			String url=prprt.getProperty("url");
		    String dbusername=prprt.getProperty("dbusername");
		    String dbpassword=prprt.getProperty("dbpassword");
				Class.forName(driverClassName);
				con=DriverManager.getConnection(url, dbusername, dbpassword);
				return con;
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (ClassNotFoundException e) {
			System.out.println("Driver Not Found / Wrong Driver Class Name");
		} catch (SQLException e) {
			System.out.println("Database path is incorrect / invalid database username password ");
		}
		System.out.println("Connection is Not Established");
		System.exit(0);
		return null;
	}
}
