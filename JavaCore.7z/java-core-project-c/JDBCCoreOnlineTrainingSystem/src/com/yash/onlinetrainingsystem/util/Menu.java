package com.yash.onlinetrainingsystem.util;
/**
 * this will show all the menus according to login status
 */
import java.util.Scanner;

import com.yash.onlinetrainingsystem.dao.LoginDao;
import com.yash.onlinetrainingsystem.dao.RegistrationDao;
import com.yash.onlinetrainingsystem.daoserviceimpl.LoginDaoImpl;
import com.yash.onlinetrainingsystem.daoserviceimpl.RegistrationDaoImpl;
import com.yash.onlinetrainingsystem.model.Courses;
import com.yash.onlinetrainingsystem.model.User;
import com.yash.onlinetrainingsystem.service.AdminService;
import com.yash.onlinetrainingsystem.service.TraineeService;
import com.yash.onlinetrainingsystem.service.TrainerService;
import com.yash.onlinetrainingsystem.serviceimpl.AdminServiceImpl;
import com.yash.onlinetrainingsystem.serviceimpl.TraineeServiceImpl;
import com.yash.onlinetrainingsystem.serviceimpl.TrainerServiceImpl;

public class Menu {
    private int choice;
    private boolean updatestatus;
    private Courses course;
    private User user;
    Scanner scanner=new Scanner(System.in);
    LoginDao loginDao=new LoginDaoImpl();
    AdminService adminServices=new AdminServiceImpl();
    TrainerService trainerService=new TrainerServiceImpl();
    TraineeService traineeService=new TraineeServiceImpl();
    RegistrationDao registrationDao=new RegistrationDaoImpl();
    /**
     * Home Screen Menu 
     */
    public void startMenu() {
		do{
    	System.out.println("---------------Online Training System-----------------");
		System.out.println("1. Login \n2. Register");
		System.out.println("Enter Your Choice....");
	    choice=scanner.nextInt();
		switch (choice) {
		case 1: loginMethod();break;
		case 2: RegisterMethod();break;
		default:System.out.println("Invalid Choice");
		}
		}while(true);
	}
    /**
     * this will register new user
     */
    private void RegisterMethod() {
    	User user = new User();
    	System.out.println("*****************New User Registration*******************");
		System.out.println("Fill all the details......");
		System.out.print("Enter First Name  :");
		user.setFirstname(scanner.next());
		System.out.print("Enter Last Name   :");
		user.setLastname(scanner.next());
		System.out.print("Enter Email Add   :");
		user.setEmail(scanner.next());
		System.out.print("Enter Contact No. :");
		user.setContact(scanner.nextLong());
		System.out.print("Enter username    :");
		user.setUsername(scanner.next());
		System.out.print("Enter password   :");
		user.setPassword(scanner.next());
		boolean status=registrationDao.registerUser(user);
		if(status){System.out.println("User Registered Successfully");}
		else{System.out.println("Registration Unsuccessfull");}
	}
	/**
     * this will take user login credentials and authenticate
     */
	private void loginMethod() {
		System.out.print("Username :");
		String username=scanner.next();
		System.out.print("Password :");
		String password=scanner.next();
		String[] nameAndRole=loginDao.checkLogin(username,password);
		if(nameAndRole[1]!=null){
			System.out.println(nameAndRole[1]+" LOGIN SUCCESSFULL");
			System.out.println("Hello "+nameAndRole[0]);
			switch (nameAndRole[1].toLowerCase()) {
			case "admin":adminMenu(nameAndRole[0]);break;
			case "trainer":trainerMenu(nameAndRole[0]);break;
			case "trainee":traineeMenu(nameAndRole[0]);break;
			default:return;
			}		
		}else
		{
			System.out.println("LOGIN UNSUCCESSFULL please Enter Valid Credentials");
			return;
		}
		
	}
	/**
	 * Trainee Menu and its Services
	 * @param string
	 */
	private void traineeMenu(String traineeName) {
	 if(traineeService.checkStatus(traineeName))
		{do{    
		    System.out.println("*******Trainee Menu********");
			System.out.println("1. List all Courses");
			System.out.println("0. Logout");
			System.out.println("Enter Your Choice....");
			choice=scanner.nextInt();
			switch (choice) {
			case 1:traineeService.listAllCourese(traineeName);break;
			case 0:return;
			default:System.out.println("Invalid Choice.. ");
			}
		}while(true);
		
	}else
	{
		System.out.println("You are Not Active yet Please Contact to Admin to Make Your Account Active");
	}
	}
	/**
	 * Admin Menu and its Services
	 */
	private void adminMenu(String adminName) {
		do{
			System.out.println("*******Admin Menu********");
			System.out.println("1. List all Users");
			System.out.println("2. List all Courses");
			System.out.println("3. Update user Status");
			System.out.println("4. Update user Role");
			System.out.println("0. Logout");
			System.out.println("Enter Your Choice....");
			choice=scanner.nextInt();
			switch (choice) {
			case 1:adminServices.listAllUser();break;
			case 2:adminServices.listAllCourses();break;
			case 3:user=new User();
				   System.out.println("Enter user Id :");
				   user.setId(scanner.nextInt());
				   System.out.println("Enter new Status...(active/inactive)");
				   String status=scanner.next();
				   boolean check=user.setStatus(status);
				   if(check){
				   updatestatus=adminServices.updateUserDetailStatus(user);
				   }else{System.out.println("Invalid Status");}
				   if(updatestatus){System.out.println("User Record Updated Successfully");}
				   else {System.out.println("updation Unsuccessfull");}
				   break;
			case 4:user=new User();
			       System.out.println("Enter user Id :");
			       user.setId(scanner.nextInt());
			       System.out.println("Enter new Role...(Trainer/Trainee/Admin)");
			       String role=scanner.next();
			       System.out.println("Enter Trainer id");
			       int id=scanner.nextInt();
			       if(user.setRole(role)){
				   updatestatus=adminServices.updateUserDetailRole(user,id);
				   }else{System.out.println("Invalid Role");}
			       if(updatestatus){System.out.println("User Record Updated Successfully");}
				   else {System.out.println("updation Unsuccessfull");}
			       break;
			case 0:System.out.println(adminName+" Logout Successfull");return;
			default:System.out.println("Invalid Choice...");
			}
		}while(true);
		
	}
	/**
	 * Trainer Menu and its Services
	 */
    private void trainerMenu(String TrainerName) {
    
    do{ 
    	System.out.println("*******Trainer Menu********");
		System.out.println("1. List all Trainees");
		System.out.println("2. List all Courses Added");
		System.out.println("3. Update Course details");
		System.out.println("4. Add Course");
		System.out.println("5. Delete Course");
		System.out.println("0. Logout");
		System.out.println("Enter Your Choice....");
		choice=scanner.nextInt();
		switch (choice) {
		case 1:trainerService.listAllTrainees();
		       break;
		case 2:trainerService.listAllCourses(TrainerName);
		       break;
		case 3:getUpdateCourseDetails();
			   break;
		case 4:getNewCourseDetails(TrainerName);
		       break;
		case 5:getCourseDetailToDelete();
		       break;
		case 0:System.out.println(TrainerName+" Logout Successfull");return;
		default:System.out.println("Invalid Choice...");
		}
    }while(true);	
	}
    /**
     * this will get Course details to delete
     */
	private void getCourseDetailToDelete() {
		boolean status;
		course=new Courses();
		       System.out.println("Enter Cid of Course You want to Delete ");
		       course.setCid(scanner.nextInt());
		       status=trainerService.deleteCourse(course);
		       if(status){System.out.println("Course Deletion Successfully");
		       } else{System.out.println("Deletion Unsuccessfull");}
	}
	/**
	 * this will get new course details
	 * @param TrainerName
	 */
	private void getNewCourseDetails(String TrainerName) {
		boolean status;
		course=new Courses();
			   System.out.println("Enter New Course Name ");
			   scanner.nextLine();
			   course.setCname(scanner.nextLine());
			   course.setAddedBy(TrainerName);
			   status=trainerService.addNewCourse(course);
		       if(status){System.out.println(course.getCname()+" Added");}
		       else{System.out.println("Course Not Added");}
	}
	/**
	 * this will get course details to update
	 */
	private void getUpdateCourseDetails() {
		course=new Courses();
			   System.out.println("Enter Course Id :");
			   course.setCid(scanner.nextInt());
			   System.out.println("Enter new Name :");
			   String cname=scanner.next();
			   boolean check=course.setCname(cname);
			   if(check){
			   updatestatus=trainerService.updateCourseDetails(course);
			   }else{System.out.println("Invalid Name");}
			   if(updatestatus){System.out.println("Course Record Updated Successfully");}
			   else {System.out.println("updation Unsuccessfull");}
	}

}
