package com.yash.onlinetrainingsystem.main;
/**
 * this will start the application
 */
import com.yash.onlinetrainingsystem.util.Menu;

public class StartUpApp {
	public static void main(String[] args) {
		new Menu().startMenu();
	}

}
