package com.yash.onlinetrainingsystem.model;
/**
 * this will keep the user details
 */

public class User {
	/**
	 * user id
	 */
	private int id;
	/**
	 * user first name
	 */
	private String firstname;
	/**
	 * user last name
	 */
	private String lastname;
	/**
	 * user email id
	 */	
	private String email;
	/**
	 * user's contact number 
	 */	
	private long contact;
	/**
	 * user's username 
	 */	
	private String username;
	/**
	 * user role
	 */
	private String role="TRAINEE";
	/**
	 * user status
	 */
	private String status="INACTIVE";
	/**
	 * user's password 
	 */	
	private String password;
	/**
	 * user created date
	 */	
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getFirstname() {
	return firstname;
}
public void setFirstname(String firstname) {
	this.firstname = firstname;
}
public String getLastname() {
	return lastname;
}
public void setLastname(String lastname) {
	this.lastname = lastname;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public long getContact() {
	return contact;
}
public void setContact(long contact) {
	this.contact = contact;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getRole() {
	return role;
}
public boolean setRole(String role) {
	if(role.equalsIgnoreCase("trainee")||role.equalsIgnoreCase("trainer")||role.equalsIgnoreCase("admin")){
	this.role = role.toUpperCase();
	return true;
	}
	else{return false;}
}
public String getStatus() {
	return status;
}
public boolean setStatus(String status) {
	if(status.equalsIgnoreCase("active")||status.equalsIgnoreCase("inactive")){
	this.status = status.toUpperCase();
	return true;
	}else
	{return false;}
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
}
