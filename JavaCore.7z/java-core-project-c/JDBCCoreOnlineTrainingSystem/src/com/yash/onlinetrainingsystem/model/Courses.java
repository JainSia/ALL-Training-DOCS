package com.yash.onlinetrainingsystem.model;
/**
 * this will keep the details of a particular course
 * @author chetan.magre
 *
 */
public class Courses {
    /**
     * course id
     */
	private int cid;
	/**
	 * course name
	 */
	private String cname;
	/**
	 * Trainer Name by whom course is added 
	 */
	private String addedBy;
	
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public boolean setCname(String cname) {
		this.cname = cname;
		return true;
	}
	public String getAddedBy() {
		return addedBy;
	}
	public void setAddedBy(String addedBy) {
		this.addedBy = addedBy;
	}
	
}
