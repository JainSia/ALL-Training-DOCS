package com.yash.onlinetrainingsystem.daoserviceimpl;
/**
 *  dao implementation of Registration related query
 */
import java.sql.Connection;
import java.sql.PreparedStatement;

import com.yash.onlinetrainingsystem.dao.RegistrationDao;
import com.yash.onlinetrainingsystem.model.User;
import com.yash.onlinetrainingsystem.util.DBconnection;

public class RegistrationDaoImpl implements RegistrationDao{
	DBconnection dbc = new DBconnection();
	private Connection con;
	/**
	 * this will register all new user and insert all the details to users table
	 */
	@Override
	public boolean registerUser(User user) {
		
		try
		{boolean status=false;
		con=dbc.DataBaseConnectivity();
		String sql="INSERT INTO users(firstname, lastname, email, contact, username, password, creationdate) values(?,?,?,?,?,?,NOW())";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, user.getFirstname());
		pstmt.setString(2, user.getLastname());
		pstmt.setString(3, user.getEmail());
		pstmt.setLong(4, user.getContact());
		pstmt.setString(5, user.getUsername());
		pstmt.setString(6, user.getPassword());
		int state=pstmt.executeUpdate();
		if(state>=1)status=true;
		pstmt.close();
		con.close();
		return status;
	    } catch (Exception e) {
		e.printStackTrace();
	    }	
		return false;
	}

}
