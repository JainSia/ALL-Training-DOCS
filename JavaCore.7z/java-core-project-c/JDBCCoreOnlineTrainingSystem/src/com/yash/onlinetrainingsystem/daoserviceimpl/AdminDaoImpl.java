package com.yash.onlinetrainingsystem.daoserviceimpl;
/**
 * dao Implementation for admin services
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;


import com.yash.onlinetrainingsystem.dao.AdminDao;
import com.yash.onlinetrainingsystem.model.User;
import com.yash.onlinetrainingsystem.util.DBconnection;

public class AdminDaoImpl implements AdminDao {
	DBconnection dbc = new DBconnection();
	private Connection con;
	 /**
	  * this will get all the records from table type
	  */
	  @Override
		public void getAllRecords(String type){
			try
			{
			con=dbc.DataBaseConnectivity();
			String sql="SELECT * FROM "+type;
			PreparedStatement pstmt=con.prepareStatement(sql);
			ResultSet rs=pstmt.executeQuery(sql);
			ResultSetMetaData rsmd=rs.getMetaData();
			int count=rsmd.getColumnCount();
			for(int i=1;i<=count;i++){
			     System.out.print(rsmd.getColumnName(i)+"      ");		
				}
			System.out.println();
			while(rs.next()){
				for(int i=1;i<=count;i++){
			     System.out.print(rs.getString(i)+"       ");		
				}
				System.out.println();
			}
			pstmt.close();
			con.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}	
		}
	  /**
	   * this will update Status of user in users table 
	   */
	  @Override
		public boolean updateStatusOfRecord(User user) {
			try
			{boolean status=false;
			con=dbc.DataBaseConnectivity();
			String sql="UPDATE users SET status ='"+user.getStatus()+"', modifieddate=NOW() WHERE id="+user.getId();
			PreparedStatement pstmt=con.prepareStatement(sql);
			int state=pstmt.executeUpdate();
			if(state>=1)status=true;
			pstmt.close();
			con.close();
			return status;
		    } catch (Exception e) {
			e.printStackTrace();
		    }	
			return false;
		}
	  /**
	   * this will update Role (Trainer)of user in users table
	   */
	@Override
	public boolean updateRoleOfRecord(User user,int trainerId) {
		if(user.getRole().equalsIgnoreCase("trainee")){
		return updateTraineeRole(user, trainerId);}
		else{
			try{ 
				boolean status=false;
				 String sql=null;
				 PreparedStatement pstmt;
				 int managerid=0;
				con=dbc.DataBaseConnectivity();
				sql="SELECT * FROM users WHERE username='chetan'";
				pstmt=con.prepareStatement(sql);
				ResultSet rs=pstmt.executeQuery(sql);
				while(rs.next()){
				 managerid=rs.getInt(1);
				}		
				sql="UPDATE users SET role ='"+user.getRole()+"', modifieddate=NOW(), managerid="+managerid+" WHERE id="+user.getId();
				pstmt=con.prepareStatement(sql);
				int state=pstmt.executeUpdate();
				if(state>=1)status=true;
				pstmt.close();
				con.close();
				return status;
			    } catch (Exception e) {
				e.printStackTrace();
			    }	
				return false;
	}	  
  }
	/**
	 * this will update Role(Trainee) of user in users table
	 * @param user
	 * @param trainerId
	 * @return
	 */
	private boolean updateTraineeRole(User user,int trainerId) {
		try{ 
		boolean status=false;
		 String sql=null;
		 PreparedStatement pstmt;
		 int managerid=0;
		con=dbc.DataBaseConnectivity();
		sql="SELECT * FROM users WHERE id="+trainerId;
		pstmt=con.prepareStatement(sql);
		ResultSet rs=pstmt.executeQuery(sql);
		if(rs.next()){
		 managerid=rs.getInt(1);		
		sql="UPDATE users SET role ='"+user.getRole()+"', modifieddate=NOW(), managerid="+managerid+" WHERE id="+user.getId();
		pstmt=con.prepareStatement(sql);
		int state=pstmt.executeUpdate();
		if(state>=1)status=true;
		pstmt.close();
		con.close();
		return status;
		}else{return status;}
	    } catch (Exception e) {
		e.printStackTrace();
	    }	
		return false;
	}
}