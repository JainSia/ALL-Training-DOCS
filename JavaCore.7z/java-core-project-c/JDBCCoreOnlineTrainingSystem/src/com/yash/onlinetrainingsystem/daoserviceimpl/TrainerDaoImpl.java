package com.yash.onlinetrainingsystem.daoserviceimpl;
/**
 * dao implementation of Trainer related query
 */

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

import com.yash.onlinetrainingsystem.dao.TrainerDao;
import com.yash.onlinetrainingsystem.model.Courses;
import com.yash.onlinetrainingsystem.util.DBconnection;

public class TrainerDaoImpl implements TrainerDao {
	DBconnection dbc = new DBconnection();
	private Connection con;
	/**
	 * this will show all Courses added by that Trainer
	 */
	@Override
	public void getRecordsBasedOnName(String trainerName,String type) {
		try
		{
		con=dbc.DataBaseConnectivity();
		String sql="SELECT * FROM "+type+" WHERE addedby='"+trainerName.toLowerCase()+"'";
		PreparedStatement pstmt=con.prepareStatement(sql);
		ResultSet rs=pstmt.executeQuery(sql);
		ResultSetMetaData rsmd=rs.getMetaData();
		int count=rsmd.getColumnCount();
		for(int i=1;i<=count;i++){
		     System.out.print(rsmd.getColumnName(i)+"      ");		
			}
		System.out.println();
		while(rs.next()){
			for(int i=1;i<=count;i++){
		     System.out.print(rs.getString(i)+"   ");		
			}
			System.out.println();
		}
		pstmt.close();
		con.close();
	} catch (Exception e) {
		e.printStackTrace();
	}		
	}
	/**
	 * this will show all trainees
	 */
	@Override
	public void getRecordsBasedOnRole(String role, String type) {
		try
		{
		con=dbc.DataBaseConnectivity();
		String sql="SELECT * FROM "+type+" WHERE role='"+role+"'";
		PreparedStatement pstmt=con.prepareStatement(sql);
		ResultSet rs=pstmt.executeQuery(sql);
		ResultSetMetaData rsmd=rs.getMetaData();
		int count=rsmd.getColumnCount();
		for(int i=1;i<=count;i++){
		     System.out.print(rsmd.getColumnName(i)+"      ");		
			}
		System.out.println();
		while(rs.next()){
			for(int i=1;i<=count;i++){
		     System.out.print(rs.getString(i)+"   ");		
			}
			System.out.println();
		}
		pstmt.close();
		con.close();
	} catch (Exception e) {
		e.printStackTrace();
	}			
	}
	/**
	 * this will allow trainer to update name of course 
	 */
	@Override
	public boolean updateRecordOfCourseTable(Courses course) {
		try
		{boolean status=false;
		con=dbc.DataBaseConnectivity();
		String sql="UPDATE courses SET name ='"+course.getCname()+"' WHERE cid="+course.getCid();
		PreparedStatement pstmt=con.prepareStatement(sql);
		int state=pstmt.executeUpdate();
		if(state>=1)status=true;
		pstmt.close();
		con.close();
		return status;
	    } catch (Exception e) {
		e.printStackTrace();
	    }	
		return false;
	}
	/**
	 * this will allow Trainer to add New Course to course table
	 */
	@Override
	public boolean addNewRecordInCourseTable(String type, Courses course) {
		try
		{boolean status=false;
		con=dbc.DataBaseConnectivity();
		String sql="INSERT INTO "+type+"(name, addedby) values('"+course.getCname()+"','"+course.getAddedBy()+"')";
		PreparedStatement pstmt=con.prepareStatement(sql);
		int state=pstmt.executeUpdate();
		if(state>=1)status=true;
		pstmt.close();
		con.close();
		return status;
	    } catch (Exception e) {
		e.printStackTrace();
	    }	
		return false;
	}
	/**
	 * this will allow Trainer to Delete a course from course table
	 */
	@Override
	public boolean deleteRecordByIdInCourseTable(String type, Courses course) {
		try
		{boolean status=false;
		con=dbc.DataBaseConnectivity();
		String sql="DELETE FROM "+type+" WHERE cid="+course.getCid();
		PreparedStatement pstmt=con.prepareStatement(sql);
		int state=pstmt.executeUpdate();
		if(state>=1)status=true;
		pstmt.close();
		con.close();
		return status;
	    } catch (Exception e) {
		e.printStackTrace();
	    }	
		return false;
	}

}
