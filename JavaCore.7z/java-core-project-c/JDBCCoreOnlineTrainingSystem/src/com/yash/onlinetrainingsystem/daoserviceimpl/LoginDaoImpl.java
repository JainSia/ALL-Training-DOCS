package com.yash.onlinetrainingsystem.daoserviceimpl;
/**
 *  dao implementation of Login related query
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.yash.onlinetrainingsystem.dao.LoginDao;
import com.yash.onlinetrainingsystem.util.DBconnection;


public class LoginDaoImpl implements LoginDao {
	DBconnection dbc = new DBconnection();
	private Connection con;
	/**
	 * this will check the user credentials and authenticate from users table
	 */
	@Override
	public String[] checkLogin(String username, String password) {
		String[] nameAndRole=new String[2];
		try {
			con=dbc.DataBaseConnectivity();
			String sql="SELECT username, password, role, concat(firstname,' ',lastname) FROM users";
			PreparedStatement pstmt=con.prepareStatement(sql);
			ResultSet rs=pstmt.executeQuery(sql);
			while(rs.next()){
				if(rs.getString(1).equals(username)&&rs.getString(2).equals(password))
				{   nameAndRole[0]=rs.getString(4).toUpperCase();
					nameAndRole[1]=rs.getString(3);
					pstmt.close();
					con.close();
					return nameAndRole;
				}
			}
			pstmt.close();
			con.close();
			return nameAndRole;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return nameAndRole;
	}
  
    
	
	
}
