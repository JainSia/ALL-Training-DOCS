package com.yash.onlinetrainingsystem.daoserviceimpl;
/**
 * dao implementation of Trainee related query
 */

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

import com.yash.onlinetrainingsystem.dao.TraineeDao;
import com.yash.onlinetrainingsystem.util.DBconnection;

public class TraineeDaoImpl implements TraineeDao{
	DBconnection dbc = new DBconnection();
	private Connection con;
	/**
	 * this will list all the courses available to Trainee 
	 */
	@Override
	public void listAllCourses(String traineeName) {
		try
		{
		con=dbc.DataBaseConnectivity();
		String sql="SELECT * FROM courses";
		PreparedStatement pstmt=con.prepareStatement(sql);
		ResultSet rs=pstmt.executeQuery(sql);
		ResultSetMetaData rsmd=rs.getMetaData();
		int count=rsmd.getColumnCount();
		for(int i=1;i<=count;i++){
		     System.out.print(rsmd.getColumnName(i)+"      ");		
			}
		System.out.println();
		while(rs.next()){
			for(int i=1;i<=count;i++){
		     System.out.print(rs.getString(i)+"      ");		
			}
			System.out.println();
		}
		pstmt.close();
		con.close();
	} catch (Exception e) {
		e.printStackTrace();
	}	
	}
	/**
	 * this will check the status of trainee (Active or Inactive)
	 */
	@Override
	public boolean checkStatus(String traineeName) {
		String []name=traineeName.split(" ");
		try
		{boolean status=false;
		con=dbc.DataBaseConnectivity();
		String sql="SELECT status FROM users WHERE firstname='"+name[0]+"'";
		PreparedStatement pstmt=con.prepareStatement(sql);
		ResultSet rs=pstmt.executeQuery(sql);
		while(rs.next()){
			if(rs.getString(1).equalsIgnoreCase("active")){status=true;}
			}
		pstmt.close();
		con.close();
		return status;
	    } catch (Exception e) {
		e.printStackTrace();
	    }	
		return false;
	}

}
