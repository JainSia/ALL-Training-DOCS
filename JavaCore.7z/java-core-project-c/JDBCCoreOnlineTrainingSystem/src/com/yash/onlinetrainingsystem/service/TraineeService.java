package com.yash.onlinetrainingsystem.service;

public interface TraineeService {
    /**
     * this will check that the trainee is active or not
     * @param TraineeName
     * @return
     */
	public boolean checkStatus(String TraineeName);
    /**
     * this will list all the courses available
     * @param TraineeName
     */
	public void listAllCourese(String TraineeName);

}
