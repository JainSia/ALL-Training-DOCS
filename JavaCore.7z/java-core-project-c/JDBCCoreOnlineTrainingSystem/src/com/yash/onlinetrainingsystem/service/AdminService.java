package com.yash.onlinetrainingsystem.service;

import com.yash.onlinetrainingsystem.model.User;

public interface AdminService {
	/**
	 * this will list all users to admin
	 */
	public void listAllUser();
	/**
	 * this will list all courses to admin
	 */
	public void listAllCourses();
	/**
	 * this will update user status
	 * @param user
	 * @param trainerId
	 * @return
	 */
	public boolean updateUserDetailRole(User user, int trainerId);
	/**
	 * this will update user role
	 * @param user
	 * @return
	 */
	public boolean updateUserDetailStatus(User user);

}
