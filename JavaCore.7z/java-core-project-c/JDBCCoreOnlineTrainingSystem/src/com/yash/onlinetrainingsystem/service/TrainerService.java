package com.yash.onlinetrainingsystem.service;

import com.yash.onlinetrainingsystem.model.Courses;

public interface TrainerService {
	/**
	 * this will list all trainees
	 */
	public void listAllTrainees();
	/**
	 * this will list all courses added by logged in trainer
	 * @param trainerName
	 */
	public void listAllCourses(String trainerName);
	/**
	 * this will update course details
	 * @param course
	 * @return
	 */
	public boolean updateCourseDetails(Courses course);
	/**
	 * this will add new course
	 * @param course
	 * @return
	 */
	public boolean addNewCourse(Courses course);
	/**
	 * this will delete a existing course
	 * @param course
	 * @return
	 */
	public boolean deleteCourse(Courses course);

}
