package com.yash.onlinetrainingsystem.dao;

import com.yash.onlinetrainingsystem.model.Courses;

public interface TrainerDao {
	/**
	 * this will show all Courses added by that Trainer
	 * @param name
	 * @param Type
	 */
	public void getRecordsBasedOnName(String name,String Type);
	/**
	 *  this will show all trainees
	 * @param role
	 * @param Type
	 */
	public void getRecordsBasedOnRole(String role,String Type);
	/**
	 * this will allow trainer to update name of course 
	 * @param course
	 * @return
	 */
	public boolean updateRecordOfCourseTable(Courses course);
	/**
	 * this will allow Trainer to add New Course to course table
	 * @param type
	 * @param course
	 * @return
	 */
	public boolean addNewRecordInCourseTable(String type, Courses course);
	/**
	 * this will allow Trainer to Delete a course from course table
	 * @param type
	 * @param course
	 * @return
	 */
	public boolean deleteRecordByIdInCourseTable(String type, Courses course);
}
