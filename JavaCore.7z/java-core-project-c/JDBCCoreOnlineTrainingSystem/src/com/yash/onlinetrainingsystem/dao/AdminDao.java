package com.yash.onlinetrainingsystem.dao;
/**
 * it performs CURD operations on Admin 
 */
import com.yash.onlinetrainingsystem.model.User;

public interface AdminDao {
	/**
	  * this will get all the records from table type
	  */
	public void getAllRecords(String type);
	/**
	 * this will update Status of user in users table 
	 * @param user
	 * @return
	 */
	public boolean updateStatusOfRecord(User user);
	/**
	 * this will update Role (Trainer)of user in users table
	 * @param user
	 * @param trainerId
	 * @return
	 */
	public boolean updateRoleOfRecord(User user,int trainerId);
}
