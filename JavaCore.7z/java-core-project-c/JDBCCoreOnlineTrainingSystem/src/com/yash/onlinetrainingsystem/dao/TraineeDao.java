package com.yash.onlinetrainingsystem.dao;

public interface TraineeDao {
    /**
     * this will check the status of trainee (Active or Inactive)
     * @param TraineeName
     * @return
     */
	public boolean checkStatus(String TraineeName);
    /**
     * this will list all the courses available to Trainee 
     * @param TraineeName
     */
	public void listAllCourses(String TraineeName);

}
