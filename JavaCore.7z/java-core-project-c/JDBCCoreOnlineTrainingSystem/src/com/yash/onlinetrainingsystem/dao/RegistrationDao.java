package com.yash.onlinetrainingsystem.dao;

import com.yash.onlinetrainingsystem.model.User;

public interface RegistrationDao {
    /**
     * this will register all new user and insert all the details to users table
     * @param user
     * @return
     */
	boolean registerUser(User user);

}
