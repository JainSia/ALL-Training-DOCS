package com.yash.onlinetrainingsystem.dao;

public interface LoginDao {
	/**
	 * this will check the user credentials and authenticate from users table
	 * @param username
	 * @param password
	 * @return
	 */
	public String[] checkLogin(String username, String password);
}
