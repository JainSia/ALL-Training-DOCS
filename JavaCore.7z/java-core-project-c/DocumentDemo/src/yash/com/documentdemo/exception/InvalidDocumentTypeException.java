package yash.com.documentdemo.exception;

public class InvalidDocumentTypeException extends Exception {
   public InvalidDocumentTypeException(String ErrMsg) {
	super(ErrMsg);
}
}
