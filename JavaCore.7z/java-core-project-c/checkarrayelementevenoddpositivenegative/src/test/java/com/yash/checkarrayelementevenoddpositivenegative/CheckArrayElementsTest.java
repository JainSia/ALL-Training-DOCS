package com.yash.checkarrayelementevenoddpositivenegative;

import static org.junit.Assert.*;

import org.junit.Test;

public class CheckArrayElementsTest {
    
	private CheckArrayElements checkelement= new CheckArrayElements();
    @Test
	public void test_even_number_in_array() {
		int check[]=checkelement.checkEvenAndOdd();
		int arr[]={7,8};
		assertArrayEquals(arr, check);
	}
    @Test
	public void test_positve_and_negative_number_in_array() {
		int check[]=checkelement.checkPositivieAndNegative();
		int arr[]={12,3};
		assertArrayEquals(arr, check);
	}

}
