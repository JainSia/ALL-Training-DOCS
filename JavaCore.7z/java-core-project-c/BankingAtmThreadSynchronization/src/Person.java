
public class Person implements Runnable {
	private String name;
	private int amount;
	
	Bank bank;
	public Person(String name, int amount,Bank bank) {
		this.name = name;
		this.amount = amount;
		this.bank=bank;
	//	new Thread(this).start();
	}
	@Override
	public void run() {
		bank.withdraw(name, amount);
		
	}
}
