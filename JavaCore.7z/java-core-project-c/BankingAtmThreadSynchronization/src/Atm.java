
public class Atm {

	public static void main(String[] args) {
     Bank bank=new Bank();
     Person p1=new Person("Chetan", 100, bank);
     Person p2=new Person("Ishan", 100, bank);
     Person p3=new Person("harmeet", 100, bank);
     Thread t=new Thread(p1);
     t.start();
     try {
		t.join();
	} catch (InterruptedException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
     Thread t1=new Thread(p2);
     t1.start();
     try {
 		t1.join();
 	} catch (InterruptedException e1) {
 		// TODO Auto-generated catch block
 		e1.printStackTrace();
 	}
   
     Thread t2=new Thread(p3);
     t2.start();
	}

}
