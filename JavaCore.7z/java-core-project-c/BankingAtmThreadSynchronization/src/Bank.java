public class Bank{
	private double balance=200;
	
	public void withdraw(String name2, int amount2) {
		if(amount2<=balance){
		System.out.println("Account Name : "+name2);
		System.out.println("Initial Balance :"+balance);
		balance-=amount2;
		System.out.println("Amount withdraw :"+amount2);
		System.out.println("Available Balance :"+balance);
		}
		else
		{   System.out.println("Account Name : "+name2);
			System.out.println("Available Balance :"+balance);
			System.out.println("Insufficent fund");
	    }
	}

}
