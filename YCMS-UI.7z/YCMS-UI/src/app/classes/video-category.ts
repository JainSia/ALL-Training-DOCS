export class VideoCategory {
    private id: number;

    private name: String;
}
