/**
 * 
 * @author saloni.jain
 * 
 * this is article class
 */
export class Article {
    id:number;
    fileName:string;
    publishStatus:string;
    featureStatus:string;
    access:string;
    author:string;
    tag:string;
    language:string;
    datecreated:Date;
    

  }