import { Injectable } from '@angular/core';
import { Http,Response,Headers,RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { HostURL } from '../../hostUrl/hostUrl';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable()
export class RegistrationService {
  constructor(private http:Http,private hosturl:HostURL) { }
  
    checkIsDomainNameExist(dbname:string){
      let url='http://'+this.hosturl.hostName+'/ycmsweb/customers/getdb/'+dbname;
      return this.http.get(url,{ withCredentials: true });
    }
  
    registerCustomer(email:string,password:string,domainName:string){
      var user={"email":email, "domainName":domainName, "password":password}
    let url = 'http://'+this.hosturl.hostName+'/ycmsweb/customers/register';
    let params = user;
    let headers = new Headers(
    { 'Content-Type': 'application/json' });
    return this.http.post(url, params, {headers: headers, withCredentials : true}).catch((e:any)=>Observable.throw(e));
    }

}
