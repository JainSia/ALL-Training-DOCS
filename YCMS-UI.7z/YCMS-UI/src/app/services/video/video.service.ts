import { Injectable } from '@angular/core';
import { HttpClient, HttpRequest, HttpEvent } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/throw';
import { Video } from '../../classes/video';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { HostURL } from '../../hostUrl/hostUrl';

/**
 * This is a service class for Video.
 * 
 * Author : harmeet.saluja
 */
@Injectable()
export class VideoService {

  /**
   * constructor of the class.
   * 
   * @param http object of HttpClient that is used to execute http requests
   */
  constructor(private http: HttpClient,private hosturl:HostURL) { }

  /**
   * This method is used to send the data to the backend controller
   * 
   * @param file video file that is to be uploaded
   * @param title title of the video
   * @returns HttpEvent
   */
  uploadVideo(file: File, title: string): Observable<Object> {
    let url = 'http://'+this.hosturl.hostName+'/ycmsweb/videos/savevideo';
    let formdata: FormData = new FormData();
    formdata.append('file', file);
    formdata.append('title', title);
    return this.http.post(url, formdata, { observe: 'response' });

  }

  /**
   * This method is used to get the details of all the videos that are present in the database.
   * 
   * @returns the list containing the details of the Video
   */
  getAllVideos(): Observable<Video[]> {
    let url = "http://"+this.hosturl.hostName+"/ycmsweb/videos/videosList";
    return this.http.get(url)
      .map((res: Response) => res)
      .catch((error: any) => Observable.throw(error));
  }

}
