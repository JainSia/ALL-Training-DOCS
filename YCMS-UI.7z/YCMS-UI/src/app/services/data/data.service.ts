import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable()
export class DataService {

  constructor() { }
  
  /**
   * @author saloni.jain
   * 
   * this variable will store the name of article.
   */
  private articleName =new BehaviorSubject<string>("");
  currentArticleName=this.articleName.asObservable();


  private messageSource=new BehaviorSubject<boolean>(false);
  currentLoginValue=this.messageSource.asObservable();
   
  changeLoginValue(loginValue:boolean){
     this.messageSource.next(loginValue);
   }

   /**
    * @author saloni.jain

    * this method will change the article's name value
    */
   changeArticleName(articleNameValue:string){
     this.articleName.next(articleNameValue);
   }
}
