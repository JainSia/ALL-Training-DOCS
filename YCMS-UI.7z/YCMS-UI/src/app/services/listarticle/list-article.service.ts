import { Injectable } from '@angular/core';
import { HttpHeaders,HttpClient } from '@angular/common/http';
import { HostURL } from '../../hostUrl/hostUrl';
/** 
 * 
 * @author saloni.jain
 * 
 * this service will return the functionality related to listing of article.
 */
@Injectable()
export class ListArticleService {

  /**
   *
   * @param http is injected
   */
  constructor(private httpclient:HttpClient,private hosturl:HostURL) {
   
   }

  

  /**
   * this function will return the list on the basis of attributes provided to it.
   * 
   * 
   * @param title is the name of file
   * @param selectedStatus is the status of file i.e it is published or unpublished
   * @param selectedAccess is the status of file i.e it is public or private
   */
  getListOfArticles(selectedStatus:string,selectedAccess:string,language:string,featureStatus:string,fileName:string,author:string,tag:string,id:number){
    let url = 'http://'+this.hosturl.hostName+'/ycmsweb/searchArticles';
    var data={"publishStatus":selectedStatus,"access":selectedAccess,"language":language,"featureStatus":featureStatus,"fileName":fileName,"author":author,"tag":tag,"id":id};
    let headers = new HttpHeaders({'Content-Type': 'application/json'});
    return this.httpclient.post(url, data, {headers: headers, withCredentials : true});
    }
    /**
     * 
     * 
     * this will return the list of all articles according to task
     */
  getAllArticles(task:string){
    console.log(task);
    var url;
    if(task=="trash"){
      url = 'http://'+this.hosturl.hostName+'/ycmsweb/getTrashedArticles';
    }if(task=="untrash"){
      console.log(task);
      url = 'http://'+this.hosturl.hostName+'/ycmsweb/getUntrashedArticles';      
    }
      let headers = new Headers({'Content-Type': 'application/json'});
      return this.httpclient.get(url);
    }
    /**
     * 
     * @author saloni.jain
     * 
     * this will change the status of articles from unpublish to publish or viceversa
     */
    changeStatusToPublishOrUnpublish(id:number,task:string){
      var url;
      if(task=="published"){
        console.log(task);
         url = 'http://'+this.hosturl.hostName+'/ycmsweb/changeStatusToPublish';        
      }
      if(task=="unpublished") {
        console.log(task);
         url = 'http://'+this.hosturl.hostName+'/ycmsweb/changeStatusToUnpublish';
      }
      var data={ "id":id};
      let headers = new HttpHeaders({'Content-Type': 'application/json'});
      return this.httpclient.post(url, data,{headers: headers, withCredentials : true});
    }
    
    /**
     * 
     * this will move the article to trash
     */
    changeStatusToTrash(id:number){
      let url = 'http://'+this.hosturl.hostName+'/ycmsweb/changeStatusToTrash';
      let data={ "id":id};
      let headers = new HttpHeaders({'Content-Type': 'application/json'});
      return this.httpclient.post(url, data, {headers: headers, withCredentials : true});
    }

    /**
     * 
     * this will delete the article permanently
     */
    deleteArticle(id:number){
      let url = 'http://'+this.hosturl.hostName+'/ycmsweb/deleteArticle';
      let data={ "id":id};
      let headers = new HttpHeaders({'Content-Type': 'application/json'});
      return this.httpclient.post(url, data, {headers: headers, withCredentials : true});
    }

    getFeaturedArticles(){
      let url = 'http://'+this.hosturl.hostName+'/ycmsweb/getFeatureArticles';
      let headers = new HttpHeaders({'Content-Type': 'application/json'});
      return this.httpclient.get(url);
    }
    
    /**
     * this will change the status of article from unfeature to feature.
     * 
     * @param id is the primary key of article on the basis of which we will change the 
     *        status of article from unfeature to feature.
     */
    changeStatusToFeatureOrUnfeatureArticle(id:number,task:string){
      var url;
      if(task=="featured") {
       url='http://'+this.hosturl.hostName+'/ycmsweb/changeStatusToFeature';
      }
      if(task=="unfeatured"){
        url='http://'+this.hosturl.hostName+'/ycmsweb/changeStatusToUnfeature';
      }
      let data={ "id":id};
      let headers = new HttpHeaders({'Content-Type': 'application/json'});
      return this.httpclient.post(url, data, {headers: headers, withCredentials : true});
    }

   
    
	editArticle(fileName:String){
		let url='http://'+this.hosturl.hostName+'/ycmsweb/editArticle';
		let data = {"fileName":fileName};
		return this.httpclient.post(url , data);
	}
	
	openPage(title:string){
		let url='http://'+this.hosturl.hostName+'/ycmsweb/openpage/'+title;
		return this.httpclient.get(url);
	}
	
}
