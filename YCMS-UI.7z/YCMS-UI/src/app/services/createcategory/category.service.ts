import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { Category } from '../../classes/Category';
import { HostURL } from '../../hostUrl/hostUrl'

/**
 * CategoryService class is responsible for making http calls to
 * fetch json data or response from rest controller
 * Author : minerva.shrivastava
 */
@Injectable()
export class CategoryService {

  /**
   * the common backend URL used by all the methods
   */
  URL = 'http://'+this.hosturl.hostName+'/ycmsweb/';

  /**
   * Initializing HTTPClient to make http requests
   * @param http
   */

constructor(private httpClient:HttpClient,private hosturl:HostURL) { }

  /**
   * this method makes the post request to store the category
   * at the specified URL and header
   */
  addCategory(category : Category){
	console.log(category);
   let URL=this.URL+'category';
	let headers = new HttpHeaders(
	  {
		'Content-Type':'application/json'
	  });
   return this.httpClient.post(URL,category,{observe:'response'});
  }
}
