import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Http} from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import {Observable} from 'rxjs/Observable';
import { HostURL } from '../../hostUrl/hostUrl';

@Injectable()
export class WhatsNewService {
/**
 * This is the url from which the list of updates will be displayed in JSON format
 */
  private apiUrl='http://'+this.hosturl.hostName+'/ycmsweb/updates';

  /**
   * The constructor of the class
   * 
   * @param http, httpCilent http objects to execute http requests 
   */
  constructor(private http:Http,private httpclient:HttpClient,private hosturl:HostURL) { }

  /**
   * This method is used to get the list of updates in JSON format 
   */
   whatsNewUpdate(){
    
     //return this.http.get(this.apiUrl);

     return this.httpclient.get(this.apiUrl);

   }

}