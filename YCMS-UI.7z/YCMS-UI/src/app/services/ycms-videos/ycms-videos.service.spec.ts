import { TestBed, inject } from '@angular/core/testing';

import { YcmsVideosService } from './ycms-videos.service';

describe('YcmsVideosService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [YcmsVideosService]
    });
  });

  it('should be created', inject([YcmsVideosService], (service: YcmsVideosService) => {
    expect(service).toBeTruthy();
  }));
});
