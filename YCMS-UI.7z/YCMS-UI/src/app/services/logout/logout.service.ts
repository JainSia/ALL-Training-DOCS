import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HostURL } from '../../hostUrl/hostUrl';

@Injectable()
export class LogoutService {

  constructor(private httpClient:HttpClient,private hosturl:HostURL) { }

  customerLogout(){
    let url='http://'+this.hosturl.hostName+'/ycmsweb/customers/logout';
    return this.httpClient.get(url);
  }
}
