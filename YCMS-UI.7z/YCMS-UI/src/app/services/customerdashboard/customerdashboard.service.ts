import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http'
import { Customer } from '../../classes/customer';
import { HostURL } from '../../hostUrl/hostUrl'
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

/**
 * reponsible for customer related http requests.
 * 
 * Author : maithili.pande
 */

@Injectable()
export class CustomerdashboardService {
 /**
	 * this property stores header related attributes for http request.
	 */
	headers = new Headers(
		{
			'Content-Type': 'application/json'
		});


	/**
	 * the "constructor"
	   */
	constructor(private httpClient: HttpClient,private hosturl:HostURL) { }


	/**
	 * makes post request and fetches customer details.
	 */
	getCustomer(email:String) {
        let url = "http://"+this.hosturl.hostName+"/ycmsweb/customers/getcustomer";
        return this.httpClient.get(url,{observe:'response'});
	}

	/**
	 * makes post request to update customer details.
	 * @param customer customer to be updated
	 */
	updateCustomer(customer: Customer) {
		let url = "http://"+this.hosturl.hostName+"/ycmsweb/customers/update";
		let param={
			organization:customer.organization,
			id:customer.id,
			firstName:customer.firstName,
			lastName:customer.lastName,
			contact:customer.contact,
			address:customer.address,
			country:customer.country,
			state:customer.state,
			city:customer.city,
			zip:customer.zip
		}
		return this.httpClient.post(url, param, {observe:'response'});
	}

}
