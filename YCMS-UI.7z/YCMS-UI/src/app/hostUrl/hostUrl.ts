/**
 * 
 * @author chetan.magre
 * 
 * this is host URL class which Defines that at what host the allpication will send request.
 */
export class HostURL{
    hostName:String="localhost:8080";
}