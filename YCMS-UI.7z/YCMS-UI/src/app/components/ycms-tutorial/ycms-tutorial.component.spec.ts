import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { YcmsTutorialComponent } from './ycms-tutorial.component';

describe('YcmsTutorialComponent', () => {
  let component: YcmsTutorialComponent;
  let fixture: ComponentFixture<YcmsTutorialComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ YcmsTutorialComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(YcmsTutorialComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
