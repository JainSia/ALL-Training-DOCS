import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-ycms-tutorial',
  templateUrl: './ycms-tutorial.component.html',
  styleUrls: ['./ycms-tutorial.component.css']
})
export class YcmsTutorialComponent implements OnInit {

  constructor(private router:Router) {
		if(sessionStorage.getItem('Authorization')===null){
		  this.router.navigate(['/signin']);
	  }
	  }

  ngOnInit() {
  }

}
