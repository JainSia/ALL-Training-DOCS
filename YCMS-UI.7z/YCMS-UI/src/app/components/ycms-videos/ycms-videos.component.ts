import { Component, OnInit } from '@angular/core';
import { YcmsVideosService } from '../../services/ycms-videos/ycms-videos.service';

@Component({
  selector: 'app-ycms-videos',
  templateUrl: './ycms-videos.component.html',
  styleUrls: ['./ycms-videos.component.css']
})
export class YcmsVideosComponent implements OnInit {

  constructor(private ycmsVideosService: YcmsVideosService) { }

  ngOnInit() {
    this.ycmsVideosService.getAllVideos().subscribe();
  }

}
