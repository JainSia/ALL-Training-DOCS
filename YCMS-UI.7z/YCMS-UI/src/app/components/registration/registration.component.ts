import { Component, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { Observable } from 'rxjs/Observable'
import { RegistrationService } from '../../services/registration/registration.service';
import { Router } from '@angular/router';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http'
@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  emailFormControl = new FormControl('', [
    Validators.required,
    Validators.email,
  ]);
  hide = true;

  email: string;
  password: string;
  domainName: string;
  domainError = false;
  errMsg: string;
  succMsg: string;
  clicked: boolean = false;
  constructor(private router: Router, private registrationService: RegistrationService) { }

  registerCustomer() {
    this.clicked = true;
    this.registrationService.registerCustomer(this.email, this.password, this.domainName).subscribe(

      res => {
        this.clicked = false;
        if (res.text() === "Registration Successful") {
          this.succMsg = res.text();
          this.email = '';
          this.password = '';
          this.domainName = '';
        } else {
          this.errMsg = res.text();
        }
        console.log(res.text());

      }

      ,
      err => {
        this.clicked = false;
        console.log(err.text());
      }
    )
  }

  checkDomainName() {
    this.registrationService.checkIsDomainNameExist(this.domainName).subscribe(
      res => {
        console.log(res.text());
        if (res.text() == "domain Not Available") {
          this.domainError = true;
          document.getElementById("register-btn").setAttribute("disabled", "true");
        } else {
          this.domainError = false;
          document.getElementById("register-btn").removeAttribute("disabled");
        }
      }
    )
  }

  ngOnInit() {
  }
}