import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup} from '@angular/forms';
import { Router } from '@angular/router';
import {AdminportalService } from '../../services/adminportal/adminportal.service';
import {Customer} from '../../classes/customer';
import { HomeService } from '../../services/home/home.service';
import { HttpResponse } from '@angular/common/http';

@Component({
  selector: 'app-adminportal',
  templateUrl: './adminportal.component.html',
  styleUrls: ['./adminportal.component.css']
})
export class AdminportalComponent implements OnInit {
  customers:Customer[];
  visitorCount:number;
  ngOnInit() {
  }
  constructor(private adminService:AdminportalService, private homeService: HomeService,private router:Router) {
if(sessionStorage.getItem('Authorization')===null){
		  this.router.navigate(['/signin']);
	  }
    adminService.getAllCustomers().subscribe(
      res=>{ 
        this.customers=JSON.parse(JSON.stringify(res));
        console.log("List"+this.customers.length);
		this.visitorCount=this.customers.length;
    })
  }
  
  url: string;
  openHtml() {
    let pageName = document.getElementById("indexvalue").getAttribute("value");
    console.log("document",document.getElementById("indexvalue"));
    this.homeService.getUrl(pageName).subscribe(
      (res: HttpResponse<any>) => {
        console.log(res);
        document.getElementById("indexvalue").getAttribute("path");
        this.url = JSON.parse(JSON.parse(JSON.stringify(res))._body);
        window.open(this.url);
      },
      error => {
        console.log(error.error.text);

        window.open(error.error.text);
      }

    );
  }
}
