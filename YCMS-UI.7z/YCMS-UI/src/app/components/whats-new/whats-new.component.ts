import { Component, OnInit } from '@angular/core';
import {WhatsNewService} from '../../services/whats-new/whats-new.service';
import { HttpResponse} from '@angular/common/http';
import { Router } from '@angular/router';

/**
 * This component handles the list to be displayed on the what's new
 * section
 * @author yash.khanwilkar
 */
@Component({
  selector: 'app-whats-new',
  templateUrl: './whats-new.component.html',
  styleUrls: ['./whats-new.component.css']
})
export class WhatsNewComponent implements OnInit {
/**
 * 
 * @param whatsNewService service imported to get the list of updates to the component
 */
  constructor(private whatsNewService: WhatsNewService,private router:Router) {
	
	if(sessionStorage.getItem('Authorization')===null){
		  this.router.navigate(['/signin']);
	  }

  }
/**
 * This will call the getTopFiveUpdates on the page load
 */
  ngOnInit() {
    // this.getTopFiveUpdates();
  }
  /**
   * This will store the list of updates that are done on the application
   */
  updates:String[];

  /**
   * This will get the top five updates from service and store in the array updates
   */
  //   getTopFiveUpdates() {
  //   this.whatsNewService.whatsNewUpdate().subscribe(
  //   res=>{
  //     this.updates=JSON.parse(JSON.parse(JSON.stringify(res))._body);    
  //   }
  //   )
  // }

}
