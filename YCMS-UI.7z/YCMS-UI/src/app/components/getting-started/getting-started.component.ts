import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-getting-started',
  templateUrl: './getting-started.component.html',
  styleUrls: ['./getting-started.component.css']
})
export class GettingStartedComponent implements OnInit {

  constructor(private router:Router) { 
  if(sessionStorage.getItem('Authorization')===null){
		  this.router.navigate(['/signin']);
	  }
  }

  ngOnInit() {
  }

}
