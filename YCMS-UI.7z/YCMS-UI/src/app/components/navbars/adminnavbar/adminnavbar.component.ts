import { Component, OnInit, ViewChild } from '@angular/core';
import {Customer} from '../../../classes/customer';

import {AdminportalService } from '../../../services/adminportal/adminportal.service';
import {MatTableDataSource, MatPaginator, MatSort} from '@angular/material';
import { HttpResponse } from '@angular/common/http';
import { ListArticleService } from '../../../services/listarticle/list-article.service';
import { Article } from '../../../classes/article';
import { LogoutService } from '../../../services/logout/logout.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-adminnavbar',
  templateUrl: './adminnavbar.component.html',
  styleUrls: ['./adminnavbar.component.css']
})
export class AdminnavbarComponent implements OnInit {
  customers:Customer[];
  // articles:Article[];

  dataSource:MatTableDataSource<any>;
  articleDataSource:MatTableDataSource<Article>;

  constructor(private adminService:AdminportalService,
              private listService:ListArticleService,
              private logoutService:LogoutService,
              private router:Router){
    this.getAllCustomers();
    this.getAllArticles();
   }
  displayedColumns = ['firstName', 'lastLoginDate', 'lastLoginTime'];
  articleDisplayedColumns=['fileName','author','datecreated'];
  ngOnInit() {}

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort:MatSort;

  getAllCustomers(){
    this.adminService.getAllCustomers().subscribe(
		res=>{
			console.log(res);
        this.dataSource = new MatTableDataSource(JSON.parse(JSON.stringify(res)));
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      },
      err=>{
        console.log(err);
      }
    )
  }

  getAllArticles(){
    this.listService.getFeaturedArticles().subscribe(
      res =>{
        console.log("get All articles",res);
        this.articleDataSource=new MatTableDataSource(JSON.parse(JSON.stringify(res)));
        this.articleDataSource.paginator=this.paginator;
        this.articleDataSource.sort=this.sort;
      }, 
      err=>{
        console.log(err);
      }
    )
  }
  
  logout(){
    this.logoutService.customerLogout().subscribe(
      res=>{
          sessionStorage.setItem('Authorization','null');
          this.router.navigate(['/signin']);
    });
  }

}


export interface Element {
  name: string;
  position: number;
  weight: number;
 
}

