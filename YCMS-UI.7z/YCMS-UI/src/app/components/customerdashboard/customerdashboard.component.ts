import { Component, OnInit, ViewChild, AfterViewInit, EventEmitter } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UpdateComponent } from '../update/update.component';
import { DataService } from '../../services/data/data.service';
import { Customer } from '../../classes/customer';

/**
 * This component shows various tabs for customer and initially displays update form to customer.
 * 
 * Author : maithili.pande
 */
@Component({
  selector: 'app-customerdashboard',
  templateUrl: './customerdashboard.component.html',
  styleUrls: ['./customerdashboard.component.css']
})
export class CustomerdashboardComponent implements OnInit {

  /**
    *  checks selection for tabs, set to false when tab is selected
    */
  condition = true;

  /**
   * used to show and hide the important message span of customer dashboard
   */
  check: boolean = false;
  
  /**
   * checks if customer is authorized. If not customer is redirected to signin page
   * @param router redirects to signin page
   * @param data 
   */
  constructor(private router: Router, private data: DataService) {
    if (sessionStorage.getItem('Authorization') === null) {
      this.router.navigateByUrl('signin')
    }
  }
  /**
   * @ignore
   */
  ngOnInit() {
  }

  /**
   * checkEvent is value set from the child component i.e. UpdateComponent, 
   * then run the assigneventValue function whenever this event occurs.
   * @param event 
   */
  assigneventValue(event) {
    this.check = event;
  }

  /**
   * sets the condition property to false
   */
  tabSelection() {
    this.condition = false;
  }

}
