import { Component, OnInit } from '@angular/core';
import { HomeService } from '../../services/home/home.service';
import { HttpResponse } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-manage-ycms',
  templateUrl: './manage-ycms.component.html',
  styleUrls: ['./manage-ycms.component.css']
})
export class ManageYcmsComponent implements OnInit {


  constructor(private homeService: HomeService,private router:Router) {
	if(sessionStorage.getItem('Authorization')===null){
		  this.router.navigate(['/signin']);
	  }
  }

  ngOnInit() {
  }

  url: string;
  openHtml() {
    let pageName = document.getElementById("indexvalue").getAttribute("value");
    console.log("document",document.getElementById("indexvalue"));
    this.homeService.getUrl(pageName).subscribe(
      (res: HttpResponse<any>) => {
        console.log(res);
        document.getElementById("indexvalue").getAttribute("path");
        this.url = JSON.parse(JSON.parse(JSON.stringify(res))._body);
        window.open(this.url);
      },
      error => {
        console.log(error.error.text);

        window.open(error.error.text);
      }

    );
  }
}
