import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageYcmsComponent } from './manage-ycms.component';

describe('ManageYcmsComponent', () => {
  let component: ManageYcmsComponent;
  let fixture: ComponentFixture<ManageYcmsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageYcmsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageYcmsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
