import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatSort, MatPaginator,MatDialog } from '@angular/material';
import { Article } from '../../classes/article';
import { Router } from '@angular/router';
import { ListArticleService } from '../../services/listarticle/list-article.service';
import { FormControl, FormGroupDirective, NgForm, Validators, FormGroup, FormArray } from '@angular/forms';
import {ErrorStateMatcher} from '@angular/material/core';
import { DialogBoxComponent } from "./dialog-box/dialog-box.component";
import { DataService } from '../../services/data/data.service';
import {SelectionModel} from '@angular/cdk/collections';
import { HttpResponse } from '@angular/common/http';

@Component({
  selector: 'app-list-article',
  templateUrl: './list-article.component.html',
  styleUrls: ['./list-article.component.css']
})

/**
 * this will work as a mediator in between service and html component.
 * 
 * @author saloni.jain
 * 
 */
export class ListArticleComponent implements OnInit {
  
 
/** array Of publish status**/   
 deleteOptions = [
    {value: 'delete', viewValue: 'Delete'},
    {value: 'trash', viewValue: 'Trash'}
   ];
  
publishStatus = [
    {value: 'published', viewValue: 'Published'},
    {value: 'unpublished', viewValue: 'Unpublished'},
  ];

  /**this is for dialog box. */
  dialogData: any;
  // animal: string;
  // name: string;

  


  /** array Of access**/   
accessStatus = [
  {value: 'private', viewValue: 'Private'},
  {value: 'public', viewValue: 'Public'},
];

/** array Of feature status**/   
featureStatusArray = [
  {value: 'yes', viewValue: 'Featured'},
  {value: 'no', viewValue: 'Unfeatured'},
];

/** array Of language**/   
languages = [
  {value: 'EN', viewValue: 'en'},
  {value: 'HI', viewValue: 'hi'},
];

  /**
   * this variable value will decide to show the span
   */
  private showSpanOnClick:boolean = false;
  /**
   * This varialble value will decide to show side navigation span.
   */
  private showsideNavigationSpanOnClick:boolean=false;
   /**
   * this will store the value of file
   */
  private fileName:string ='';
  /**
   * this will store  the value of status i.e. published or unpublished
   */
  private selectedStatus:string ='';
  /**
   * this will store  the value of access i.e. public or private
   */
  private selectedAccess:string ='';
  /**
   * this will store the value of feature i.e. feature or unfeature
   */
  private featureStatus:string="";
  /**
   * this will store  the value of author name
   */
  private author:string='';
  /**
   * this will store the value of access
   */
  private access:string='';
  /**
   * this will store the value of language
   */
  private language:string='';
  /**
   * this will store the value of id
   */
  private id:number;
  /**
   * this will store the value of text to be search
   */
  private searchText:string="";
  /**
   * this vairiable's value will decide whether the message box will appear or not
   */
  private showMessageBox:boolean=false;
  /**
   * this will store the value of tag.
   */
  private tag:string="";

  /**
   * this will use to propogate the value of article that has been published ,unpublished ,feature or unfeatured etc..
   */
  private responseMessage:string="";
  /**
   * this variable is used for check and uncheck (All) functionality.
   */
  private selectedAll: any;

  private selected:boolean=false;

  selection = new SelectionModel<Article>(true, []);
  /**
   * this will store the name of coloumns
   */
  displayedColumns = ['moreVert','select','status','title','access', 'author', 'language','dateCreated','hits','id'];
  dataSource: MatTableDataSource<Article>;

  @ViewChild(MatPaginator) paginator: MatPaginator;

  @ViewChild(MatSort) sort: MatSort;
  /**
   * this will recieve the value in form of JSON
   */
   articles: Article[] = [];


   /**
    * this will store the list of articles
    */
   articleList=[];

  /**
   * 
   * Set the paginator and sort after the view init since this component will
   * be able to query its view for the initialized paginator and sort.
   * 
   *  @param listArticleService is injected
   */
  constructor(private listArticleService : ListArticleService, 
              private dataService: DataService,
              private router: Router,
              public dialog: MatDialog) {
	  if(sessionStorage.getItem('Authorization')===null){
	  this.router.navigate(['/signin']);
	  }
				  
    // Assign the data to the data source for the table to render
    this.listArticleService.getAllArticles('untrash').subscribe(
      (res)=>{
        
		    console.log("constructor--->",res);
        this.dataSource = new MatTableDataSource(JSON.parse(JSON.stringify(res)));
        this.dataSource.paginator = this.paginator;
      },
      err=>{
        console.log(err);
      }
    );
    
  }
  /**
   * @ignore
   */
  ngOnInit() {
    
  }

  openDialog(): void {
    let dialogRef = this.dialog.open(DialogBoxComponent, {
    
    //data: { name: this.name, animal: this.animal }
  });

  dialogRef.afterClosed().subscribe(result => {
    console.log('The dialog was closed');
   // this.animal = result;
  });
}

  /**
   * this method will show the search Toolbar.
   */
  showSpan(){
    this.showSpanOnClick=!this.showSpanOnClick;
  }

  showSideNavigationSpan(){
    this.showsideNavigationSpanOnClick=!this.showsideNavigationSpanOnClick;
  }

  deleteOrTrashArticle(value:string,id:number) {
    console.log(value,"---->",id);
  if(value=="delete"){
      this.listArticleService.deleteArticle(id).subscribe(
        res=>{
          console.log("res--->",res);
          this.getListOfUntrashedOrTrashArticles('untrash');
        },
        err=>{
          console.log(err);
        }
      );
  }
    if(value=="trash"){
      this.listArticleService.changeStatusToTrash(id).subscribe(
        res=>{
          console.log(res);
          this.getListOfUntrashedOrTrashArticles('untrash');
        },
        err=>{
          console.log(err);
        }
      );
    }
  }

  toggleStatus(id:number,task:string){
    console.log(task);
      if(task=="published" || task=="unpublished"){
          this.changeId(id);
          this.changeStatusToPublishOrUnpublish(task);
      }
      if(task=="featured" || task=="unfeatured"){
        this.changeId(id);
        this.changeStatusToFeatureOrUnfeatureArticle(task);
    }
  }
 
  
  /**
   * this will clear the data of all textbox
   */
  clearTextBox(){
  this.searchText="";
   this.fileName="";
   this.selectedStatus="";
   this.selectedAccess="";
   this.featureStatus="";
   this.author="";
   this.language="";
   this.tag="";
   this.id=0;
   this.getListOfUntrashedOrTrashArticles('untrash');
  }

 /**
  * @ignore
  */
  ngAfterViewInit() {
    
  }
  /**
   * This method will filter the list of articles.
   * 
   * @param filterValue is value on the basis of which we will filter
   * the list of articles.
   */
  applyFilter(filterValue:string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }

  


/** this function will builds and returns a list of articles according to the atribute provided */
  getListOfArticles(){ 
    console.log(this.selectedStatus);
  this.listArticleService.getListOfArticles(this.selectedStatus,this.selectedAccess,this.language,this.featureStatus,this.fileName,this.author,this.tag,this.id).subscribe(
  res=>{ 
    this.dataSource = new MatTableDataSource(JSON.parse(JSON.stringify(res)));
    this.dataSource.paginator = this.paginator;
  },
  err=>{
  console.log(err);
  }
  ); 
  }

  /**
   * 
   */
  getListOfUntrashedOrTrashArticles(task:string) {
    this.listArticleService.getAllArticles(task).subscribe(
      res=>{
        console.log("trash--->",res)
        this.dataSource=JSON.parse(JSON.stringify(res));
      },
      err=>{
        console.log(err);        
      }
    );
  }
  /**
   * method that will used to set Id.
   */
  changeId(id:number){
    this.id=id;
   
  }

  

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    if(numSelected==1)
    {
      this.changeId(this.selection.selected[0].id);// this will give the id when a single checkbox is selected.
   }
    const numRows = this.dataSource.data.length;
    this.articleList=this.dataSource.data;
    this.changeStatus(this.articleList);
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
        this.selection.clear() :
        this.dataSource.data.forEach(row => this.selection.select(row));
  }

  /** this will navigate you to the page where u can create a new article */
  createNewArticle(){
    this.router.navigate(['newArticle']);  
  }




  // editArticle(fileName:string){
  //   console.log(fileName);
	// this.listArticleService.editArticle(fileName).subscribe(
	// res=>{
	// 	console.log(res);
	// 	localStorage.setItem('htmlContent',res.htmlContent);
	// 	localStorage.setItem('title',res.fileName);
	// 	localStorage.setItem('publish',res.publishStatus);
	// 	localStorage.setItem('featured',res.featureStatus);
	// 	localStorage.setItem('tags',res.tag);
	// 	localStorage.setItem('category',res.category);
	// 	localStorage.setItem('language',res.language);
	// 	localStorage.setItem('access',res.access);
		
	// 	this.router.navigate(['/newArticle']);
	// },
	// err=>{
	// 	console.log(err.error.text.htmlContent);

	// }
	// );
  // }


  changeStatusToPublishOrUnpublish(task:string){
    this.responseMessage=task;
    this.listArticleService.changeStatusToPublishOrUnpublish(this.id,task).subscribe(
      res=>{
          this.showMessageBox=!this.showMessageBox; // value will set to true
          this.selection.clear();
          this.getListOfUntrashedOrTrashArticles('untrash');
      },
      err=>{
        this.showMessageBox=!this.showMessageBox;; // value will set to true
        this.selection.clear();
      }
    );
  }
  changeStatusToFeatureOrUnfeatureArticle(task:string){
    this.responseMessage=task;
    this.listArticleService.changeStatusToFeatureOrUnfeatureArticle(this.id,task).subscribe(
      res=>{
        this.showMessageBox=true; // value will set to true
        this.selection.clear();
        this.getListOfUntrashedOrTrashArticles('untrash');
      },
      err=>{
        this.showMessageBox=true; // value will set to true
        this.selection.clear();
      }
    );
    
  }
 
  deleteArticle(){
   
  }

  initializeDataSource(res){
    this.dataSource = new MatTableDataSource(JSON.parse(JSON.stringify(res)));
    this.dataSource.paginator = this.paginator;
  }
  
  openPage(title:string){
	 this.listArticleService.openPage(title).subscribe(
	 (res:HttpResponse<any>)=>{
		 console.log(res);
	 },
	 err=>{
		 console.log(err);
		 let url = err.error.text;
		 window.open(url);
	 }
	 
	 );
  }

  changeStatus(articleList: any): void {
    this.articleList.forEach(row=>{
      this.articleList[0].id;
      console.log(this.articleList[0].id);
    })
  }

}
