import { Component, OnInit, Inject } from '@angular/core';
import {  MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-dialog-box',
  templateUrl: './dialog-box.component.html',
  styles: []
})
export class DialogBoxComponent implements OnInit {

    constructor(
    public dialogRef: MatDialogRef<DialogBoxComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

      onNoClick = function (): void {
        this.dialogRef.close();
      }
      
  ngOnInit() {
  }

}
