import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule,Routes} from '@angular/router';
// import {CategoryComponent} from './category/category.component';

// const routes:Routes = [{path:'dashboard', component:CategoryComponent},{path:'',component:C}];
@NgModule({
  imports: [
    //outerModule.forRoot(routes)
  ],
  declarations: []
})
export class AppRoutingModule { }
