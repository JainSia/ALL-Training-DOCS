export class category{
    category:string;
    categoryDetail:string;
}