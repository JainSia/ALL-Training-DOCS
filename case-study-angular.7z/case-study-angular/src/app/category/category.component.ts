import { Component, OnInit } from '@angular/core';
import { CategoryService } from '../category.service';
import { category } from '../Category';
@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {

  category:string;
  categoryDetail:string;

  constructor(private categoryService:CategoryService) { }
  ngOnInit() {
  }

  addCategory(){
    
    this.categoryService.addCategory(this.category, this.categoryDetail).subscribe(
      res=>{
        console.log(res);
      },
      err=>{
        console.log(err);
      }
    )
  }

}
