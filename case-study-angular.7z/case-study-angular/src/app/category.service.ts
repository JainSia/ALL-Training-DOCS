import { Injectable } from '@angular/core';
import { Observable} from 'rxjs/Observable';
import { Http, Headers} from '@angular/http';
import { category } from './category';
@Injectable()
export class CategoryService {

  url="http://localhost:8080/technicalforumweb/category";
  constructor(private http: Http) { }

  addCategory(category:string,categoryDetail:string){
    console.log(category);
    let categoryJson={'category':category,'categoryDetail':categoryDetail}
    let headers=new Headers({'Content-Type':'application/json'});
    return this.http.post(this.url, categoryJson,{headers: headers, withCredentials: true});
  }
}
